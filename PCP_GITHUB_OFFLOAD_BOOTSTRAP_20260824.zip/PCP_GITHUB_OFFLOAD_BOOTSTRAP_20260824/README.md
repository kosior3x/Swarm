# PCP GitHub offload bootstrap

This bundle prepares Phase 1: GitHub Actions executes Arduino builds, SEOHOST only dispatches/status-checks.

Repository files:
- .github/workflows/pcp-build.yml
- scripts/github/pcp_build_worker.sh
- COPILOT_TASK.md

Server-side bootstrap/reference:
- scripts/server/pcp_github_bridge.py
- scripts/server/bootstrap_github_bridge.sh
- config/pcp_github.env.example

Token config must live outside public_html, recommended: $HOME/.config/pcp/github.env with chmod 600.

No local Termux exit/logout is required by this bundle.
