#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
swarm_fast.py – Szybki mózg SWARM  (CDC v1.3.7)
==============================================
Zmiany względem v1.3.6:
  [B5] LidarPredictorNet – wielokrokowa predykcja LIDAR (H=4):
       Architektura: [K×5] → 52 → 32 → 16 → 4 (T+1..T+4)
       Ważenie błędów: im dalszy horyzont, tym mniejsza waga (exp(-0.5*k))
       Bufory opóźnionej weryfikacji (_actual_buffer, _pending)
       Pesymistyczne minimum z całego horyzontu dla SafetyLayer
       Cechy sieci Q: [pred[0], pred[-1], trend, confidence]

  [v1.3.7 – lifelong learning]
  - Automatyczne wczytywanie stanu brain i predyktora przy starcie
  - Flagi FORCE_NEW_BRAIN i FORCE_NEW_PREDICTOR w SwarmConfig
  - Zabezpieczenie przed nadpisaniem pliku przy starcie (zapis tylko gdy step > 0)
  - Uproszczenie metody load() – nie wczytuje już predyktora
  - Lepsze logowanie wczytywania/zapisu

  [v1.3.7 – dynamiczny BOOST]
  - request_boost(cycles) – czas trwania BOOST zależny od eff_min i predyktora
  - SafetyLayer.compute_boost_cycles() – wyznacza długość boostu
  - W loop() uwzględnia neural_pred_for_safety dla dłuższej reakcji

Sloty 48-51 w wektorze cech:
  f[48] = predicted_min_dist (T+1)
  f[49] = predicted_min_dist (T+H – najdalsza predykcja)
  f[50] = trend (pred[-1] - pred[0])
  f[51] = predictor_confidence

Konwencja Y↓ (pygame):
  lidar[0]=0°=PRZÓD, lidar[4]=90°=LEWY fiz, lidar[8]=180°=TYŁ, lidar[12]=270°=PRAWY fiz
"""

import math
import os
import pickle
import random
from collections import deque
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Tuple, Optional, Any

import numpy as np

from config import SwarmConfig


# =============================================================================
# AKCJE
# =============================================================================

class Action(Enum):
    FORWARD          = auto()
    TURN_LEFT        = auto()
    TURN_RIGHT       = auto()
    SPIN_LEFT        = auto()
    SPIN_RIGHT       = auto()
    REVERSE          = auto()
    ESCAPE_MANEUVER  = auto()
    STOP             = auto()


# Tablicowe PWM – WYŁĄCZNIE dla odruchów bezpieczeństwa (bypass slew).
# Decyzje NEURAL używają get_dynamic_pwm() z głowic speed/steer.
PWM_TABLE: Dict[Action, Tuple[float, float]] = {
    Action.FORWARD:         (  80,  80),
    Action.TURN_LEFT:       (  28,  80),
    Action.TURN_RIGHT:      (  80,  28),
    Action.SPIN_LEFT:       ( -50,  50),
    Action.SPIN_RIGHT:      (  50, -50),
    Action.REVERSE:         ( -60, -60),
    Action.ESCAPE_MANEUVER: ( -50,  50),
    Action.STOP:            (   0,   0),
}


# =============================================================================
# ATRAKTORY CHAOTYCZNE
# =============================================================================

class LorenzAttractor:
    def __init__(self, cfg=None):
        self.sigma = 10.0; self.rho = 28.0; self.beta = 8.0 / 3.0
        self.dt = 0.01
        self.x, self.y, self.z = 1.0, 1.0, 1.0
        self._xn = self._zn = 0.0

    def step(self):
        dx = self.sigma * (self.y - self.x)
        dy = self.x * (self.rho - self.z) - self.y
        dz = self.x * self.y - self.beta * self.z
        self.x += dx * self.dt; self.y += dy * self.dt; self.z += dz * self.dt
        self._xn = max(-1.0, min(1.0, self.x / 22.0))
        self._zn = max(-1.0, min(1.0, self.z / 40.0))

    @property
    def x_norm(self): return self._xn
    @property
    def z_norm(self): return self._zn


class RosslerAttractor:
    def __init__(self):
        self.a, self.b, self.c = 0.2, 0.2, 5.7
        self.dt = 0.02
        self.x, self.y, self.z = -5.0, 0.0, 0.02
        self._xn = 0.0
        for _ in range(2000):
            dx = -self.y - self.z
            dy = self.x + self.a * self.y
            dz = self.b + self.z * (self.x - self.c)
            self.x += dx * self.dt
            self.y += dy * self.dt
            self.z += dz * self.dt
        self._xn = max(-1.0, min(1.0, self.x / 10.0))

    def step(self):
        dx = -self.y - self.z
        dy = self.x + self.a * self.y
        dz = self.b + self.z * (self.x - self.c)
        self.x += dx * self.dt; self.y += dy * self.dt; self.z += dz * self.dt
        self._xn = max(-1.0, min(1.0, self.x / 10.0))

    @property
    def x_norm(self): return self._xn


class DoubleScrollAttractor:
    def __init__(self):
        self.alpha = 9.0; self.beta = 100.0 / 7.0
        self.m0, self.m1 = -1.0 / 7.0, 2.0 / 7.0
        self.dt = 0.005
        self.x, self.y, self.z = 1.2, 0.0, 0.0
        self._xn = 0.0
        self.mode = 'IDLE'
        self.boost_counter = 0; self.release_ramp = 0.0
        self.cross_phase = 0; self.current_amplitude = 0.5

    def _f(self, x):
        return self.m1 * x + 0.5 * (self.m0 - self.m1) * (abs(x + 1) - abs(x - 1))

    def request_boost(self, cycles: int = 4):
        """Przejdź w tryb BOOST na `cycles` kroków (domyślnie 4 dla kompatybilności)."""
        if self.mode != 'BOOST':
            self.mode = 'BOOST'
            self.boost_counter = cycles

    def step_amplitude(self):
        if self.mode == 'BOOST':
            if self.boost_counter > 0:
                self.boost_counter -= 1
                self.current_amplitude = 1.8 if self.boost_counter >= 2 else (1.3 if self.boost_counter % 2 == 1 else 1.6)
            else:
                self.mode = 'RELEASE'; self.release_ramp = 1.0
        elif self.mode == 'RELEASE':
            self.release_ramp = max(0.0, self.release_ramp - 0.12)
            self.current_amplitude = 0.85 + 0.95 * self.release_ramp
            if self.release_ramp <= 0.0:
                self.mode = 'IDLE'; self.current_amplitude = 0.85
        elif self.mode == 'CROSSOVER':
            seq = [0.6, -0.6, -1.1]
            if self.cross_phase < len(seq):
                self.current_amplitude = seq[self.cross_phase]; self.cross_phase += 1
            else:
                self.mode = 'IDLE'; self.current_amplitude = 0.85; self.cross_phase = 0
        else:
            self.current_amplitude = 0.85

    def request_crossover(self):
        if self.mode in ('IDLE', 'RELEASE'):
            self.mode = 'CROSSOVER'; self.cross_phase = 0

    def step(self):
        self.step_amplitude()
        dx = self.alpha * (self.y - self.x - self._f(self.x))
        dy = self.x - self.y + self.z
        dz = -self.beta * self.y
        self.x += dx * self.dt; self.y += dy * self.dt; self.z += dz * self.dt
        self._xn = max(-1.0, min(1.0, self.x / 0.25))

    @property
    def x_norm(self): return self._xn
    @property
    def modulated_x_norm(self): return self._xn * self.current_amplitude


# =============================================================================
# LORENZ CARTOGRAPHER – neuronowy predyktor LIDAR  [CDC v1.3.7 Block 5]
# =============================================================================

class LidarPredictorNet:
    """
    Neuronowy predyktor odległości LIDAR (Lorenz Cartographer).
    WIELOKROKOWY – przewiduje H kroków do przodu.

    Architektura:  [K×5] → Dense(52, GainMod) → Dense(32, GainMod)
                           → Dense(16, GainMod×0.5) → Dense(H)
    Wejście:       K kroków historii × [min_dist, lor_x, lor_z, ros_x, ds_x]
    Wyjście:       wektor H wartości – przewidywane min_dist dla T+1, T+2, ..., T+H
    Uczenie:       online supervised (ważony MSE, gradient co krok)
    Zapis:         predictor_fast.pkl (niezależny od brain_fast.pkl)

    Rola w systemie:
      - Pesymistyczna wartość min(current, worst_pred) trafia do SafetyLayer
        jeszcze PRZED odebraniem kolejnego pakietu z ESP32
      - Sloty 48-51 wektora cech: [pred[0], pred[-1], trend, confidence]
        – sieć Q widzi trajektorię predykcji i może reagować przed kolizją
    """

    def __init__(self, k: int = 10, hidden1: int = 52, hidden2: int = 32,
                 hidden3: int = 16, horizon: int = 4,
                 lr: float = 0.006, beta: float = 0.2):
        self.k = k
        self.hidden1 = hidden1
        self.hidden2 = hidden2
        self.hidden3 = hidden3
        self.horizon = horizon        # H – ile kroków do przodu
        self.lr = lr
        self.n_in = k * 5            # 50

        # Wagi błędów dla różnych horyzontów – im dalej, tym mniejsza waga
        raw_weights = np.exp(-0.5 * np.arange(horizon))  # [1.00, 0.61, 0.37, 0.22]
        self._error_weights = raw_weights / raw_weights.sum()

        # Aktywacje chaotyczne (takie same jak w głównej sieci Fast Brain)
        self.act1 = GainModActivation(beta)
        self.act2 = GainModActivation(beta)
        self.act3 = GainModActivation(beta * 0.5)

        # Warstwa 1: Wejście → hidden1 (50 → 52)
        self.W1 = (np.random.randn(self.n_in, hidden1).astype(np.float64)
                   * np.sqrt(2.0 / self.n_in))
        self.b1 = np.zeros(hidden1, dtype=np.float64)

        # Warstwa 2: hidden1 → hidden2 (52 → 32)
        self.W2 = (np.random.randn(hidden1, hidden2).astype(np.float64)
                   * np.sqrt(2.0 / hidden1))
        self.b2 = np.zeros(hidden2, dtype=np.float64)

        # Warstwa 3: hidden2 → hidden3 (32 → 16)
        self.W3 = (np.random.randn(hidden2, hidden3).astype(np.float64)
                   * np.sqrt(2.0 / hidden2))
        self.b3 = np.zeros(hidden3, dtype=np.float64)

        # Warstwa wyjściowa: hidden3 → horizon (16 → H, liniowa)
        self.W4 = np.random.randn(hidden3, horizon).astype(np.float64) * 0.01
        self.b4 = np.zeros(horizon, dtype=np.float64)

        # Bufor historii wejść
        self.history: deque = deque(maxlen=k)
        # Kolejka predykcji czekających na weryfikację
        self._pending: deque = deque(maxlen=52)
        # Bufor przyszłych wartości min_dist do weryfikacji
        self._actual_buffer: deque = deque(maxlen=horizon)

        self.mae: float = 0.5
        self._trained_steps: int = 0
        self._last_pred: Optional[np.ndarray] = None

    def push(self, min_dist: float, lor_x: float, lor_z: float,
             ros_x: float, ds_x: float):
        """Dodaj bieżący odczyt do bufora historii."""
        self.history.append([float(min_dist), float(lor_x), float(lor_z),
                              float(ros_x), float(ds_x)])

    def _fwd(self, flat: np.ndarray, chaos: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Forward pass. Zwraca (pred_H, h1, h2, h3) z aktywacją chaotyczną."""
        z1 = flat @ self.W1 + self.b1
        h1 = self.act1.forward(z1, chaos)

        z2 = h1 @ self.W2 + self.b2
        h2 = self.act2.forward(z2, chaos)

        z3 = h2 @ self.W3 + self.b3
        h3 = self.act3.forward(z3, chaos)

        raw = h3 @ self.W4 + self.b4   # → H wartości
        return np.clip(raw, 0.0, 3.0), h1, h2, h3

    def predict_next(self) -> Optional[np.ndarray]:
        """
        Predykcja wektora H wartości min_dist dla kolejnych kroków.
        Zwraca None gdy bufor historii niepełny.
        """
        if len(self.history) < self.k:
            return None
        flat = np.array(list(self.history), dtype=np.float64).flatten()
        chaos = float(self.history[-1][1])
        pred, _, _, _ = self._fwd(flat, chaos)
        self._last_pred = pred.copy()
        self._pending.append((flat.copy(), chaos, pred.copy()))
        return pred

    def update_actual(self, actual_min: float):
        """
        Weryfikuje najstarszą predykcję przez rzeczywiste wartości.
        Używa bufora _actual_buffer do zebrania H przyszłych wartości.
        """
        self._actual_buffer.append(float(actual_min))

        # Potrzebujemy H wartości w buforze, żeby zweryfikować predykcję
        if len(self._actual_buffer) < self.horizon or not self._pending:
            return

        flat, chaos, predicted = self._pending.popleft()
        actual = np.array(list(self._actual_buffer), dtype=np.float64)  # H wartości

        # Ważony błąd – im dalszy horyzont, tym mniejsza waga
        errors = predicted - actual
        weighted_mae = np.sum(self._error_weights * np.abs(errors))
        self.mae = 0.98 * self.mae + 0.02 * weighted_mae
        self._trained_steps += 1

        # Forward pass (ponownie, aby uzyskać cache dla backward)
        _, h1, h2, h3 = self._fwd(flat, chaos)

        # Gradient wyjściowy z ważeniem
        dL_weighted = (errors * self._error_weights).reshape(1, -1)  # (1, H)
        dW4 = h3.reshape(-1, 1) @ dL_weighted  # (16, 1) @ (1, H) → (16, H)
        db4 = (errors * self._error_weights).copy()
        d_h3 = (self.W4 @ dL_weighted.T).flatten()

        # Wstecz przez act3
        d_h3_act = self.act3.backward(d_h3)
        dW3 = np.outer(h2, d_h3_act)
        db3 = d_h3_act.copy()
        d_h2 = d_h3_act @ self.W3.T

        # Wstecz przez act2
        d_h2_act = self.act2.backward(d_h2)
        dW2 = np.outer(h1, d_h2_act)
        db2 = d_h2_act.copy()
        d_h1 = d_h2_act @ self.W2.T

        # Wstecz przez act1
        d_h1_act = self.act1.backward(d_h1)
        dW1 = np.outer(flat, d_h1_act)
        db1 = d_h1_act.copy()

        clip = 0.075
        for w, dw, bv, db in [
            (self.W4, dW4, self.b4, db4),
            (self.W3, dW3, self.b3, db3),
            (self.W2, dW2, self.b2, db2),
            (self.W1, dW1, self.b1, db1),
        ]:
            w  -= self.lr * np.clip(dw, -clip, clip)
            bv -= self.lr * np.clip(db, -clip, clip)
            np.clip(w, -5.0, 5.0, out=w)

    def pessimistic(self, current: float) -> float:
        """min(current, worst_pred) – pesymistyczne minimum z całego horyzontu."""
        p = self.predict_next()
        if p is None:
            return current
        return min(current, float(np.min(p)))

    @property
    def confidence(self) -> float:
        """Pewność: 1 − MAE/3.0 (0 = zły predyktor, 1 = idealny)."""
        return float(max(0.0, 1.0 - self.mae / 3.0))

    def save(self, filepath: str):
        data = {
            'W1': self.W1, 'b1': self.b1,
            'W2': self.W2, 'b2': self.b2,
            'W3': self.W3, 'b3': self.b3,
            'W4': self.W4, 'b4': self.b4,
            'mae': self.mae, 'steps': self._trained_steps,
            'horizon': self.horizon,
        }
        try:
            tmp = filepath + '.tmp'
            with open(tmp, 'wb') as f:
                pickle.dump(data, f)
            os.replace(tmp, filepath)
        except Exception as e:
            print(f"[PREDICTOR] Błąd zapisu: {e}")

    def load(self, filepath: str) -> bool:
        if not os.path.exists(filepath):
            return False
        try:
            with open(filepath, 'rb') as f:
                data = pickle.load(f)
            if (data.get('horizon', 1) != self.horizon):
                print(f"[PREDICTOR] Niezgodność horyzontu ({data.get('horizon', 1)} vs {self.horizon}) – start od zera")
                return False
            if (data['W1'].shape == self.W1.shape and
                data['W2'].shape == self.W2.shape and
                data['W3'].shape == self.W3.shape and
                data['W4'].shape == self.W4.shape):
                self.W1[:] = data['W1']; self.b1[:] = data['b1']
                self.W2[:] = data['W2']; self.b2[:] = data['b2']
                self.W3[:] = data['W3']; self.b3[:] = data['b3']
                self.W4[:] = data['W4']; self.b4[:] = data['b4']
                self.mae = float(data.get('mae', 0.5))
                self._trained_steps = int(data.get('steps', 0))
                print(f"[PREDICTOR] Wczytano: mae={self.mae:.4f}  steps={self._trained_steps}  horizon={self.horizon}")
                return True
            else:
                print(f"[PREDICTOR] Niezgodność kształtów – start od zera")
                return False
        except Exception as e:
            print(f"[PREDICTOR] Błąd odczytu ({e}) – start od zera")
            return False


# =============================================================================
# RESERVOIR COMPUTING – Echo State Network
# =============================================================================

class ReservoirReadout:
    def __init__(self, k: int = 12, c_dim: int = 8):
        self.k = k; self.c_dim = c_dim
        self.n_in = k * 7
        self.lr = 0.0001
        self.Wr = np.random.randn(self.n_in, c_dim).astype(np.float64) * 0.01
        self.br = np.zeros(c_dim, dtype=np.float64)
        self.history: deque = deque(maxlen=k)

    def push(self, lorenz, rossler, dscroll):
        snap = [lorenz.x_norm, lorenz.y / 30.0, lorenz.z_norm,
                rossler.x_norm, rossler.y / 5.0,
                dscroll.x_norm,
                float(np.clip(dscroll.y / 1.0, -1.0, 1.0))]
        self.history.append(snap)

    def read(self) -> np.ndarray:
        if len(self.history) < self.k:
            return np.zeros(self.c_dim, dtype=np.float32)
        flat = np.array(list(self.history), dtype=np.float64).flatten()
        return np.tanh(flat @ self.Wr + self.br).astype(np.float32)

    def update(self, reward: float):
        if len(self.history) < self.k:
            return
        flat = np.array(list(self.history), dtype=np.float64).flatten()
        ctx = np.tanh(flat @ self.Wr + self.br)
        dtanh = 1.0 - ctx ** 2
        self.Wr += self.lr * np.clip(np.outer(flat, reward * dtanh), -0.1, 0.1)
        self.br += self.lr * np.clip(reward * dtanh, -0.1, 0.1)

    def get_weights(self): return {'Wr': self.Wr.copy(), 'br': self.br.copy()}

    def set_weights(self, d):
        if 'Wr' in d and d['Wr'].shape == self.Wr.shape: self.Wr[:] = d['Wr']
        if 'br' in d and d['br'].shape == self.br.shape: self.br[:] = d['br']


# =============================================================================
# NORMALIZACJA CECH
# =============================================================================

class RunningNormalizer:
    def __init__(self, n: int):
        self.n = n
        self.mu  = np.zeros(n, dtype=np.float64)
        self.var = np.ones(n,  dtype=np.float64)
        self.cnt = 0

    def update(self, x: np.ndarray):
        self.cnt += 1
        d = x - self.mu
        self.mu  += d / self.cnt
        self.var += d * (x - self.mu)

    def normalize(self, x: np.ndarray) -> np.ndarray:
        if self.cnt < 2: return x.astype(np.float32)
        std = np.sqrt(np.maximum(self.var / self.cnt, 1e-8))
        return np.clip((x - self.mu) / std, -4.0, 4.0).astype(np.float32)


# =============================================================================
# EKSTRAKTOR CECH – 108 cech
# =============================================================================

class FeatureExtractor:
    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg
        self.bumper_history = 0.0

    def extract(self,
                lidar_16: np.ndarray,
                us_left: float, us_right: float,
                encoder_l: float, encoder_r: float,
                attractor_x: float, attractor_z: float,
                rear_bumper: int, min_dist: float,
                last_action: Optional[Action] = None,
                free_angle: float = 0.0, free_mag: float = 0.0,
                rossler_x: float = 0.0, double_scroll_x: float = 0.0,
                rc_context: Optional[np.ndarray] = None,
                slow_action: Optional[Action] = None,
                predicted_min: float = 0.0,        # 48 – pred[0] – T+1
                predicted_far: float = 0.0,        # 49 – pred[-1] – T+H
                trend: float = 0.0,                # 50 – pred[-1] - pred[0]
                predictor_conf: float = 0.0,       # 51 – confidence
                ) -> np.ndarray:

        front_sec = np.array([lidar_16[14], lidar_16[15], lidar_16[0], lidar_16[1]])
        right_sec = lidar_16[10:14]
        rear_sec  = lidar_16[6:10]
        left_sec  = lidar_16[2:6]

        mf = float(np.mean(front_sec))
        ml = float(np.mean(left_sec))
        mr = float(np.mean(right_sec))
        mt = float(np.mean(rear_sec))
        avg_speed  = (encoder_l + encoder_r) / 2.0
        speed_diff = encoder_l - encoder_r
        us_min = min(us_left, us_right)

        f: List[float] = []
        f.extend(lidar_16.tolist())                                # 0-15
        f.append(min_dist)                                         # 16
        f.append(mf); f.append(ml); f.append(mr); f.append(mt)    # 17-20
        f.append(ml - mr)                                          # 21
        f.append(1.0 if min_dist < 0.3 else 0.0)                  # 22
        f.append(us_left); f.append(us_right); f.append(us_min)   # 23-25
        f.append(us_left - us_right)                               # 26
        f.append(1.0 if us_left < 0.2 else 0.0)                   # 27
        f.append(1.0 if us_right < 0.2 else 0.0)                  # 28
        f.append(encoder_l); f.append(encoder_r)                  # 29-30
        f.append(avg_speed); f.append(speed_diff)                 # 31-32
        f.append(abs(speed_diff))                                  # 33
        f.append(attractor_x); f.append(attractor_z)              # 34-35
        f.append(rossler_x)                                        # 36
        f.append(double_scroll_x)                                  # 37
        f.append(rossler_x * attractor_x)                          # 38
        f.append(double_scroll_x * min_dist)                       # 39
        # 40-47: RC context (ESN readout 8D)
        if rc_context is not None and len(rc_context) == 8:
            f.extend(rc_context.tolist())
        else:
            f.extend([0.0] * 8)
        # 48-51: Lorenz Cartographer predykcja wielokrokowa [B5]
        f.append(float(predicted_min))                             # 48 – T+1
        f.append(float(predicted_far))                             # 49 – T+H
        f.append(float(trend))                                     # 50 – trend
        f.append(float(predictor_conf))                            # 51 – confidence
        f.append(float(rear_bumper))                               # 52
        f.append(us_min * min_dist)                                # 53
        f.append((1.0 if min_dist < 0.3 else 0.0) * avg_speed)   # 54
        f.append((us_left - us_right) * attractor_x)              # 55
        f.append(speed_diff * (1.0 - min_dist))                   # 56
        f.append((ml - mr) * attractor_x)                         # 57
        f.append(min_dist * avg_speed)                             # 58
        f.append(us_min * avg_speed)                               # 59
        f.append(float(np.log(min_dist + 0.01)))                  # 60
        f.append(float(np.var(front_sec)))                         # 61
        f.append(ml - mf); f.append(mr - mf); f.append(mt - mf)  # 62-64
        f.append(min_dist ** 2); f.append(us_min ** 2)            # 65-66
        fp = float(np.max(front_sec))
        f.append(fp)                                               # 67
        f.append(float(np.max(left_sec)))                          # 68
        f.append(float(np.max(right_sec)))                         # 69
        f.append(fp - mf)                                          # 70
        f.append(float(np.max(left_sec))  - ml)                   # 71
        f.append(float(np.max(right_sec)) - mr)                   # 72
        f.append(1.0 / (us_left  + 0.1))                          # 73
        f.append(1.0 / (us_right + 0.1))                          # 74
        f.append(avg_speed ** 2)                                   # 75
        f.append(1.0)                                              # 76 bias
        f.append(1.0 - mf); f.append(1.0 - mt)                   # 77-78
        f.append(1.0 - ml); f.append(1.0 - mr)                   # 79-80
        f.append(math.sin(free_angle))                             # 81
        f.append(math.cos(free_angle))                             # 82
        f.append(free_mag)                                         # 83
        a_vec = [0.0] * 8
        if last_action is not None:
            idx = last_action.value - 1
            if 0 <= idx < 8: a_vec[idx] = 1.0
        f.extend(a_vec)                                            # 84-91
        if rear_bumper == 1:
            self.bumper_history = 1.0
        else:
            self.bumper_history *= 0.9
        f.append(self.bumper_history)                              # 92
        fc = 1.0 - mf
        f.append(fc * (1.0 - ml))                                 # 93
        f.append(fc * (1.0 - mr))                                 # 94
        f.append((1.0 - mt) * (1.0 - ml))                        # 95
        f.append((1.0 - mt) * (1.0 - mr))                        # 96
        f.append(fc * avg_speed)                                   # 97
        f.append(0.0); f.append(0.0)                              # 98-99
        # 100-107: slow action one-hot
        if slow_action is not None and hasattr(slow_action, 'value'):
            sv = [0.0] * 8; sv[slow_action.value - 1] = 1.0
            f.extend(sv)
        else:
            f.extend([0.0] * 8)

        if len(f) != 108:
            raise RuntimeError(f"FeatureExtractor: {len(f)} != 108 – błąd rozmiaru wektora cech")
        return np.array(f, dtype=np.float32)


# =============================================================================
# SIEĆ NEURONOWA Z MODULACJĄ CHAOTYCZNĄ + GŁOWICE KIERUNKOWE  [B6]
# =============================================================================

class GainModActivation:
    """ReLU z chaotycznym gain – gain = max(0.01, 1 + beta * lorenz_norm)."""
    def __init__(self, beta: float = 0.2):
        self.beta = beta; self._gain = 1.0; self._cache = None

    def forward(self, z: np.ndarray, chaos: float) -> np.ndarray:
        self._gain = max(0.01, 1.0 + self.beta * float(chaos))
        a = np.maximum(0.0, z) * self._gain
        self._cache = (z, a)
        return a

    def backward(self, d: np.ndarray) -> np.ndarray:
        z, _ = self._cache
        return d * self._gain * (z > 0).astype(np.float64)


class HystereticLayer:
    """
    [v1.3] Warstwa histeretyczna – każdy neuron pamięta swój stan binarny.
    Kompatybilna z GainModActivation pod kątem forward/backward API.
    Aby użyć: ustaw USE_HYSTERESIS=True w SwarmConfig.
    """
    def __init__(self, size: int,
                 up_base: float   = 0.40, down_base: float = 0.15,
                 up_range: float  = 0.50, down_range: float = 0.30):
        self.size       = size
        self.up_base    = up_base
        self.down_base  = down_base
        self.up_range   = up_range
        self.down_range = down_range
        self.state      = np.zeros(size, dtype=np.float64)
        self._cache: Optional[tuple] = None

    def forward(self, z: np.ndarray,
                lorenz_x: float, rossler_x: float = 0.0) -> np.ndarray:
        arousal = max(0.0, min(1.0, float(lorenz_x)))
        fatigue = max(0.0, min(1.0, -float(rossler_x)))

        up_th   = self.up_base   + self.up_range   * arousal
        down_th = self.down_base - self.down_range  * fatigue
        if up_th <= down_th + 0.05:
            up_th = down_th + 0.05

        up_mask   = (z > up_th).astype(np.float64)
        down_mask = (z < down_th).astype(np.float64)
        self.state = up_mask + (1.0 - up_mask) * (1.0 - down_mask) * self.state
        self._cache = (z, up_mask, down_mask, up_th, down_th)
        return self.state * np.maximum(0.0, z)

    def forward_gain(self, z: np.ndarray, chaos: float) -> np.ndarray:
        return self.forward(z, lorenz_x=chaos)

    def backward(self, d: np.ndarray) -> np.ndarray:
        if self._cache is None:
            return d
        z, up_mask, down_mask, up_th, down_th = self._cache
        changed = (up_mask + down_mask) > 0.0
        gate = np.where(changed, 1.0, 0.2) * (np.abs(z) < 2.0)
        return d * self.state * gate


class NeuralBrain:
    """
    Sieć Q z trzema głowicami wyjściowymi:
      Wq – Q-values (8), Wa – avoidance (8),
      W_speed – speed_head (1), W_steer – steer_head (1)
    Architektura: 108 → 80 → 88 → 64 → {Wq, Wa, W_speed, W_steer}
    """

    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg
        self.lr  = cfg.NN_LR
        self.steer_lr = cfg.STEER_LR
        F, H1, H2, H3, A = (cfg.FEATURE_DIM, cfg.HIDDEN_1,
                             cfg.HIDDEN_2, cfg.HIDDEN_3, cfg.N_ACTIONS)

        def W(r, c): return np.random.randn(r, c).astype(np.float64) * 0.1
        def b(n):    return np.zeros(n, dtype=np.float64)

        self.W1, self.b1 = W(F,  H1), b(H1)
        self.W2, self.b2 = W(H1, H2), b(H2)
        self.W3, self.b3 = W(H2, H3), b(H3)
        self.Wq, self.bq = W(H3, A),  b(A)
        self.Wa, self.ba = W(H3, A),  b(A)

        self.W_speed = W(H3, 1) * 0.01
        self.b_speed = np.array([1.386], dtype=np.float64)
        self.W_steer = W(H3, 1) * 0.01
        self.b_steer = np.zeros(1, dtype=np.float64)

        beta = cfg.LORENZ_BETA
        if getattr(cfg, 'USE_HYSTERESIS', False):
            self.act1 = HystereticLayer(H1)
            self._use_hyst = True
        else:
            self.act1 = GainModActivation(beta)
            self._use_hyst = False
        self.act2 = GainModActivation(beta)
        self.act3 = GainModActivation(beta * 0.5)
        self.cache: Dict[str, Any] = {}

        self._speed: float = 0.8
        self._steer: float = 0.0

    def forward(self, features: np.ndarray, lorenz_x: float,
                rossler_x: float = 0.0) -> np.ndarray:
        if self._use_hyst:
            a1 = self.act1.forward(np.dot(features, self.W1) + self.b1,
                                   lorenz_x, rossler_x)
        else:
            a1 = self.act1.forward(np.dot(features, self.W1) + self.b1, lorenz_x)
        a2 = self.act2.forward(np.dot(a1, self.W2) + self.b2, lorenz_x)
        a3 = self.act3.forward(np.dot(a2, self.W3) + self.b3, lorenz_x)
        q  = np.clip(np.dot(a3, self.Wq) + self.bq, -5.0, 5.0)
        av = np.clip(np.dot(a3, self.Wa) + self.ba, -2.0, 2.0)

        speed_raw = float((np.dot(a3, self.W_speed) + self.b_speed)[0])
        steer_raw = float((np.dot(a3, self.W_steer) + self.b_steer)[0])
        self._speed = float(1.0 / (1.0 + math.exp(-max(-30.0, min(30.0, speed_raw)))))
        self._steer = float(math.tanh(steer_raw))

        self.cache.update(dict(f=features, a1=a1, a2=a2, a3=a3, q=q, av=av))
        return q

    def avoidance(self) -> np.ndarray:
        return self.cache.get('av', np.zeros(self.cfg.N_ACTIONS))

    def get_dynamic_pwm(self, action: Action, pwm_max: float) -> Tuple[float, float]:
        spd = self._speed
        st  = self._steer
        P   = pwm_max

        if action == Action.FORWARD:
            base = spd * P
            pl = base * max(0.0, 1.0 + 0.35 * st)
            pr = base * max(0.0, 1.0 - 0.35 * st)
        elif action == Action.TURN_LEFT:
            outer = spd * P
            inner_r = max(0.05, 0.35 * (1.0 - 0.6 * abs(st)))
            pl = outer * inner_r
            pr = outer
        elif action == Action.TURN_RIGHT:
            outer = spd * P
            inner_r = max(0.05, 0.35 * (1.0 - 0.6 * abs(st)))
            pl = outer
            pr = outer * inner_r
        elif action == Action.SPIN_LEFT:
            mag = spd * P * max(0.3, 0.5 + 0.3 * abs(st))
            pl = -mag; pr = mag
        elif action == Action.SPIN_RIGHT:
            mag = spd * P * max(0.3, 0.5 + 0.3 * abs(st))
            pl = mag; pr = -mag
        elif action == Action.REVERSE:
            rev = spd * 0.45 * P
            pl = pr = -rev
        elif action == Action.ESCAPE_MANEUVER:
            mag = spd * 0.5 * P * max(0.4, 0.6 + 0.4 * abs(st))
            pl = -mag; pr = mag
        else:
            pl = pr = 0.0

        return (float(np.clip(pl, -P, P)),
                float(np.clip(pr, -P, P)))

    def backward(self, tgt_q: np.ndarray, tgt_a: Optional[np.ndarray] = None):
        if 'f' not in self.cache: return
        c = self.cache
        clip = self.cfg.NN_CLIP_GRAD * 0.1

        dq  = c['q'] - tgt_q
        dWq = np.outer(c['a3'], dq); dbq = dq

        da_out = np.zeros_like(c['a3'])
        if tgt_a is not None:
            da = c['av'] - tgt_a
            self.Wa -= self.lr * np.clip(np.outer(c['a3'], da), -clip, clip)
            self.ba -= self.lr * np.clip(da, -clip, clip)
            da_out = np.dot(da, self.Wa.T)

        d3 = self.act3.backward(np.dot(dq, self.Wq.T) + da_out)
        d2 = self.act2.backward(np.dot(d3, self.W3.T))
        d1 = self.act1.backward(np.dot(d2, self.W2.T))

        for w, dw, bv, db in [
            (self.Wq, dWq,                      self.bq, dbq),
            (self.W3, np.outer(c['a2'], d3),    self.b3, d3),
            (self.W2, np.outer(c['a1'], d2),    self.b2, d2),
            (self.W1, np.outer(c['f'],  d1),    self.b1, d1),
        ]:
            w  -= self.lr * np.clip(dw, -clip, clip)
            bv -= self.lr * np.clip(db, -clip, clip)
        for w in (self.W1, self.W2, self.W3, self.Wq, self.Wa):
            np.clip(w, -10.0, 10.0, out=w)

    def backward_steering(self, reward: float, action: Action,
                          prev_pwm_l: float = 0.0, prev_pwm_r: float = 0.0,
                          cur_pwm_l: float = 0.0, cur_pwm_r: float = 0.0):
        if 'a3' not in self.cache: return
        a3 = self.cache['a3']
        lr = self.steer_lr

        sg = float(self._speed * (1.0 - self._speed))
        if reward > 0:
            delta_speed = reward * sg * 0.5
        else:
            delta_speed = reward * sg * 0.3

        pwm_jump = (abs(cur_pwm_l - prev_pwm_l) + abs(cur_pwm_r - prev_pwm_r)) / 200.0
        smooth_pen = -self.cfg.STEER_SMOOTH_WEIGHT * pwm_jump
        delta_speed += smooth_pen * sg

        tg = float(1.0 - self._steer ** 2)

        if action == Action.TURN_LEFT:
            target_steer = -0.8 if reward > 0 else 0.0
        elif action == Action.TURN_RIGHT:
            target_steer = +0.8 if reward > 0 else 0.0
        elif action in (Action.SPIN_LEFT,):
            target_steer = -1.0 if reward > 0 else -0.5
        elif action in (Action.SPIN_RIGHT,):
            target_steer = +1.0 if reward > 0 else +0.5
        else:
            target_steer = 0.0

        steer_error = target_steer - self._steer
        l2_pull = -0.025 * self._steer
        entropy_bonus = -0.01 * (self._steer ** 2)

        delta_steer = tg * (0.3 * steer_error + l2_pull + entropy_bonus)

        clip = 0.01
        self.W_speed += lr * np.clip(np.outer(a3, [delta_speed]), -clip, clip)
        self.b_speed += lr * np.clip(np.array([delta_speed]),      -clip, clip)
        self.W_steer += lr * np.clip(np.outer(a3, [delta_steer]), -clip, clip)
        self.b_steer += lr * np.clip(np.array([delta_steer]),      -clip, clip)

        np.clip(self.W_speed, -5.0, 5.0, out=self.W_speed)
        np.clip(self.W_steer, -5.0, 5.0, out=self.W_steer)


# =============================================================================
# REPLAY BUFFER
# =============================================================================

class ReplayBuffer:
    def __init__(self, capacity: int):
        self.buf: deque = deque(maxlen=capacity)

    def push(self, s, a, r, s2, done): self.buf.append((s, a, r, s2, done))
    def sample(self, n): return random.sample(self.buf, min(n, len(self.buf)))
    def __len__(self): return len(self.buf)


# =============================================================================
# AVOIDANCE BUFFER
# =============================================================================

@dataclass
class AvoidExp:
    features: np.ndarray; action: int; severity: float


class AvoidanceBuffer:
    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg; self.buf: List[AvoidExp] = []; self.cap = cfg.AVOIDANCE_CAPACITY

    def push(self, features, action, severity):
        if severity < self.cfg.AVOIDANCE_MIN_SEVERITY: return
        self.buf.append(AvoidExp(features.copy(), action, severity))
        if len(self.buf) > self.cap:
            self.buf.sort(key=lambda e: e.severity)
            self.buf = self.buf[len(self.buf)//4:]

    def decay(self):
        for e in self.buf: e.severity *= self.cfg.AVOIDANCE_DECAY

    def sample(self, n):
        if not self.buf: return []
        sevs = np.array([e.severity for e in self.buf])
        probs = sevs / sevs.sum()
        idxs = np.random.choice(len(self.buf), size=min(n, len(self.buf)),
                                replace=False, p=probs)
        return [self.buf[i] for i in idxs]

    def __len__(self): return len(self.buf)


# =============================================================================
# SAFETY LAYER  (LinPredictor zachowany jako wewnętrzny fallback)
# =============================================================================

class _LinearLidarPredictor:
    def __init__(self, horizon_steps: int = 15):
        self.horizon = horizon_steps
        self.history: deque = deque(maxlen=max(horizon_steps * 2, 30))

    def update(self, min_dist: float): self.history.append(float(min_dist))

    def predict(self) -> Optional[float]:
        if len(self.history) < self.horizon + 2: return None
        y = list(self.history)[-self.horizon:]
        slope = (y[-1] - y[0]) / max(len(y) - 1, 1)
        return max(0.0, y[-1] + slope * self.horizon)

    def pessimistic(self, current: float) -> float:
        p = self.predict()
        return min(current, p) if p is not None else current


class SafetyLayer:
    """
    Hierarchiczny nawigator:
      1. Bumper front  → REVERSE + SPIN do najlepszej strefy
      2. Hard safety   → natychmiastowy SPIN
      3. Bumper rear   → FORWARD
      4. Nawigacja ciągła (steer z us_diff + lidar_lr_diff)
      5. Droga wolna   → None (sieć decyduje)
    """
    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg
        self._bump_rev = 0; self._bump_spin = 0; self._bump_spin_total = 0
        self._bump_act: Optional[Action] = None
        self._bump_cd = 0; self._rear_fwd = 0
        self._reflex_act: Optional[Action] = None; self._reflex_rem = 0
        self._stall_active: bool = False
        self._stall_rem:    int  = 0
        self._side_cd = 0
        self._lin_pred = _LinearLidarPredictor(horizon_steps=cfg.PREDICT_STEPS)
        self._last_pred = -1.0
        self._hs_consecutive: int   = 0
        self._hs_min_dist_best: float = 3.0
        self._hs_escape_rem:  int   = 0
        self._hs_escape_mode: str   = 'SPIN'

    def compute_boost_cycles(self, eff_min: float, base: float = 0.30) -> int:
        """
        Zwraca liczbę cykli boostu na podstawie bieżącej bezpiecznej odległości.
        Im mniejsze eff_min, tym dłuższy boost (maks. 12 cykli).

        Jeżeli eff_min >= base → 0 cykli (brak potrzeby boostu).
        """
        if eff_min >= base:
            return 0
        # danger ∈ (0, 1] – 1 dla eff_min=0 (najgorzej), 0 dla eff_min=base
        danger = 1.0 - (eff_min / base)
        # 2..12 cykli
        return 2 + int(danger * 10)   # 10 = (max_cycles - min_cycles) = 12-2

    def _spatial(self, lidar: np.ndarray) -> Dict:
        MAX = self.cfg.LIDAR_MAX_RANGE
        occ = {
            # Sektory frontowe: tylko 15,0,1 (±45°) – nie 14 (±67.5°) który łapie ściany boczne
            'F': float(np.mean(lidar[[15, 0, 1]])),
            'R': float(np.mean(lidar[10:14])),
            'B': float(np.mean(lidar[6:10])),
            'L': float(np.mean(lidar[2:6])),
        }
        dist = {k: (1.0 - v) * MAX for k, v in occ.items()}
        dist_min = {
            'L': (1.0 - float(np.max(lidar[2:6])))   * MAX,
            'R': (1.0 - float(np.max(lidar[10:14]))) * MAX,
        }
        best = min(occ, key=occ.__getitem__)
        return {'occ': occ, 'dist': dist, 'dist_min': dist_min, 'best': best}

    def _spin_to(self, zone: str, usl: float, usr: float) -> Action:
        if zone == 'R': return Action.SPIN_RIGHT
        if zone == 'L': return Action.SPIN_LEFT
        if zone == 'B': return Action.SPIN_RIGHT if usr >= usl else Action.SPIN_LEFT
        return Action.SPIN_LEFT

    def _cycles(self, zone: str) -> int:
        dpc = self.cfg.BUMPER_DEG_PER_CYCLE; oh = self.cfg.BUMPER_SPIN_OVERHEAD
        return int({'F': 0, 'R': 90, 'B': 180, 'L': 90}.get(zone, 90) / dpc) + oh

    def check(self, lidar, lidar_min, us_left, us_right,
              encoder_l, encoder_r, bumper_front, rear_bumper,
              double_scroll_x=0.0, neural_pred_min: float = -1.0,
              tof_left: float = 3.0, tof_right: float = 3.0,
              ) -> Tuple[Optional[Action], str]:

        sp = self._spatial(lidar)
        occ = sp['occ']; dist = sp['dist']; best = sp['best']

        self._lin_pred.update(lidar_min)
        lin_pred = self._lin_pred.pessimistic(lidar_min)

        tof_min = min(
            tof_left  if tof_left  > 0.02 else 3.0,
            tof_right if tof_right > 0.02 else 3.0,
        )
        if neural_pred_min >= 0.0:
            eff_min = min(lidar_min, neural_pred_min, lin_pred, tof_min)
        else:
            eff_min = min(lidar_min, lin_pred, tof_min)
        # Podłoga: predyktor nie może obniżyć eff_min o więcej niż 45% rzeczywistego lidar_min.
        # Eliminuje phantom HARD_SAFETY gdy lidar widzi wolną przestrzeń (>0.8m),
        # a lin_pred underestimuje przez hamowanie / obrót głowicy.
        eff_min = max(eff_min, lidar_min * 0.55)
        self._last_pred = self._lin_pred.predict() or -1.0

        def _lidar_spin() -> Action:
            left_m  = (1.0 - float(np.max(lidar[2:6])))   * self.cfg.LIDAR_MAX_RANGE
            right_m = (1.0 - float(np.max(lidar[10:14]))) * self.cfg.LIDAR_MAX_RANGE
            return Action.SPIN_LEFT if left_m >= right_m else Action.SPIN_RIGHT

        def _lidar_turn() -> Action:
            left_m  = (1.0 - float(np.max(lidar[2:6])))   * self.cfg.LIDAR_MAX_RANGE
            right_m = (1.0 - float(np.max(lidar[10:14]))) * self.cfg.LIDAR_MAX_RANGE
            return Action.TURN_LEFT if left_m >= right_m else Action.TURN_RIGHT

        # 1. BUMPER FRONT
        if bumper_front == 1 and self._bump_cd == 0:
            if self._bump_rev == 0:
                cands = {'R': occ['R'], 'B': occ['B'], 'L': occ['L']}
                tgt = min(cands, key=cands.__getitem__)
                left_m  = (1.0 - float(np.max(lidar[2:6])))   * self.cfg.LIDAR_MAX_RANGE
                right_m = (1.0 - float(np.max(lidar[10:14]))) * self.cfg.LIDAR_MAX_RANGE
                if tgt == 'L':   self._bump_act = Action.SPIN_LEFT
                elif tgt == 'R': self._bump_act = Action.SPIN_RIGHT
                else:            self._bump_act = Action.SPIN_LEFT if left_m >= right_m else Action.SPIN_RIGHT
                self._bump_spin       = self._cycles(tgt)
                self._bump_spin_total = self._bump_spin
            self._bump_rev = self.cfg.BUMPER_REVERSE_CYCLES
            self._rear_fwd = 0; self._reflex_rem = 0
            return Action.REVERSE, "BUMPER_HIT"

        if self._bump_cd > 0: self._bump_cd -= 1

        if self._bump_rev > 0:
            self._bump_rev -= 1
            return Action.REVERSE, "BUMPER_REV"

        if self._bump_spin > 0:
            front_clear_m = (1.0 - float(np.mean(lidar[[14, 15, 0, 1]]))) * self.cfg.LIDAR_MAX_RANGE
            done_so_far = self._bump_spin_total - self._bump_spin
            min_done    = done_so_far >= max(self.cfg.BUMPER_SPIN_OVERHEAD, self._bump_spin_total // 3)
            if min_done and lidar_min > 0.45 and front_clear_m > 0.60:
                self._bump_spin = 0
                self._bump_cd   = self.cfg.BUMPER_COOLDOWN
            else:
                self._bump_spin -= 1
                if self._bump_spin == 0: self._bump_cd = self.cfg.BUMPER_COOLDOWN
                return self._bump_act or Action.SPIN_LEFT, "BUMPER_SPIN"

        # 2. HARD SAFETY
        ds_mod = self.cfg.DSCROLL_SAFETY_BETA * double_scroll_x
        base = max(0.06, min(0.30, self.cfg.LIDAR_HARD_SAFETY_MIN + ds_mod * self.cfg.SAFETY_DYNAMIC_RANGE))

        if eff_min < 0.30:
            self._rear_fwd = 0; self._reflex_rem = 0; self._side_cd = 0
            self._hs_consecutive += 1

            pp_thresh = getattr(self.cfg, 'HARD_SAFETY_PINGPONG_THRESH', 20)

            if self._hs_escape_rem > 0:
                self._hs_escape_rem -= 1
                esc_mode = getattr(self, '_hs_escape_mode', 'SPIN')

                if esc_mode == 'FORWARD':
                    return Action.FORWARD, "HARD_SAFETY"
                elif esc_mode == 'REVERSE':
                    back_occ  = float(lidar[8]) if len(lidar) > 8 else 0.5
                    back_dist = (1.0 - back_occ) * self.cfg.LIDAR_MAX_RANGE
                    if back_dist >= 0.45:
                        return Action.REVERSE, "HARD_SAFETY"
                    esc_mode = 'SPIN'
                    self._hs_escape_mode = 'SPIN'

                if esc_mode == 'SPIN':
                    return (_lidar_spin() if best in ('F','B')
                            else self._spin_to(best, us_left, us_right)), "HARD_SAFETY"

            if self._hs_consecutive >= pp_thresh:
                self._hs_consecutive = 0
                front_occ = float(lidar[0]) if len(lidar) > 0 else 0.5
                back_occ  = float(lidar[8]) if len(lidar) > 8 else 0.5
                front_dist = (1.0 - front_occ) * self.cfg.LIDAR_MAX_RANGE
                back_dist  = (1.0 - back_occ)  * self.cfg.LIDAR_MAX_RANGE
                esc_steps = getattr(self.cfg, 'HARD_SAFETY_ESCAPE_STEPS', 40)
                if front_dist > 1.0:
                    self._hs_escape_mode = 'FORWARD'
                elif back_dist >= 0.45:
                    self._hs_escape_mode = 'REVERSE'
                else:
                    self._hs_escape_mode = 'SPIN'
                self._hs_escape_rem = esc_steps
                if self._hs_escape_mode == 'FORWARD':
                    return Action.FORWARD, "HARD_SAFETY"
                elif self._hs_escape_mode == 'REVERSE':
                    return Action.REVERSE, "HARD_SAFETY"
                else:
                    return (_lidar_spin() if best in ('F','B')
                            else self._spin_to(best, us_left, us_right)), "HARD_SAFETY"

            if best in ('F', 'B'):
                return _lidar_spin(), "HARD_SAFETY"
            return self._spin_to(best, us_left, us_right), "HARD_SAFETY"

        else:
            self._hs_consecutive   = 0
            self._hs_min_dist_best = 3.0
            self._hs_escape_rem    = 0
            self._hs_escape_mode   = 'SPIN'

        if eff_min < self.cfg.SAFETY_SLOW_DOWN_DIST:
            if occ['F'] > 0.50 and best in ('L', 'R'):
                return self._spin_to(best, us_left, us_right), "SLOW_DOWN"

        thresh_front = max(self.cfg.EMERGENCY_MIN, base)
        thresh_side  = max(self.cfg.EMERGENCY_MIN, base * self.cfg.SAFETY_SIDE_MULT)

        front_occ_raw = float(np.mean(lidar[[14, 15, 0, 1]]))
        front_dist_m  = (1.0 - front_occ_raw) * self.cfg.LIDAR_MAX_RANGE
        front_dist_m  = min(front_dist_m, eff_min) if eff_min < lidar_min else front_dist_m

        tof_alarm_left  = tof_left  < thresh_side * 1.5 and tof_left  > 0.02
        tof_alarm_right = tof_right < thresh_side * 1.5 and tof_right > 0.02
        if tof_alarm_right and not tof_alarm_left:
            return Action.TURN_LEFT,  "TOF_AVOID"
        if tof_alarm_left and not tof_alarm_right:
            return Action.TURN_RIGHT, "TOF_AVOID"

        if front_dist_m < thresh_front:
            self._rear_fwd = 0; self._reflex_rem = 0; self._side_cd = 0
            if best == 'F':
                return _lidar_turn(), "HARD_SAFETY"
            return self._spin_to(best, us_left, us_right), "HARD_SAFETY"

        if self._side_cd > 0: self._side_cd -= 1

        right_dist_m = sp['dist_min']['R']
        left_dist_m  = sp['dist_min']['L']
        if self._side_cd == 0:
            hyst = self.cfg.SIDE_SAFETY_HYST
            if right_dist_m < thresh_side and right_dist_m < left_dist_m * hyst:
                self._rear_fwd = 0; self._reflex_rem = 0; self._side_cd = self.cfg.SIDE_SAFETY_CD
                return Action.TURN_LEFT, "SIDE_SAFETY"
            elif left_dist_m < thresh_side and left_dist_m < right_dist_m * hyst:
                self._rear_fwd = 0; self._reflex_rem = 0; self._side_cd = self.cfg.SIDE_SAFETY_CD
                return Action.TURN_RIGHT, "SIDE_SAFETY"

        # 3. BUMPER REAR
        if rear_bumper == 1:
            self._reflex_rem = 0
            if occ['F'] < 0.5:
                self._rear_fwd = self.cfg.REAR_BUMPER_FORWARD_CYCLES
                return Action.FORWARD, "REAR_BUMPER"
            spin = _lidar_spin()
            self._reflex_act = spin; self._reflex_rem = self.cfg.HARD_REFLEX_HOLD_CYCLES
            return spin, "REAR_BUMPER"

        if self._rear_fwd > 0:
            if occ['F'] > 0.5: self._rear_fwd = 0
            else:
                self._rear_fwd -= 1
                return Action.FORWARD, "REAR_FWD"

        # 4. NAWIGACJA CIĄGŁA
        front_occ = occ['F']
        us_diff = us_left - us_right
        lr_diff = dist['L'] - dist['R']
        steer = us_diff * 0.55 + lr_diff * 0.45

        if front_occ > 0.900:   # było 0.833 – zbyt agresywne w korytarzach
            if best in ('L', 'R', 'B'):
                return self._spin_to(best, us_left, us_right), "SPATIAL_SPIN"
        elif front_occ > 0.760: # było 0.667
            if abs(steer) > 0.08:
                return (Action.TURN_LEFT if steer > 0 else Action.TURN_RIGHT), "SPATIAL_TURN"
            if best == 'L': return Action.TURN_LEFT,  "SPATIAL_TURN"
            if best == 'R': return Action.TURN_RIGHT, "SPATIAL_TURN"
        elif front_occ > 0.400:
            us_min_sensor = min(us_left, us_right)
            if us_min_sensor < 0.80:
                if us_diff > 0.15:  return Action.TURN_LEFT,  "US_CORR"
                if us_diff < -0.15: return Action.TURN_RIGHT, "US_CORR"

        # 5. Anti-stall
        enc_zero = (encoder_l == 0 and encoder_r == 0)
        if enc_zero and self.cfg.PWM_MAX > 40:
            self._stall_active = True
            self._stall_rem    = self.cfg.HARD_REFLEX_HOLD_CYCLES
            return None, "ANTI_STALL"

        self._reflex_act = None
        return None, ""


# =============================================================================
# FREE SPACE INSTINCT
# =============================================================================

class FreeSpaceInstinct:
    def __init__(self, cfg: SwarmConfig): self.cfg = cfg

    def compute(self, lidar_16: np.ndarray) -> Tuple[float, float]:
        free = 1.0 - lidar_16
        angs = np.arange(16) * (2.0 * math.pi / 16.0)
        xs = float(np.sum(free * np.cos(angs))); ys = float(np.sum(free * np.sin(angs)))
        mag = math.sqrt(xs**2 + ys**2) / 16.0
        if mag < 0.05: return 0.0, 0.85
        return math.atan2(ys, xs), mag

    def bias(self, angle, mag, front_clearance, us_left, us_right, sector_0_occ):
        b: Dict[Action, float] = {a: 0.0 for a in Action}
        w = self.cfg.INSTINCT_WEIGHT; bon = self.cfg.INSTINCT_FORWARD_BONUS
        fwd_align  = math.cos(angle); side_align = abs(math.sin(angle))
        us_min = min(us_left, us_right)

        if front_clearance > 0.55 and fwd_align > 0.1 and us_min > 0.15:
            sc = (front_clearance - 0.55) / 0.45
            b[Action.FORWARD]         += bon * sc * max(0.0, fwd_align) * 0.7
            b[Action.REVERSE]         -= bon * 0.5 * max(0.0, fwd_align)
            b[Action.SPIN_LEFT]       -= bon * 0.3; b[Action.SPIN_RIGHT]      -= bon * 0.3
            b[Action.ESCAPE_MANEUVER] -= bon * 0.4
        elif front_clearance < 0.45 or sector_0_occ > 0.35:
            blk = max(sector_0_occ, 1.0 - front_clearance)
            b[Action.FORWARD] -= bon * blk * 1.2
            prox = max(0.0, 1.0 - front_clearance / 0.6)
            push = sector_0_occ * w * 2.0 * (1.0 + prox * 2.5)
            if us_left >= us_right:
                b[Action.TURN_LEFT]  += push * 1.8; b[Action.SPIN_LEFT]  += push * 0.9
            else:
                b[Action.TURN_RIGHT] += push * 1.8; b[Action.SPIN_RIGHT] += push * 0.9

        if mag > 0.12:
            tw = w * mag * side_align
            if math.pi/6 < angle < 5*math.pi/6:
                b[Action.TURN_LEFT]  += tw * 1.8; b[Action.SPIN_LEFT]  += tw * 0.5
            if -5*math.pi/6 < angle < -math.pi/6:
                b[Action.TURN_RIGHT] += tw * 1.8; b[Action.SPIN_RIGHT] += tw * 0.5
            if abs(angle) > 3*math.pi/4:
                b[Action.SPIN_LEFT]  += w * mag;  b[Action.SPIN_RIGHT]  += w * mag

        if fwd_align > -0.3 and front_clearance > 0.3:
            b[Action.REVERSE]         -= w * self.cfg.INSTINCT_REVERSE_PENALTY
            b[Action.ESCAPE_MANEUVER] -= w * 0.25
        return b


# =============================================================================
# ANTI-STAGNATION / ANTI-OSCILLATION
# =============================================================================

class AntiStagnation:
    _REVERSE_PHASE = 12
    _SPIN_PHASE    = 22

    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg
        self.hist:      deque = deque(maxlen=cfg.STAGNATION_WINDOW)
        self._pos_hist: deque = deque(maxlen=cfg.STAGNATION_WINDOW)
        self.stuck    = False
        self.force    = 0
        self._phase   = 0
        self._phase_rem = 0
        self.dir      = 1
        self.count    = 0
        self.cooldown = 0
        self._real_stuck_ctr: int = 0

    def update(self, x: float, y: float, pwm: float, action,
               min_dist: float = 3.0, bumper_front: bool = False,
               lidar_front: float = 3.0):
        if self.cooldown > 0:
            self.cooldown -= 1
            return

        self._pos_hist.append((x, y))

        spinning = action in (Action.SPIN_LEFT, Action.SPIN_RIGHT,
                              Action.TURN_LEFT, Action.TURN_RIGHT,
                              Action.ESCAPE_MANEUVER)
        if not spinning:
            self.hist.append((x, y))

        if bumper_front and min_dist < self.cfg.LIDAR_HARD_SAFETY_MIN:
            self._real_stuck_ctr += 1
        else:
            self._real_stuck_ctr = max(0, self._real_stuck_ctr - 1)

        if (self._real_stuck_ctr >= self.cfg.STAGNATION_OPEN_GUARD
                and self.force <= 0):
            self._real_stuck_ctr = 0
            self.count += 1; self.dir *= -1
            self._phase = 2; self._phase_rem = self._SPIN_PHASE
            self.force  = self._SPIN_PHASE
            self.stuck  = True
            self.hist.clear(); self._pos_hist.clear()
            self.cooldown = self.cfg.STAGNATION_COOLDOWN
            return

        if self.force > 0 or len(self.hist) < self.cfg.STAGNATION_WINDOW:
            if self.force <= 0:
                self.stuck = False
            return

        pts = np.array(list(self.hist), dtype=np.float32)
        var = float(np.var(pts, axis=0).sum())
        diffs = np.diff(pts, axis=0)
        cum_path = float(np.hypot(diffs[:, 0], diffs[:, 1]).sum())

        front_clear = lidar_front > self.cfg.STAGNATION_FRONT_MIN
        is_moving = cum_path > self.cfg.STAGNATION_CUM_MIN
        truly_stuck_var = var < self.cfg.STAGNATION_VAR_MIN

        was = self.stuck
        if front_clear and is_moving:
            self.stuck = False
        elif front_clear and not truly_stuck_var:
            self.stuck = False
        else:
            self.stuck = (var < self.cfg.STAGNATION_THRESHOLD and pwm > 15)

        if self.stuck and not was:
            self.count += 1; self.dir *= -1
            self._phase     = 1; self._phase_rem = self._REVERSE_PHASE
            self.force      = self._REVERSE_PHASE + self._SPIN_PHASE
            self.hist.clear(); self._pos_hist.clear()
            self.cooldown = self.cfg.STAGNATION_COOLDOWN

    def next(self) -> Optional[Action]:
        if self.force <= 0:
            self._phase = 0
            return None
        self.force      -= 1
        self._phase_rem -= 1
        if self._phase == 1 and self._phase_rem <= 0:
            self._phase = 2; self._phase_rem = self._SPIN_PHASE
        if self._phase == 1:
            return Action.REVERSE
        if self._phase == 2:
            if self.dir > 0:
                return Action.SPIN_LEFT  if self.count % 2 == 1 else Action.TURN_LEFT
            return Action.SPIN_RIGHT if self.count % 2 == 1 else Action.TURN_RIGHT
        return None


class AntiOscillation:
    _PAIRS = [
        frozenset({Action.TURN_LEFT,  Action.TURN_RIGHT}),
        frozenset({Action.SPIN_LEFT,  Action.SPIN_RIGHT}),
        frozenset({Action.TURN_LEFT,  Action.SPIN_RIGHT}),
        frozenset({Action.TURN_RIGHT, Action.SPIN_LEFT}),
    ]
    def __init__(self, cfg: SwarmConfig):
        self.cfg = cfg; self.hist: deque = deque(maxlen=cfg.OSC_WINDOW)

    def update(self, action: Action): self.hist.append(action)

    def penalties(self) -> Dict[Action, float]:
        h = list(self.hist)
        if len(h) < 4: return {}
        alts = sum(1 for i in range(1, len(h)) if frozenset({h[i], h[i-1]}) in self._PAIRS)
        if alts < len(h) // 2: return {}
        recent = set(h[-4:])
        return {a: -self.cfg.OSC_PENALTY for a in recent
                if a in (Action.TURN_LEFT, Action.TURN_RIGHT, Action.SPIN_LEFT, Action.SPIN_RIGHT)}


# =============================================================================
# GŁÓWNY MÓZG FAST
# =============================================================================

class SwarmFastBrain:
    """
    Interfejs publiczny:
      loop(sensor_data, dt) → (pwm_l, pwm_r, action, source, diagnostics)
      save() / load()
    """
    def __init__(self, cfg: Optional[SwarmConfig] = None):
        self.cfg     = cfg or SwarmConfig()
        self.step    = 0
        self.lr      = self.cfg.LR
        self.epsilon = self.cfg.EPSILON

        self.lorenz        = LorenzAttractor(self.cfg)
        self.rossler       = RosslerAttractor()
        self.double_scroll = DoubleScrollAttractor()
        self.dscroll       = self.double_scroll
        self.reservoir     = ReservoirReadout(k=12, c_dim=8)
        self._cur_lorenz_x = 0.0

        self.predictor_net = LidarPredictorNet(
            k=self.cfg.PREDICTOR_K,
            hidden1=getattr(self.cfg, 'PREDICTOR_H1', 52),
            hidden2=getattr(self.cfg, 'PREDICTOR_H2', 32),
            hidden3=getattr(self.cfg, 'PREDICTOR_H3', 16),
            horizon=getattr(self.cfg, 'PREDICTOR_HORIZON', 4),
            lr=self.cfg.PREDICTOR_LR,
            beta=getattr(self.cfg, 'LORENZ_BETA', 0.2),
        )

        self.features   = FeatureExtractor(self.cfg)
        self.normalizer = RunningNormalizer(self.cfg.FEATURE_DIM)
        self.brain      = NeuralBrain(self.cfg)
        self.safety     = SafetyLayer(self.cfg)
        self.instinct   = FreeSpaceInstinct(self.cfg)
        self.anti_stag  = AntiStagnation(self.cfg)
        self.anti_osc   = AntiOscillation(self.cfg)
        self.replay     = ReplayBuffer(self.cfg.REPLAY_CAPACITY)
        self.avoidance  = AvoidanceBuffer(self.cfg)

        from swarm_slow import ImpulseBiasController
        self.cc = ImpulseBiasController()

        self.last_action: Optional[Action] = None
        self.last_source: str = ""
        self._prev_features: Optional[np.ndarray] = None
        self._pwm_l = 0.0; self._pwm_r = 0.0
        self.last_reward: float = 0.0
        self._prev_pwm_l = 0.0; self._prev_pwm_r = 0.0
        self._neural_steer_ctr: int = 0

        self.arousal         = 0.3
        self.stress          = 0.1
        self.plasticity      = 0.5
        self._baseline_rew   = 0.0
        self.x = 0.0; self.y = 0.0

        # [v1.3.7 – lifelong learning] Automatyczne wczytywanie
        brain_loaded = False
        predictor_loaded = False

        if not getattr(self.cfg, 'FORCE_NEW_BRAIN', False):
            brain_loaded = self.load()

        if self.cfg.USE_LIDAR_PREDICTOR and not getattr(self.cfg, 'FORCE_NEW_PREDICTOR', False):
            predictor_loaded = self.predictor_net.load(self.cfg.PREDICTOR_FILE)

        if brain_loaded:
            print(f"[FAST] Wczytano {self.cfg.BRAIN_FILE} (krok {self.step})")
        else:
            print("[FAST] Brain startuje od losowych wag")

        if self.cfg.USE_LIDAR_PREDICTOR:
            if predictor_loaded:
                print(f"[FAST] Wczytano {self.cfg.PREDICTOR_FILE} (MAE={self.predictor_net.mae:.4f}, "
                      f"kroki={self.predictor_net._trained_steps})")
            else:
                print("[FAST] Predyktor startuje od losowych wag")

    # ------------------------------------------------------------------
    def _parse(self, sd: Dict[str, Any]) -> Dict[str, Any]:
        if 'lidar_points' in sd and 'lidar_0' not in sd:
            pts = sd['lidar_points']
            MAX = self.cfg.LIDAR_MAX_RANGE
            sec: Dict[int, float] = {}
            for ang, dist in pts:
                if 0 < dist <= MAX:
                    i = int((float(ang) % 360) / 22.5) % 16
                    if i not in sec or dist < sec[i]: sec[i] = dist
            for i in range(16):
                d = sec.get(i, MAX)
                sd[f'lidar_{i}'] = max(0.0, min(1.0, 1.0 - d / MAX))
            sd.setdefault('min_dist', float(min(sec.values(), default=MAX)))
        if 'us_left' not in sd:
            sd['us_left']  = float(sd.get('us_left_dist',  3.0))
            sd['us_right'] = float(sd.get('us_right_dist', 3.0))
        return sd

    # ------------------------------------------------------------------
    def _pwm(self, action: Action, bypass: bool = False) -> Tuple[float, float]:
        pl, pr = PWM_TABLE.get(action, (0.0, 0.0))
        if bypass: self._pwm_l, self._pwm_r = float(pl), float(pr)
        return float(pl), float(pr)

    def _apply_slew(self, target_l: float, target_r: float) -> Tuple[float, float]:
        slew = self.cfg.PWM_SLEW_RATE
        self._pwm_l += float(np.clip(target_l - self._pwm_l, -slew, slew))
        self._pwm_r += float(np.clip(target_r - self._pwm_r, -slew, slew))
        return self._pwm_l, self._pwm_r

    # ------------------------------------------------------------------
    def _reward(self, sd: Dict, action: Action) -> float:
        bf  = int(sd.get('bumper_front', 0))
        rb  = int(sd.get('rear_bumper',  0))
        el  = float(sd.get('encoder_l',  0.0))
        er  = float(sd.get('encoder_r',  0.0))
        spd = (abs(el) + abs(er)) / 2.0

        is_forced = self.last_source in (
            'HARD_SAFETY', 'BUMPER_HIT', 'BUMPER_REV', 'BUMPER_SPIN',
            'ANTI_STALL', 'STAGNATION',
        )
        if bf == 1:
            return -0.5 if is_forced else -5.0
        if rb == 1:
            return -0.5 if is_forced else -3.0

        if action == Action.FORWARD:                           base = 0.5 + spd
        elif action in (Action.TURN_LEFT, Action.TURN_RIGHT): base = 0.2
        elif action in (Action.SPIN_LEFT, Action.SPIN_RIGHT): base = 0.1
        elif action == Action.REVERSE:
            ok = self.last_source in ('BUMPER_HIT','BUMPER_REV','BUMPER_SPIN',
                                      'HARD_SAFETY','STAGNATION')
            base = 0.3 if ok else -0.8
        else:
            base = 0.0

        if action == Action.FORWARD and self.cfg.USE_LIDAR_PREDICTOR:
            pred_conf = float(sd.get('pred_conf_internal', 0.0))
            if pred_conf > 0.4:
                base += 0.15 * pred_conf

        if action != Action.STOP:
            dl = abs(self._pwm_l - self._prev_pwm_l)
            dr = abs(self._pwm_r - self._prev_pwm_r)
            max_jump = max(dl, dr)
            thr = self.cfg.SMOOTH_JUMP_THRESHOLD
            if max_jump > thr:
                excess = (max_jump - thr) / 10.0
                base  += -self.cfg.SMOOTH_PENALTY_SCALE * (excess ** 2)

        return base

    # ------------------------------------------------------------------
    def _update_hormones(self, reward: float, is_collision: bool) -> None:
        alpha_a = 0.02; beta_a = 0.01
        alpha_s = 0.03; beta_s = 0.005

        self._baseline_rew = 0.99 * self._baseline_rew + 0.01 * reward
        delta_a = reward - self._baseline_rew
        self.arousal = float(np.clip(
            self.arousal + alpha_a * delta_a - beta_a * self.arousal, 0.0, 1.0))

        penalty = 1.0 if is_collision else max(0.0, -reward * 0.5)
        self.stress = float(np.clip(
            self.stress + alpha_s * penalty - beta_s * self.stress, 0.0, 1.0))

        arg = -5.0 * (self.arousal - 0.5) + 3.0 * (self.stress - 0.2)
        self.plasticity = float(1.0 / (1.0 + math.exp(max(-30.0, min(30.0, arg)))))

        self.brain.lr    = self.cfg.NN_LR    * (0.5 + 1.5 * self.plasticity)
        self.epsilon = max(self.cfg.EPSILON_MIN,
                           self.epsilon * (1.0 + 0.1 * (self.arousal - 0.5)))
        self.epsilon = min(0.5, self.epsilon)

    # ------------------------------------------------------------------
    # Kalibracja atraktorów na podstawie geometrii otoczenia
    # ------------------------------------------------------------------

    def calibrate_attractors(self, env, cfg, rotations: int = 2) -> None:
        """
        Obraca robotem w miejscu, zbiera LIDAR + US + ToF,
        tworzy zagęszczony profil odległości i ustawia stany atraktorów.

        Parametry:
          env      – środowisko (ArenaEnv lub _HeadlessSim) z metodą step()
          cfg      – SwarmConfig z polem LIDAR_MAX_RANGE
          rotations – liczba pełnych obrotów (domyślnie 2)
        """
        LIDAR_ANGLES    = np.arange(0.0, 360.0, 22.5)   # 16 sektorów LIDAR
        US_LEFT_ANGLE   = 18.0
        US_RIGHT_ANGLE  = -18.0
        TOF_LEFT_ANGLE  = 30.0
        TOF_RIGHT_ANGLE = -30.0

        MAX_RANGE = getattr(cfg, 'LIDAR_MAX_RANGE', 3.0)

        # Rzeczywisty kąt obrotu na krok przy PWM=(-30,+30), dt=0.063:
        #   w = (v_R - v_L) / WB = (0.30*0.75 - (-0.30*0.75)) / 0.28 = 1.607 rad/s
        #   kąt/krok = w * dt * (180/π) ≈ 5.81° → 1 obrót ≈ 62 kroki
        _WB       = getattr(cfg, 'WHEEL_BASE',     0.28)
        _MAX_SPD  = getattr(cfg, 'MAX_SPEED_MPS',  0.75)
        _PWM_SPIN = 30.0   # PWM użyte poniżej w env.step(-30, 30)
        _DT_CALIB = 0.063
        _omega    = (2.0 * (_PWM_SPIN / 100.0) * _MAX_SPD) / _WB   # rad/s
        _deg_per_step = math.degrees(_omega * _DT_CALIB)            # ~5.81°
        steps = max(8, round(rotations * 360.0 / _deg_per_step))

        # Zbieramy surowe punkty (kąt_globalny, odległość_m)
        points: List[Tuple[float, float]] = []

        for i in range(steps):
            try:
                sensors = env.step(-30, 30, dt=0.063)   # wolny SPIN_LEFT
            except Exception:
                break

            lidar_16 = np.array([sensors.get(f'lidar_{j}', 0.0) for j in range(16)])
            lidar_m  = (1.0 - lidar_16) * MAX_RANGE

            us_l  = sensors.get('us_left',   3.0)
            us_r  = sensors.get('us_right',  3.0)
            tof_l = sensors.get('tof_left',  us_l)
            tof_r = sensors.get('tof_right', us_r)

            theta_global = i * _deg_per_step    # rzeczywisty kąt z kinematyki

            # Punkty z LIDAR
            for j, ang in enumerate(LIDAR_ANGLES):
                points.append(((theta_global + ang) % 360.0, float(lidar_m[j])))

            # Punkty z US i ToF
            for loc_ang, dist in [
                (US_LEFT_ANGLE,   us_l),
                (US_RIGHT_ANGLE,  us_r),
                (TOF_LEFT_ANGLE,  tof_l),
                (TOF_RIGHT_ANGLE, tof_r),
            ]:
                points.append(((theta_global + loc_ang) % 360.0, float(dist)))

        if len(points) < 4:
            print("[CALIB] Za mało danych – pomijam kalibrację atraktorów")
            return

        # Sortowanie po kącie
        pts_ang  = np.array([p[0] for p in points])
        pts_dist = np.array([p[1] for p in points])
        sort_idx = np.argsort(pts_ang)
        pts_ang  = pts_ang[sort_idx]
        pts_dist = pts_dist[sort_idx]

        # Rozszerzenie o zawinięcie 360°→0°
        ang_ext  = np.concatenate([pts_ang,  [pts_ang[0]  + 360.0]])
        dist_ext = np.concatenate([pts_dist, [pts_dist[0]]])

        # Interpolacja na gęstą siatkę 36 punktów (co 10°)
        N_DENSE      = 36
        dense_angles = np.linspace(0.0, 360.0, N_DENSE, endpoint=False)
        dense_dists  = np.zeros(N_DENSE)

        for k, target in enumerate(dense_angles):
            idx = np.searchsorted(ang_ext, target)
            if idx == 0:
                dense_dists[k] = dist_ext[0]
                continue
            a0, a1 = ang_ext[idx - 1], ang_ext[idx]
            d0, d1 = dist_ext[idx - 1], dist_ext[idx]
            t = (target - a0) / (a1 - a0) if a1 != a0 else 0.0
            dense_dists[k] = d0 + (d1 - d0) * t

        # Statystyki środowiska
        mean_dist = float(np.mean(dense_dists))
        var_dist  = float(np.var(dense_dists))
        min_dist  = float(np.min(dense_dists))

        # ---- Atraktor Lorenza (złożoność otoczenia → gain) ----
        complexity = float(np.clip(var_dist / (mean_dist + 0.1), 0.0, 2.0))
        self.lorenz.x = 1.0 + complexity * 18.0
        self.lorenz.y = 1.0
        self.lorenz.z = 1.0 + complexity * 10.0

        # ---- Atraktor Rösslera (zatłoczenie → eksploracja) ----
        crowding = 1.0 - min_dist / 3.0
        self.rossler.x = -5.0 - crowding * 10.0
        self.rossler.y =  0.0
        self.rossler.z =  0.02 + crowding * 0.5

        # ---- DoubleScroll (zagrożenie → czułość progów) ----
        danger = float(np.clip(1.0 - mean_dist / 3.0, 0.0, 1.0))

        # Synchronizacja _xn – __init__ robi 2000 kroków rozgrzewki które nadpisują _xn.
        # DoubleScroll celowo POMINIĘTY w pętli sync – BOOST ustawiamy dopiero po niej,
        # żeby cykl BOOST→RELEASE→IDLE nie został skonsumowany przez te kroki.
        for _ in range(10):
            self.lorenz.step()
            self.rossler.step()

        # DoubleScroll: ustawiamy BOOST PO synchronizacji – trafia bezpośrednio do pętli głównej.
        # Tryb BOOST gwarantuje że amplituda nie zostanie natychmiast nadpisana przez gałąź IDLE.
        if danger > 0.6:
            self.double_scroll.mode = 'BOOST'
            self.double_scroll.boost_counter = max(4, int(danger * 8))
        elif danger > 0.3:
            self.double_scroll.mode = 'BOOST'
            self.double_scroll.boost_counter = 3
        # danger <= 0.3 – zostaw IDLE z domyślną amplitudą

        print(f"[CALIB] Otoczenie: mean={mean_dist:.2f}m, min={min_dist:.2f}m, "
              f"var={var_dist:.3f}, complexity={complexity:.2f}")
        print(f"[CALIB] Atraktory po kalibracji: "
              f"lorenz_xn={self.lorenz.x_norm:.4f}, "
              f"rossler_xn={self.rossler.x_norm:.4f}, "
              f"dscroll_amp={self.double_scroll.current_amplitude:.3f}")

    def loop(self, sensor_data: Dict[str, Any], dt: float = 0.033,
             pos: Optional[Tuple[float, float]] = None,
             lorenz_x: float = 0.0, lorenz_z: float = 0.0,
             rossler_x: float = 0.0, rossler_y: float = 0.0,
             dscroll_x: float = 0.0,
             slow_action: Optional[Action] = None,
             slow_conf: float = 0.0,
             ) -> Tuple[float, float, Action, str, Dict]:

        self.step += 1
        self._cur_lorenz_x = lorenz_x
        self.lorenz.step(); self.rossler.step(); self.double_scroll.step()
        self.reservoir.push(self.lorenz, self.rossler, self.double_scroll)

        sd = self._parse(sensor_data)
        if pos: self.x, self.y = pos

        lidar_16  = np.array([sd.get(f'lidar_{i}', 0.0) for i in range(16)], dtype=np.float32)
        us_left   = float(sd.get('us_left',    3.0))
        us_right  = float(sd.get('us_right',   3.0))
        encoder_l = float(sd.get('encoder_l',  0.0))
        encoder_r = float(sd.get('encoder_r',  0.0))
        bumper_f  = int(sd.get('bumper_front',  0))
        bumper_r  = int(sd.get('rear_bumper',   0))
        lidar_min = float(sd.get('min_dist',    3.0))
        tof_left  = float(sd.get('tof_left',   3.0))
        tof_right = float(sd.get('tof_right',  3.0))

        if self.step > 1:
            self.predictor_net.update_actual(lidar_min)

        self.predictor_net.push(lidar_min,
                                self.lorenz.x_norm, self.lorenz.z_norm,
                                self.rossler.x_norm,
                                self.double_scroll.modulated_x_norm)

        pred_vec = None
        pred_conf = 0.0
        pred_min_feat = lidar_min
        pred_far_feat = lidar_min
        trend = 0.0
        neural_pred_for_safety = -1.0

        if self.cfg.USE_LIDAR_PREDICTOR:
            pred_vec = self.predictor_net.predict_next()
            if pred_vec is not None:
                pred_conf = self.predictor_net.confidence
                pred_min_feat = float(pred_vec[0])
                pred_far_feat = float(pred_vec[-1])
                trend = pred_far_feat - pred_min_feat
                neural_pred_for_safety = float(np.min(pred_vec))

        # Dynamiczny BOOST – neural_pred_for_safety już poprawnie zainicjalizowany powyżej
        if lidar_min < 0.55:
            tof_min = min(
                tof_left  if tof_left  > 0.02 else 3.0,
                tof_right if tof_right > 0.02 else 3.0,
            )
            lin_pred = self.safety._lin_pred.pessimistic(lidar_min)
            if neural_pred_for_safety >= 0.0:
                eff_min = min(lidar_min, neural_pred_for_safety, lin_pred, tof_min)
            else:
                eff_min = min(lidar_min, lin_pred, tof_min)
            cycles = self.safety.compute_boost_cycles(eff_min)
            if cycles > 0:
                self.double_scroll.request_boost(cycles)

        sd['pred_conf_internal'] = pred_conf

        free_angle, free_mag = self.instinct.compute(lidar_16)
        rc_context = self.reservoir.read()
        feats = self.features.extract(
            lidar_16, us_left, us_right, encoder_l, encoder_r,
            self.lorenz.x_norm, self.lorenz.z_norm,
            bumper_r, lidar_min,
            self.last_action, free_angle, free_mag,
            self.rossler.x_norm, self.double_scroll.modulated_x_norm,
            rc_context, slow_action,
            predicted_min=pred_min_feat,
            predicted_far=pred_far_feat,
            trend=trend,
            predictor_conf=pred_conf,
        )
        self.normalizer.update(feats)
        norm_feats = self.normalizer.normalize(feats)

        avg_pwm = (abs(self._pwm_l) + abs(self._pwm_r)) / 2.0
        lidar_front_m = (1.0 - float(lidar_16[0])) * self.cfg.LIDAR_MAX_RANGE
        self.anti_stag.update(self.x, self.y, avg_pwm, self.last_action,
                              min_dist=lidar_min, bumper_front=bool(bumper_f),
                              lidar_front=lidar_front_m)
        stag_force = self.anti_stag.next()

        _HARD_SRCS = frozenset({
            'BUMPER_HIT','BUMPER_REV','BUMPER_SPIN',
            'HARD_SAFETY','REAR_BUMPER','REAR_FWD','TOF_AVOID'
        })
        safety_act, safety_src = self.safety.check(
            lidar_16, lidar_min, us_left, us_right,
            encoder_l, encoder_r, bumper_f, bumper_r,
            self.double_scroll.modulated_x_norm,
            neural_pred_min=neural_pred_for_safety,
            tof_left=tof_left, tof_right=tof_right,
        )

        self._neural_steer_ctr = max(0, self._neural_steer_ctr - 1)

        _stag_rev_active = (stag_force == Action.REVERSE)
        _stag_overrides_soft = _stag_rev_active and (
            safety_act is not None and safety_src not in _HARD_SRCS
        )

        if safety_act is not None and not _stag_overrides_soft:
            _hard_bypass = safety_src in _HARD_SRCS
            # ANTI_STALL z check() zwraca zawsze (None, "ANTI_STALL") – safety_act is None,
            # więc zewnętrzny warunek go i tak odfiltruje. Brak osobnej gałęzi.
            raw_l, raw_r = self._pwm(safety_act, bypass=_hard_bypass)
            if not _hard_bypass: pwm_l, pwm_r = self._apply_slew(raw_l, raw_r)
            else:                pwm_l, pwm_r = raw_l, raw_r
            self._finish(norm_feats, safety_act, sd, safety_src, bumper_f)
            return pwm_l, pwm_r, safety_act, safety_src, self._diag(lidar_16, us_left, us_right)

        if stag_force is not None:
            dyn_l, dyn_r = self.brain.get_dynamic_pwm(stag_force, self.cfg.PWM_MAX)
            tab_l, tab_r = self._pwm(stag_force)
            if abs(dyn_l) > 5.0 or abs(dyn_r) > 5.0:
                raw_l, raw_r = dyn_l, dyn_r
            else:
                raw_l, raw_r = tab_l, tab_r
            pwm_l, pwm_r = self._apply_slew(raw_l, raw_r)
            self._finish(norm_feats, stag_force, sd, "STAGNATION", bumper_f)
            return pwm_l, pwm_r, stag_force, "STAGNATION", self._diag(lidar_16, us_left, us_right)

        q  = self.brain.forward(norm_feats, self.lorenz.x_norm, self.rossler.x_norm)
        av = self.brain.avoidance()

        front_secs  = lidar_16[[14, 15, 0, 1]]
        front_clear = 1.0 - float(np.max(front_secs))
        sector0_occ = float(lidar_16[0])

        inst_bias = self.instinct.bias(free_angle, free_mag, front_clear, us_left, us_right, sector0_occ)
        osc_pen   = self.anti_osc.penalties()

        scores = q - self.cfg.AVOIDANCE_PENALTY * av
        for i, a in enumerate(Action):
            scores[i] += inst_bias.get(a, 0.0) * 4.0
            scores[i] += osc_pen.get(a, 0.0)

        if self.cfg.BLOCK_REVERSE:
            scores[list(Action).index(Action.REVERSE)] = -1e9

        if random.random() < self.epsilon:
            valid = [i for i, a in enumerate(Action)
                     if not (self.cfg.BLOCK_REVERSE and a == Action.REVERSE)]
            best_idx = random.choice(valid)
        else:
            best_idx = int(np.argmax(scores))

        action = list(Action)[best_idx]

        raw_l, raw_r = self.brain.get_dynamic_pwm(action, self.cfg.PWM_MAX)

        if slow_action is not None and slow_conf >= 0.15:
            tab_l, tab_r = PWM_TABLE.get(slow_action, (0.0, 0.0))
            dyn_l, dyn_r = self.brain.get_dynamic_pwm(slow_action, self.cfg.PWM_MAX)
            alpha = slow_conf * 0.70
            pwm_slow = (
                alpha * tab_l + (1.0 - alpha) * dyn_l,
                alpha * tab_r + (1.0 - alpha) * dyn_r,
            )
            raw_l, raw_r = self.cc.integrate(
                (raw_l, raw_r), pwm_slow, slow_conf,
                lorenz_x=self.lorenz.x_norm,
                rossler_x=self.rossler.x_norm,
                dscroll_x=self.double_scroll.modulated_x_norm,
                front_dist_m=sd.get('min_dist', 3.0),
                side_left_m=float(np.mean(lidar_16[10:14])),
                side_right_m=float(np.mean(lidar_16[2:6])),
                stagnant=self.anti_stag.stuck,
                bumper=bool(sd.get('bumper_front', 0)),
            )

        pwm_l, pwm_r = self._apply_slew(raw_l, raw_r)

        reward_cur = self._reward(sd, action)
        self.brain.backward_steering(
            reward_cur, action,
            prev_pwm_l=self._prev_pwm_l, prev_pwm_r=self._prev_pwm_r,
            cur_pwm_l=pwm_l, cur_pwm_r=pwm_r,
        )
        self._prev_pwm_l = pwm_l; self._prev_pwm_r = pwm_r

        self._finish(norm_feats, action, sd, "NEURAL", bumper_f)
        self._train(norm_feats, action, sd, bumper_f)

        return pwm_l, pwm_r, action, "NEURAL", self._diag(lidar_16, us_left, us_right)

    # ------------------------------------------------------------------
    def _finish(self, feats, action, sd, source, bumper_f):
        reward = self._reward(sd, action)
        self.last_reward = reward
        if self._prev_features is not None:
            self.replay.push(self._prev_features, action.value - 1, reward, feats, bumper_f == 1)
        if bumper_f == 1 or reward < -1.0:
            sev = min(1.0, abs(reward) / 5.0)
            self.avoidance.push(feats, action.value - 1, sev)

        self.anti_osc.update(action)
        self.last_action = action; self.last_source = source
        self._prev_features = feats.copy()
        self.reservoir.update(reward)

        if getattr(self.cfg, 'USE_HORMONES', False):
            self._update_hormones(reward, is_collision=(bumper_f == 1))
        else:
            self.epsilon = max(self.cfg.EPSILON_MIN, self.epsilon * self.cfg.EPSILON_DECAY)
            self.lr      = max(self.cfg.LR_MIN,      self.lr      * self.cfg.LR_DECAY)

        if self.step > 0 and self.step % self.cfg.AUTO_SAVE_INTERVAL == 0:
            self.save()
            if self.cfg.USE_LIDAR_PREDICTOR:
                self.predictor_net.save(self.cfg.PREDICTOR_FILE)

    def _train(self, feats, action, sd, bumper_f):
        if self.step % self.cfg.REPLAY_FREQ == 0 and len(self.replay) >= self.cfg.REPLAY_BATCH:
            batch = self.replay.sample(self.cfg.REPLAY_BATCH)
            for s, a_idx, r, s2, done in batch:
                q_s2 = self.brain.forward(s2, self.lorenz.x_norm)
                tgt  = self.brain.forward(s,  self.lorenz.x_norm).copy()
                tgt[a_idx] = r + (0.0 if done else self.cfg.GAMMA * float(np.max(q_s2)))
                self.brain.backward(tgt)

        if self.step % self.cfg.AVOIDANCE_TRAIN_FREQ == 0 and len(self.avoidance) > 0:
            for exp in self.avoidance.sample(self.cfg.REPLAY_BATCH // 2):
                q = self.brain.forward(exp.features, self.lorenz.x_norm)
                # tgt_q: obniż Q niebezpiecznej akcji proporcjonalnie do severity
                # (zamiast q==tgt_q → dq=0 → brak gradientu na głowicy Q)
                tgt_q = q.copy()
                tgt_q[exp.action] = q[exp.action] - exp.severity * self.cfg.AVOIDANCE_CONTRAST
                # tgt_a: ucz głowicę avoidance niezależnie
                tgt_a = np.zeros(self.cfg.N_ACTIONS)
                tgt_a[exp.action] = exp.severity
                self.brain.backward(tgt_q, tgt_a)

        if self.step % self.cfg.AVOIDANCE_DECAY_FREQ == 0:
            self.avoidance.decay()

    def _diag(self, lidar, usl, usr):
        _hard = frozenset({'BUMPER_HIT','BUMPER_REV','BUMPER_SPIN','HARD_SAFETY','REAR_BUMPER','REAR_FWD'})
        MAX = self.cfg.LIDAR_MAX_RANGE
        min_dist_m = round(float(1.0 - np.max(lidar)) * MAX, 3)
        return {
            'step':         self.step,
            'epsilon':      round(self.epsilon, 4),
            'min_dist':     min_dist_m,
            'lidar_left_min':  round(float(1.0 - np.max(lidar[2:6]))   * MAX, 2),
            'lidar_right_min': round(float(1.0 - np.max(lidar[10:14])) * MAX, 2),
            'lidar_zones': {
                'FRONT': round(float(1.0 - np.max(lidar[[14,15,0,1]])) * MAX, 2),
                'RIGHT': round(float(1.0 - np.mean(lidar[10:14]))      * MAX, 2),
                'BACK':  round(float(1.0 - np.mean(lidar[6:10]))       * MAX, 2),
                'LEFT':  round(float(1.0 - np.mean(lidar[2:6]))        * MAX, 2),
            },
            'us_left':       round(usl, 3),
            'us_right':      round(usr, 3),
            'action':        self.last_action.name if self.last_action else '—',
            'source':        self.last_source,
            'hard_safety':   self.last_source in _hard,
            'pred_min_dist': round(self.safety._last_pred, 3),
            'last_reward':   round(self.last_reward, 3),
            'stagnant':      self.anti_stag.stuck,
            'stag_force':    self.anti_stag.force,
            'stag_phase':    self.anti_stag._phase,
            'stag_count':    self.anti_stag.count,
            'safety_state':  self.anti_stag._phase,
            'safety_cycles_left': self.anti_stag._phase_rem,
            'oscillating':   bool(self.anti_osc.penalties()),
            'osc_count':     0,
            'lorenz_x':      round(self.lorenz.x_norm, 4),
            'rossler_x':     round(self.rossler.x_norm, 4),
            'dscroll_x':     round(self.double_scroll.modulated_x_norm, 4),
            'dscroll_mode':  self.double_scroll.mode,
            'dscroll_amp':   round(self.double_scroll.current_amplitude, 3),
            'predictor_mae': round(self.predictor_net.mae, 4),
            'predictor_conf': round(self.predictor_net.confidence, 3),
            'brain_speed':   round(self.brain._speed, 3),
            'brain_steer':   round(self.brain._steer, 3),
        }

    def save(self):
        state = {
            'W1': self.brain.W1, 'b1': self.brain.b1,
            'W2': self.brain.W2, 'b2': self.brain.b2,
            'W3': self.brain.W3, 'b3': self.brain.b3,
            'Wq': self.brain.Wq, 'bq': self.brain.bq,
            'Wa': self.brain.Wa, 'ba': self.brain.ba,
            'W_speed': self.brain.W_speed, 'b_speed': self.brain.b_speed,
            'W_steer': self.brain.W_steer, 'b_steer': self.brain.b_steer,
            'normalizer_mu':  self.normalizer.mu,
            'normalizer_var': self.normalizer.var,
            'normalizer_cnt': self.normalizer.cnt,
            'step':    self.step,
            'epsilon': self.epsilon,
            'lr':      self.lr,
            'reservoir_Wr': self.reservoir.Wr,
            'reservoir_br': self.reservoir.br,
        }
        try:
            tmp = self.cfg.BRAIN_FILE + '.tmp'
            with open(tmp, 'wb') as f: pickle.dump(state, f)
            os.replace(tmp, self.cfg.BRAIN_FILE)
        except Exception as e:
            print(f"[FAST] Błąd zapisu: {e}")

    def load(self) -> bool:
        """Wczytuje stan głównego mózgu (brain_fast.pkl). Predyktor jest obsługiwany osobno."""
        try:
            with open(self.cfg.BRAIN_FILE, 'rb') as f:
                s = pickle.load(f)
            for k in ('W1','b1','W2','b2','W3','b3','Wq','bq','Wa','ba'):
                attr = getattr(self.brain, k)
                val  = s[k]
                if attr.shape == val.shape:
                    attr[:] = val
            for k in ('W_speed','b_speed','W_steer','b_steer'):
                if k in s:
                    attr = getattr(self.brain, k)
                    val  = s[k]
                    if attr.shape == val.shape:
                        attr[:] = val
            if abs(float(self.brain.b_steer[0])) > 0.10:
                print(f"[LOAD] b_steer={self.brain.b_steer[0]:.3f} – debias → 0.0")
                self.brain.b_steer[:] = 0.0
                w = self.brain.W_steer
                clip_val = max(0.01, float(np.percentile(np.abs(w), 50)))
                self.brain.W_steer = np.clip(w, -clip_val, clip_val)
            self.normalizer.mu  = s['normalizer_mu']
            self.normalizer.var = s['normalizer_var']
            self.normalizer.cnt = s['normalizer_cnt']
            self.step    = s.get('step', 0)
            self.epsilon = s.get('epsilon', self.cfg.EPSILON)
            self.lr      = s.get('lr', self.cfg.LR)
            self.reservoir.set_weights({
                'Wr': s.get('reservoir_Wr', self.reservoir.Wr),
                'br': s.get('reservoir_br', self.reservoir.br),
            })
            return True
        except Exception as e:
            print(f"[FAST] Błąd wczytywania brain ({e}) – start od zera")
            return False