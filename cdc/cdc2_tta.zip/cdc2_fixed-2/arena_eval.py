#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arena_eval.py  –  SWARM Arena Evaluator  v1.0
==============================================
Ostateczna próba generalna przed wdrożeniem na fizyczny pojazd.
Testuje model w 6 złożonych środowiskach z przeszkodami o różnych kształtach.

CDC v1.2 arena evaluator:
  ✓ PWM slew rate 4.0 PWM/krok ≈ 0.4 m/s²
  ✓ BUMPER_TOUCH_DIST = 0.22m  (wykrywa kątowe podejście do ściany)
  ✓ HARD/SOFT safety source separation
  ✓ _slow_action_safe() – walidacja przed wykonaniem akcji slow
  ✓ Stuck detection + STUCK_REVERSE kick (8 kroków zamrożenia → cofnięcie)

Mapy (6 środowisk):
  BOX     30×30  – pilary prostokątne, bariery
  CITY    40×40  – siatka budynków, skrzyżowania
  MAZE    35×35  – labirynt
  ARENA   45×45  – okrągłe kolumny (24-kąt), otwarta przestrzeń z pułapkami
  FACTORY 38×38  – maszyny L-kształtne + ukośne ściany (pasy transportowe)
  DUNGEON 50×50  – pokoje połączone drzwiami, trójkątne pilastry, gruz

CSV (~62 kolumny): pełny stan sensorów, lidar 0-15, diagnostyki mózgu,
atraktory, zdarzenia stuck/collision, statystyki sesji.
"""

import csv
import math
import os
import random
import sys
import time
from collections import deque
from datetime import datetime
from pathlib import Path

import numpy as np

try:
    import pygame
except ImportError:
    print("Brak pygame. Zainstaluj: pip install pygame"); sys.exit(1)

# Mózg importowany WYŁĄCZNIE przez main.py
# arena_eval.py = środowisko (fizyka + sensory + rendering)

# =============================================================================
# STAŁE UKŁADU
# =============================================================================
TARGET_W = 1150; TARGET_H =  950
BTN_H    = 228;  TEL_H    = 430
MAP_H    = TARGET_H - TEL_H - BTN_H
TARGET_FPS = 30;  HISTORY = 300

ROBOT_R          = 0.18    # [m] promień robota
WHEEL_BASE       = 0.28    # [m] rozstaw kół
MAX_SPEED        = 0.75    # [m/s] przy PWM=100
DT               = 0.063   # [s] krok symulacji
PWM_SLEW         = 6.0     # [PWM/krok] ≈ 0.4 m/s² przyspieszenie
BUMPER_TOUCH_DIST = ROBOT_R + 0.08   # 0.22m – łapie kątowe podejście
US_ANG           = 18.0    # [°] kąt czujników US od osi robota
TOF_ANG_DEF      = 7.5    # [°] domyślny kąt TOF
TOF_MIN, TOF_MAX = 7.5, 45.

# HARD safety: slow brain bezwzględnie zablokowany (fizyczna kolizja)
_HARD_SAFETY_SOURCES = frozenset({
    'BUMPER_HIT','BUMPER_REV','BUMPER_SPIN',
    'HARD_SAFETY','REAR_BUMPER','REAR_FWD',
    'TOF_AVOID','ANTI_STALL',
})
# SOFT safety: slow MAY przejąć jeśli conf>=0.50 i akcja bezpieczna
_SOFT_SAFETY_SOURCES = frozenset({
    'SPATIAL_SPIN','SPATIAL_TURN','US_CORR','ANTI_STALL','STAGNATION',
    'US_SOFT','STAGNATION_FORCE','CONCEPT',
})

MAPS_LIST  = ['box','city','maze','arena','factory','dungeon','open']
MAP_LABELS = {
    'box'    : 'BOX 30×30',
    'city'   : 'MIASTO 40×40',
    'maze'   : 'LABIRYNT 35×35',
    'arena'  : 'ARENA 45×45',
    'factory': 'FABRYKA 38×38',
    'dungeon': 'LOCHY 50×50',
    'open'   : 'OTWARTA PRZESTRZEŃ 50×50 ★',
}
SPEEDS = [0.25, 0.5, 1., 2., 4., 8., 16.]
SPD_L  = ['¼×','½×','1×','2×','4×','8×','16×']

# Auto-advance: po ilu krokach na mapie automatycznie przejść na następną (0 = wyłączone)
AUTO_ADVANCE_STEPS = 15_000
# Losowość mapy przy każdym uruchomieniu: ±MAP_JITTER * wymiar komórki przesunięcia ścian
MAP_JITTER = 0.15

# =============================================================================
# PALETA
# =============================================================================
C = {
    'bg':(10,13,22),'map_bg':(13,16,28),'panel_bg':(9,12,21),'grid':(18,23,36),
    'wall':(70,90,138),'obs':(52,65,95),'obs_fill':(22,28,48),
    'circ_fill':(28,22,48),'circ_brd':(95,65,138),
    'diag_wall':(85,110,155),
    'robot':(0,220,170),'robot_dk':(0,98,75),'heading':(255,228,80),
    'trail_h':(70,175,255),'trail_t':(16,28,62),
    'us':(80,235,255),'us_w':(255,205,55),'us_d':(255,62,52),
    'tof':(205,100,255),'tof_w':(255,155,55),'tof_d':(255,62,52),
    'ld_far':(24,168,68),'ld_mid':(198,175,24),'ld_near':(218,52,38),
    'text':(200,215,238),'dim':(85,105,142),'accent':(75,188,255),
    'safe':(55,218,115),'warn':(255,190,50),'danger':(255,75,75),
    'rw_p':(55,218,115),'rw_n':(215,65,55),'sep':(28,36,58),
    'bar_bg':(18,24,42),'lorenz':(125,178,255),'rossler':(75,228,158),
    'dscroll':(228,135,255),'btn_bg':(22,30,52),'btn_on':(40,56,98),
    'btn_hi':(52,76,128),'btn_brd':(48,62,98),'btn_txt':(220,232,255),
    'bump_ok':(26,40,66),'bump_hit':(255,70,50),
    'stuck_ev':(255,130,20),'csv_on':(55,218,115),
    'goal':(255,210,0),'goal_ring':(255,240,80),'goal_reach':(80,255,160),
}

# =============================================================================
# GEOMETRIA – POMOCNICZE
# =============================================================================
def _walls_box(s):
    return [(0,0,s,0),(s,0,s,s),(s,s,0,s),(0,s,0,0)]

def circle_segs(cx, cy, r, n=24):
    """Przybliżenie koła jako wielokąt (24 segmenty → błąd max 0.013m)."""
    segs = []
    for i in range(n):
        a0 = 2*math.pi*i/n; a1 = 2*math.pi*(i+1)/n
        segs.append((cx+r*math.cos(a0), cy+r*math.sin(a0),
                     cx+r*math.cos(a1), cy+r*math.sin(a1)))
    return segs

def lshape_segs(ox, oy, w, h, notch_x, notch_y):
    """L-kształt: prostokąt (w,h) z wyciętym narożnikiem PR-GÓR (notch_x,notch_y)."""
    pts = [(ox,oy),(ox+w,oy),(ox+w,oy+notch_y),(ox+notch_x,oy+notch_y),
           (ox+notch_x,oy+h),(ox,oy+h)]
    return [(pts[i][0],pts[i][1],pts[(i+1)%6][0],pts[(i+1)%6][1]) for i in range(6)]

def triangle_segs(x1,y1,x2,y2,x3,y3):
    return [(x1,y1,x2,y2),(x2,y2,x3,y3),(x3,y3,x1,y1)]

# =============================================================================
# MAPY  (zwracają walls, obs_rect, obs_circles, extra_segs, mw, mh)
# obs_circles = [(cx,cy,r), ...]  – tylko rysowanie
# extra_segs  = [(x1,y1,x2,y2), ...] – kolizja + sensory (ukośne/koła/L)
# =============================================================================
def make_map_box(seed=None, jitter=0.12):
    s   = 30.
    rng = random.Random(seed)
    def j(v, lo=0.5, hi=28.):
        return float(np.clip(v + rng.uniform(-s * jitter * 0.5, s * jitter * 0.5), lo, hi))
    obs = [(j(5),j(5),1.5,1.5),(j(5),j(20),1.5,1.5),(j(20),j(5),1.5,1.5),(j(20),j(20),1.5,1.5),
           (j(12.5),j(12.5),1.5,1.5),
           (j(8),0,0.4,j(10,3,14)),(j(8),j(12),0.4,j(10,3,14)),(j(18),j(8),0.4,j(14,4,18)),
           (j(18),j(24),0.4,j(6,2,8)),
           (j(3),j(14),j(7,3,10),0.4),(j(22),j(14),j(5,2,8),0.4),
           (j(25),j(3),2,2),(j(3),j(25),2,2),
           (j(14),j(24),3,1),(j(24),j(14),1,3),(j(10),j(18),2,0.5),(j(6),j(9),0.5,3),(j(23),j(22),2,0.5)]
    return _walls_box(s), obs, [], [], s, s

def make_map_city(seed=None, jitter=0.08):
    s   = 45.
    rng = random.Random(seed)
    obs = []
    coords = [2.0, 10.5, 19.0, 27.5, 36.0]
    for cx in coords:
        for cy in coords:
            if not (cx == 19.0 and cy == 19.0):
                dx = rng.uniform(-s * jitter * 0.3, s * jitter * 0.3)
                dy = rng.uniform(-s * jitter * 0.3, s * jitter * 0.3)
                bw = 5 + rng.uniform(-0.5, 0.5)
                bh = 5 + rng.uniform(-0.5, 0.5)
                obs.append((cx + dx, cy + dy, bw, bh))
    mids = [8.5, 17.0, 25.5, 34.0]
    for cx in mids:
        for cy in mids:
            dx = rng.uniform(-0.4, 0.4)
            dy = rng.uniform(-0.4, 0.4)
            obs.append((cx - .4 + dx, cy - .4 + dy, .8, .8))
    return _walls_box(s), obs, [], [], s, s

def make_map_maze(seed=None, jitter=0.15):
    """
    Labirynt generowany algorytmem recursive backtracker (iteracyjny DFS).
    Gwarantuje pełną łączność – KAŻDY korytarz jest dostępny.

    Parametry:
      seed   – None = nowy losowy labirynt przy każdym uruchomieniu
      jitter – ±% przesunięcia ścian względem siatki (0.0 = idealny grid, 0.25 = duże zmiany)

    Siatka 9×9 komórek w obszarze 45×45m → korytarze ~4.6m (robot: 0.36m)
    """
    s    = 45.
    COLS = 9
    ROWS = 9
    cw   = s / COLS   # 5.0 m na komórkę
    ch   = s / ROWS
    WT   = 0.38       # grubość ściany [m]

    _seed = seed if seed is not None else random.randint(0, 2**31)
    rng   = random.Random(_seed)

    # --- Generacja labiryntu (iteracyjny DFS) ---
    # h_walls[r][c] = True → ściana pozioma między row r i r+1 przy kol. c
    # v_walls[c][r] = True → ściana pionowa między kol. c i c+1 przy wierszu r
    h_walls = [[True] * COLS for _ in range(ROWS - 1)]
    v_walls = [[True] * ROWS for _ in range(COLS - 1)]
    visited = [[False] * ROWS for _ in range(COLS)]

    stack = [(0, 0)]
    visited[0][0] = True
    while stack:
        c, r = stack[-1]
        nbrs = []
        for dc, dr in [(1, 0), (-1, 0), (0, 1), (0, -1)]:
            nc, nr = c + dc, r + dr
            if 0 <= nc < COLS and 0 <= nr < ROWS and not visited[nc][nr]:
                nbrs.append((nc, nr, dc, dr))
        if nbrs:
            nc, nr, dc, dr = rng.choice(nbrs)
            if   dc ==  1: v_walls[c][r]     = False  # E – usuń ścianę po prawej c
            elif dc == -1: v_walls[c - 1][r] = False  # W – usuń ścianę po lewej c
            elif dr ==  1: h_walls[r][c]     = False  # S – usuń ścianę pod r
            elif dr == -1: h_walls[r - 1][c] = False  # N – usuń ścianę nad r
            visited[nc][nr] = True
            stack.append((nc, nr))
        else:
            stack.pop()

    # Opcjonalnie: usuń kilka losowych dodatkowych ścian → pętle, alternatywne trasy
    extra_loops = max(2, int(COLS * ROWS * 0.08))
    for _ in range(extra_loops):
        if rng.random() < 0.5 and ROWS > 1:
            r2 = rng.randint(0, ROWS - 2)
            c2 = rng.randint(0, COLS - 1)
            h_walls[r2][c2] = False
        else:
            c2 = rng.randint(0, COLS - 2)
            r2 = rng.randint(0, ROWS - 1)
            v_walls[c2][r2] = False

    # --- Konwersja ścian na prostokąty z jitterem pozycji i długości ---
    obs  = []
    jit_pos = cw * jitter          # max przesunięcie środka ściany [m]
    jit_len = cw * jitter * 0.4    # max zmiana długości ściany [m]

    def jp(val, lo, hi):
        return float(np.clip(val + rng.uniform(-jit_pos, jit_pos), lo, hi))

    def jlen(val, vmin, vmax):
        return float(np.clip(val + rng.uniform(-jit_len, jit_len), vmin, vmax))

    # Ściany poziome: między row r i r+1
    for r in range(ROWS - 1):
        for c in range(COLS):
            if h_walls[r][c]:
                x0 = c * cw
                y0 = (r + 1) * ch - WT / 2
                ww = jlen(cw,  cw * 0.65, cw * 1.25)
                xj = jp(x0, max(0.1, x0 - jit_pos), min(s - ww - 0.1, x0 + jit_pos))
                yj = jp(y0, max(0.2,  y0 - jit_pos * 0.4), min(s - WT - 0.2, y0 + jit_pos * 0.4))
                obs.append((xj, yj, ww, WT))

    # Ściany pionowe: między kol. c i c+1
    for c in range(COLS - 1):
        for r in range(ROWS):
            if v_walls[c][r]:
                x0 = (c + 1) * cw - WT / 2
                y0 = r * ch
                hh = jlen(ch, ch * 0.65, ch * 1.25)
                xj = jp(x0, max(0.2, x0 - jit_pos * 0.4), min(s - WT - 0.2, x0 + jit_pos * 0.4))
                yj = jp(y0, max(0.1, y0 - jit_pos), min(s - hh - 0.1, y0 + jit_pos))
                obs.append((xj, yj, WT, hh))

    return _walls_box(s), obs, [], [], s, s

def make_map_arena(seed=None, jitter=0.15):
    """Arena walki: okrągłe kolumny, otwarta przestrzeń, narożne pułapki."""
    s   = 45.
    rng = random.Random(seed)
    def j(v, lo=0.5, hi=44.): return float(np.clip(v + rng.uniform(-s*jitter*0.3, s*jitter*0.3), lo, hi))
    walls = _walls_box(s)
    obs_rect = [
        (0, 0, 4, 4), (s-4, 0, 4, 4), (0, s-4, 4, 4), (s-4, s-4, 4, 4),
        (j(18), 0, 9, 1.5), (j(18), s-1.5, 9, 1.5),
        (0, j(18), 1.5, 9), (s-1.5, j(18), 1.5, 9),
    ]
    cx, cy = s / 2, s / 2
    r0 = 2.5 + rng.uniform(-0.3, 0.3)
    circles = [(cx, cy, r0)]
    ring1_r = 12 + rng.uniform(-s*jitter*0.5, s*jitter*0.5)
    for i in range(6):
        a = math.pi / 3 * i + rng.uniform(-0.12, 0.12)
        cr = 1.2 + rng.uniform(-0.15, 0.15)
        circles.append((cx + ring1_r * math.cos(a), cy + ring1_r * math.sin(a), cr))
    ring2_r = 19 + rng.uniform(-s*jitter*0.5, s*jitter*0.5)
    for i in range(4):
        a = math.pi / 4 + math.pi / 2 * i + rng.uniform(-0.12, 0.12)
        cr = 0.9 + rng.uniform(-0.1, 0.1)
        circles.append((cx + ring2_r * math.cos(a), cy + ring2_r * math.sin(a), cr))
    extra_segs = []
    for (ccx, ccy, r) in circles:
        extra_segs += circle_segs(ccx, ccy, r, 24)
    return walls, obs_rect, circles, extra_segs, s, s

def make_map_factory(seed=None, jitter=0.10):
    """Fabryka: maszyny L-kształtne + ukośne ściany (pasy transportowe)."""
    s   = 48.
    sc  = 48. / 38.
    rng = random.Random(seed)
    def j(v): return v + rng.uniform(-s * jitter * 0.25, s * jitter * 0.25)
    walls = _walls_box(s)
    obs_rect = [
        (1, 1, 5*sc, 0.5), (1, 1, 0.5, 5*sc),
        (s-1-5*sc, 1, 5*sc, 0.5), (s-1.5, 1, 0.5, 5*sc),
        (1, s-1.5, 5*sc, 0.5), (1, s-1-5*sc, 0.5, 5*sc),
        (s-1-5*sc, s-1.5, 5*sc, 0.5), (s-1.5, s-1-5*sc, 0.5, 5*sc),
    ]
    extra_segs = []
    for (ox, oy) in [(3, 3), (20, 3), (3, 20), (20, 20)]:
        extra_segs += lshape_segs(j(ox)*sc, j(oy)*sc, 7*sc, 7*sc, 4*sc, 3*sc)
    diagonals = [
        (10, 0, 18, 8), (18, 8, 10, 16), (10, 16, 18, 24), (18, 24, 10, 32),
        (28, 0, 20, 8), (20, 8, 28, 16), (28, 16, 20, 24), (20, 24, 28, 32),
    ]
    extra_segs += [(j(x1)*sc, j(y1)*sc, j(x2)*sc, j(y2)*sc) for (x1, y1, x2, y2) in diagonals]
    obs_rect += [
        (j(13)*sc, j(12)*sc, 3*sc, 1*sc), (j(13)*sc, j(25)*sc, 3*sc, 1*sc),
        (0, j(18)*sc, 2*sc, 2*sc), (s-2*sc, j(18)*sc, 2*sc, 2*sc),
    ]
    return walls, obs_rect, [], extra_segs, s, s

def make_map_dungeon(seed=None, jitter=0.10):
    """Lochy: pokoje połączone drzwiami, trójkątne pilastry, gruz."""
    s   = 50.
    rng = random.Random(seed if seed is not None else random.randint(0, 2**31))
    walls = _walls_box(s)
    obs_rect   = []
    extra_segs = []

    coords = [0, 12, 25, 38, 50]
    door_w = 4.0 + rng.uniform(-0.5, 0.5)  # lekko losowa szerokość drzwi

    for x in [12, 25, 38]:
        for i in range(4):
            y1, y2 = coords[i], coords[i+1]
            xj   = x + rng.uniform(-s * jitter * 0.15, s * jitter * 0.15)
            ymid = (y1 + y2) / 2.0 + rng.uniform(-0.8, 0.8)
            extra_segs += [(xj, y1, xj, ymid - door_w/2), (xj, ymid + door_w/2, xj, y2)]

    for y in [12, 25, 38]:
        for i in range(4):
            x1, x2 = coords[i], coords[i+1]
            yj   = y + rng.uniform(-s * jitter * 0.15, s * jitter * 0.15)
            xmid = (x1 + x2) / 2.0 + rng.uniform(-0.8, 0.8)
            extra_segs += [(x1, yj, xmid - door_w/2, yj), (xmid + door_w/2, yj, x2, yj)]

    rooms = [(cx, cy) for cx in [6, 18, 31, 44] for cy in [6, 18, 31, 44]]
    for (rx, ry) in rooms:
        r_trig = 1.0 + rng.uniform(-0.15, 0.15)
        rxj = rx + rng.uniform(-s * jitter * 0.2, s * jitter * 0.2)
        ryj = ry + rng.uniform(-s * jitter * 0.2, s * jitter * 0.2)
        extra_segs += triangle_segs(rxj, ryj - r_trig,
                                     rxj + r_trig, ryj + r_trig * 0.7,
                                     rxj - r_trig, ryj + r_trig * 0.7)

    # Gruz – losowy przy każdym uruchomieniu (nie fixowany seed=42)
    for _ in range(30):
        gx = rng.uniform(1, s - 2)
        gy = rng.uniform(1, s - 2)
        gw = rng.uniform(0.3, 0.8)
        door_clear = (not any(abs(gx - x) < 2.5 for x in [12, 25, 38]) and
                      not any(abs(gy - y) < 2.5 for y in [12, 25, 38]))
        if door_clear:
            obs_rect.append((gx, gy, gw, gw))

    circles = [(18, 18, 1.5 + rng.uniform(-0.2, 0.2)),
               (31, 31, 1.5 + rng.uniform(-0.2, 0.2))]
    for (ccx, ccy, r) in circles:
        extra_segs += circle_segs(ccx, ccy, r, 24)

    return walls, obs_rect, circles, extra_segs, s, s

def make_map_open(seed=None, jitter=0.12):
    """
    Otwarta przestrzeń z punktem docelowym.
    Kilka rozrzuconych filarów – robot musi dotrzeć do celu (żółty krzyżyk).
    Cel i przeszkody są losowane przy każdym uruchomieniu (seed).
    """
    s   = 50.
    rng = random.Random(seed if seed is not None else random.randint(0, 2**31))

    obs_rect   = []
    obs_circles = []
    extra_segs  = []

    # Kilka losowych filarów – rzadkie, żeby nie blokować trasy do celu
    # Gwarantujemy margines 5m od środka mapy (strefa startowa)
    n_pillars = rng.randint(6, 10)
    attempts  = 0
    while len(obs_circles) < n_pillars and attempts < 200:
        attempts += 1
        cx = rng.uniform(3., s - 3.)
        cy = rng.uniform(3., s - 3.)
        r  = rng.uniform(0.4, 1.0)
        # Bez filarów w strefie startowej (centrum ±6m)
        if abs(cx - s/2) < 6. and abs(cy - s/2) < 6.:
            continue
        # Bez nakładania na inne filary
        if any(math.hypot(cx-ex, cy-ey) < r+er+1.0 for (ex,ey,er) in obs_circles):
            continue
        obs_circles.append((cx, cy, r))
        extra_segs += circle_segs(cx, cy, r, 20)

    # Kilka prostokątnych barier – losowe kąty/rozmiary
    n_walls = rng.randint(3, 6)
    attempts = 0
    while len(obs_rect) < n_walls and attempts < 150:
        attempts += 1
        wx = rng.uniform(2., s - 8.)
        wy = rng.uniform(2., s - 4.)
        ww = rng.uniform(1.5, 5.0)
        wh = rng.uniform(0.3, 0.5)
        if abs(wx + ww/2 - s/2) < 6. and abs(wy - s/2) < 6.:
            continue
        obs_rect.append((wx, wy, ww, wh))

    return _walls_box(s), obs_rect, obs_circles, extra_segs, s, s


MAP_BUILDERS = {
    'box':     make_map_box,
    'city':    make_map_city,
    'maze':    make_map_maze,
    'arena':   make_map_arena,
    'factory': make_map_factory,
    'dungeon': make_map_dungeon,
    'open':    make_map_open,
}

# =============================================================================
# =============================================================================
class RobotPhysics:
    def __init__(self, x=1.0, y=1.0, theta=0.0):
        self.x = float(x); self.y = float(y); self.theta = float(theta)
        self.vl = 0.0; self.vr = 0.0
        self._pwm_l = 0.0; self._pwm_r = 0.0   # aktualny PWM po slew rate
        self.encoder_l = 0.0; self.encoder_r = 0.0

    def _slew(self, cur, tgt):
        delta = float(np.clip(tgt - cur, -PWM_SLEW, PWM_SLEW))
        return float(np.clip(cur + delta, -100., 100.))

    def update(self, pwm_l, pwm_r, dt=DT):
        self._pwm_l = self._slew(self._pwm_l, pwm_l)
        self._pwm_r = self._slew(self._pwm_r, pwm_r)
        self.vl = float(np.clip(self._pwm_l/100., -1., 1.))
        self.vr = float(np.clip(self._pwm_r/100., -1., 1.))
        v     = (self.vl + self.vr) * 0.5 * MAX_SPEED
        omega = (self.vr - self.vl) / WHEEL_BASE * MAX_SPEED
        self.theta = (self.theta + omega*dt + math.pi) % (2*math.pi) - math.pi
        self.x += v * math.cos(self.theta) * dt
        self.y += v * math.sin(self.theta) * dt
        self.encoder_l += self.vl * dt
        self.encoder_r += self.vr * dt

    @property
    def v_ms(self): return (self.vl + self.vr)*0.5*MAX_SPEED
    @property
    def omega_rads(self): return (self.vr - self.vl)/WHEEL_BASE*MAX_SPEED

# =============================================================================
# LIDAR / SENSORY
# =============================================================================
def _seg_dist2(x1,y1,x2,y2,px,py):
    dx=x2-x1; dy=y2-y1; ln2=dx*dx+dy*dy
    if ln2<1e-12:
        nx,ny=px-x1,py-y1; return nx*nx+ny*ny,nx,ny
    t=max(0.,min(1.,((px-x1)*dx+(py-y1)*dy)/ln2))
    nx=px-(x1+t*dx); ny=py-(y1+t*dy)
    return nx*nx+ny*ny,nx,ny

def _ray_seg(rx,ry,rdx,rdy,x1,y1,x2,y2):
    sdx=x2-x1; sdy=y2-y1
    denom=rdx*sdy-rdy*sdx
    if abs(denom)<1e-12: return None
    t=((x1-rx)*sdy-(y1-ry)*sdx)/denom
    u=((x1-rx)*rdy-(y1-ry)*rdx)/denom
    if t>1e-4 and 0.<=u<=1.: return t
    return None

def ray_cast(segs, ox, oy, angle, max_r=6.0):
    dx=math.cos(angle); dy=math.sin(angle)
    best=max_r
    for (x1,y1,x2,y2) in segs:
        t=_ray_seg(ox,oy,dx,dy,x1,y1,x2,y2)
        if t is not None and t<best: best=t
    return best

def build_sensors(p, all_segs, lidar_max=6.0):
    """
    Surowe odczyty sensorów – format identyczny jak pakiet z ESP32.
    Wywołuje ArenaEnv._read_sensors() przez ArenaEnv.step().
    Ta funkcja służy tylko do budowania wektora lidar_0..15 + min_dist.
    US/ToF/enkodery są nadpisywane przez ArenaEnv._read_sensors() z poprawnymi kątami.
    """
    sd = {}
    min_d = lidar_max
    for i in range(16):
        ang = p.theta + math.radians(i * 22.5)
        d = ray_cast(all_segs, p.x, p.y, ang, lidar_max)
        sd[f'lidar_{i}'] = max(0., min(1., 1. - d / lidar_max))
        if d < min_d: min_d = d
    sd['min_dist'] = min_d

    # US: lewy = +US_ANG (fizyczna LEWA), prawy = −US_ANG (fizyczna PRAWA)
    ang_us  = math.radians(US_ANG)
    sd['us_left']  = ray_cast(all_segs, p.x, p.y, p.theta + ang_us,  3.)
    sd['us_right'] = ray_cast(all_segs, p.x, p.y, p.theta - ang_us,  3.)

    # ToF: lewy = +TOF_ANG_DEF, prawy = −TOF_ANG_DEF
    ang_tof = math.radians(TOF_ANG_DEF)
    sd['tof_left']  = ray_cast(all_segs, p.x, p.y, p.theta + ang_tof, 2.)
    sd['tof_right'] = ray_cast(all_segs, p.x, p.y, p.theta - ang_tof, 2.)

    # Enkodery: ticki (int), 1 tick = 1.5 cm
    _TICK = 0.015
    sd['encoder_l'] = int(round(p.vl * MAX_SPEED * DT / _TICK))
    sd['encoder_r'] = int(round(p.vr * MAX_SPEED * DT / _TICK))

    # Zderzaki
    sd['bumper_front'] = 1 if ray_cast(all_segs, p.x, p.y, p.theta,           1.) < BUMPER_TOUCH_DIST else 0
    sd['rear_bumper']  = 1 if ray_cast(all_segs, p.x, p.y, p.theta + math.pi, 1.) < BUMPER_TOUCH_DIST else 0

    # IMU + zasilanie (symulowane)
    sd['imu_gz']        = p.omega_rads + random.gauss(0, .01)
    sd['motor_current'] = abs(p.v_ms) * 1.5 + random.uniform(.1, .3)
    sd['voltage'] = 12.0; sd['current'] = 0.5

    # Bumpery boczne (lidar proxy)
    sd['bumper_left']  = 1 if max(sd.get('lidar_10',0), sd.get('lidar_11',0)) > 0.68 else 0
    sd['bumper_right'] = 1 if max(sd.get('lidar_2', 0), sd.get('lidar_3', 0)) > 0.68 else 0
    return sd

# =============================================================================
# KOLIZJE I CLAMP
# =============================================================================
def resolve_collisions(p, all_segs, R=ROBOT_R):
    for x1,y1,x2,y2 in all_segs:
        d2,nx,ny = _seg_dist2(x1,y1,x2,y2,p.x,p.y)
        if d2 < R*R:
            d = math.sqrt(d2) if d2>1e-12 else 1e-6
            nnx,nny = nx/d,ny/d
            p.x += nnx*(R-d+0.002)
            p.y += nny*(R-d+0.002)

def clamp_to_map(p, mw, mh, R=ROBOT_R):
    p.x = max(R+.001, min(mw-R-.001, p.x))
    p.y = max(R+.001, min(mh-R-.001, p.y))

# =============================================================================
# =============================================================================



def lc(a,b,t):
    t=max(0.,min(1.,t))
    return (int(a[0]+(b[0]-a[0])*t),int(a[1]+(b[1]-a[1])*t),int(a[2]+(b[2]-a[2])*t))
def rr(s,col,rect,r=6,w=0):
    try: pygame.draw.rect(s,col,rect,w,border_radius=r)
    except: pygame.draw.rect(s,col,rect,w)
def mkf(sz, bold=False):
    """Font z bezpiecznym fallbackiem – dziala na Androidzie."""
    for n in ['Consolas', 'Courier New', 'monospace', 'DejaVuSans', '']:
        try:
            f = pygame.font.SysFont(n, sz, bold=bold)
            if f is not None: return f
        except Exception: pass
    try: return pygame.font.Font(None, max(10, sz))
    except Exception: return None
    return pygame.font.Font(None,sz)
def hbar(s,rect,v,col,r=4):
    pygame.draw.rect(s,C['bar_bg'],rect,border_radius=r)
    if v>0.002:
        w=max(r*2,int(rect[2]*min(v,1.)))
        pygame.draw.rect(s,col,(rect[0],rect[1],w,rect[3]),border_radius=r)
def bibar(s,rect,v,cp,cn,r=4):
    cx=rect[0]+rect[2]//2; pygame.draw.rect(s,C['bar_bg'],rect,border_radius=r)
    v=max(-1.,min(1.,v)); hw=int(abs(v)*rect[2]/2)
    if hw>1:
        col=cp if v>=0 else cn; x=cx if v>=0 else cx-hw
        pygame.draw.rect(s,col,(x,rect[1],hw,rect[3]),border_radius=r)
def wave(s,rect,data,col,th=1,zl=True):
    rx,ry,rw,rh=rect; pygame.draw.rect(s,C['bar_bg'],rect,border_radius=2)
    if zl: pygame.draw.line(s,C['sep'],(rx,ry+rh//2),(rx+rw,ry+rh//2))
    n=len(data)
    if n<2: return
    pts=[(rx+int(i/(n-1)*rw),ry+int((1.-(v+1.)/2.)*rh)) for i,v in enumerate(data)]
    pygame.draw.lines(s,col,False,pts,th)
def rw_wave(s,rect,data):
    rx,ry,rw,rh=rect; pygame.draw.rect(s,C['bar_bg'],rect,border_radius=2)
    pygame.draw.line(s,C['sep'],(rx,ry+rh//2),(rx+rw,ry+rh//2))
    n=len(data); prev=None
    for i,v in enumerate(data):
        x=rx+int(i/max(n-1,1)*rw); nv=max(-1.,min(1.,v/5.))
        y=ry+int((1.-(nv+1.)/2.)*rh)
        col=lc(C['dim'],C['rw_p'],nv) if nv>=0 else lc(C['rw_n'],C['dim'],nv+1.)
        if prev: pygame.draw.line(s,col,prev,(x,y),2)
        prev=(x,y)
def gauge(s,cx,cy,R,v,col,w=5):
    if R<8: return
    ST,SW=210,120; steps=36
    for i in range(steps):
        a0=math.radians(ST-i/steps*SW); a1=math.radians(ST-(i+1)/steps*SW)
        pygame.draw.line(s,C['bar_bg'],(cx+int(R*math.cos(a0)),cy-int(R*math.sin(a0))),
                         (cx+int(R*math.cos(a1)),cy-int(R*math.sin(a1))),w)
    fill=int(steps*max(0.,min(1.,v)))
    for i in range(fill):
        sc=col if v<=0.65 else lc(col,C['danger'],i/max(steps-1,1)*v)
        a0=math.radians(ST-i/steps*SW); a1=math.radians(ST-(i+1)/steps*SW)
        pygame.draw.line(s,sc,(cx+int(R*math.cos(a0)),cy-int(R*math.sin(a0))),
                         (cx+int(R*math.cos(a1)),cy-int(R*math.sin(a1))),w)
    a=math.radians(ST-max(0.,min(1.,v))*SW)
    pygame.draw.line(s,C['text'],(cx,cy),(cx+int((R-2)*math.cos(a)),cy-int((R-2)*math.sin(a))),2)

# =============================================================================
# KAMERA
# =============================================================================
class Camera:
    ZOOM_MIN=0.3; ZOOM_MAX=10.
    def __init__(self,view_rect,mw,mh):
        self.vx,self.vy,self.vw,self.vh=view_rect
        self.mw=mw; self.mh=mh; self._fit_zoom(); self._pan=None
    def _fit_zoom(self):
        mg=24
        self.zoom=min((self.vw-mg*2)/self.mw,(self.vh-mg*2)/self.mh)
        self.ox=self.vx+self.vw/2-self.mw*self.zoom/2
        self.oy=self.vy+self.vh/2-self.mh*self.zoom/2
    def resize(self,vr): self.vx,self.vy,self.vw,self.vh=vr
    def w2s(self,x,y): return (int(self.ox+x*self.zoom),int(self.oy+(self.mh-y)*self.zoom))
    def d2p(self,d): return max(1,int(d*self.zoom))
    def zoom_at(self,sx,sy,f):
        nz=max(self.ZOOM_MIN,min(self.ZOOM_MAX,self.zoom*f)); r=nz/self.zoom
        self.ox=sx-(sx-self.ox)*r; self.oy=sy-(sy-self.oy)*r; self.zoom=nz
    def pan_start(self,sx,sy): self._pan=(sx,sy,self.ox,self.oy)
    def pan_move(self,sx,sy):
        if self._pan: self.ox=self._pan[2]+sx-self._pan[0]; self.oy=self._pan[3]+sy-self._pan[1]
    def pan_end(self): self._pan=None
    def pan_by(self,dx,dy): self.ox+=dx; self.oy+=dy
    def fit(self): self._fit_zoom()
    def follow(self,wx,wy,margin_px=100):
        sx,sy=self.w2s(wx,wy)
        if sx<self.vx+margin_px: self.ox+=self.vx+margin_px-sx
        if sx>self.vx+self.vw-margin_px: self.ox-=sx-(self.vx+self.vw-margin_px)
        if sy<self.vy+margin_px: self.oy+=self.vy+margin_px-sy
        if sy>self.vy+self.vh-margin_px: self.oy-=sy-(self.vy+self.vh-margin_px)

# =============================================================================
# CACHE MAPY
# =============================================================================
class MapCache:
    def __init__(self): self._surf=None; self._zoom=None; self._key=None
    def _render(self,cam,walls,obs_rect,obs_circles,extra_segs):
        z=cam.zoom; pw=int(cam.mw*z)+8; ph=int(cam.mh*z)+8
        surf=pygame.Surface((pw,ph)); surf.fill(C['map_bg'])
        def ws(x,y): return int(x*z),int((cam.mh-y)*z)
        def d2p(d): return max(1,int(d*z))
        gs=1. if z>12 else (5. if z>4 else 10.)
        xg=0.
        while xg<=cam.mw+.01:
            sx,_=ws(xg,0); _,y0=ws(0,0); _,y1=ws(0,cam.mh)
            pygame.draw.line(surf,C['grid'],(sx,min(y0,y1)),(sx,max(y0,y1)),1); xg+=gs
        yg=0.
        while yg<=cam.mh+.01:
            _,sy=ws(0,yg); x0,_=ws(0,yg); x1,_=ws(cam.mw,yg)
            pygame.draw.line(surf,C['grid'],(min(x0,x1),sy),(max(x0,x1),sy),1); yg+=gs
        for ox,oy,w,h in obs_rect:
            pa=ws(ox,oy+h); pb=ws(ox+w,oy)
            r2=pygame.Rect(min(pa[0],pb[0]),min(pa[1],pb[1]),abs(pb[0]-pa[0]),abs(pb[1]-pa[1]))
            if r2.width>1 and r2.height>1:
                pygame.draw.rect(surf,C['obs_fill'],r2,border_radius=2)
                pygame.draw.rect(surf,C['obs'],r2,max(1,d2p(.05)),border_radius=2)
        for ccx,ccy,cr in obs_circles:
            scx,scy=ws(ccx,ccy); sr=max(3,d2p(cr))
            pygame.draw.circle(surf,C['circ_fill'],(scx,scy),sr)
            pygame.draw.circle(surf,C['circ_brd'],(scx,scy),sr,max(2,d2p(.06)))
            # krzyż wewnątrz – pillar style
            pygame.draw.line(surf,C['diag_wall'],(scx-sr//2,scy),(scx+sr//2,scy),1)
            pygame.draw.line(surf,C['diag_wall'],(scx,scy-sr//2),(scx,scy+sr//2),1)
        for x1,y1,x2,y2 in extra_segs:
            pygame.draw.line(surf,C['diag_wall'],ws(x1,y1),ws(x2,y2),2)
        for x1,y1,x2,y2 in walls:
            pygame.draw.line(surf,C['wall'],ws(x1,y1),ws(x2,y2),3)
        pygame.draw.rect(surf,C['wall'],(0,0,pw,ph),2,border_radius=2)
        self._surf=surf; self._zoom=round(z,3); self._key=(cam.mw,cam.mh)
    def blit(self,screen,cam,walls,obs_rect,obs_circles,extra_segs,vx,vy,vw,vh):
        z=round(cam.zoom,3); key=(cam.mw,cam.mh)
        if self._surf is None or z!=self._zoom or key!=self._key:
            self._render(cam,walls,obs_rect,obs_circles,extra_segs)
        sx=int(cam.ox)-vx; sy=int(cam.oy)-vy
        screen.set_clip(pygame.Rect(vx,vy,vw,vh))
        screen.blit(self._surf,(vx+sx,vy+sy))
        screen.set_clip(None)

# =============================================================================
# RYSOWANIE  (robot, sensory, trail, overlay)
# =============================================================================
def draw_sensors(s,cam,p,usl,usr,tofl,tofr,tof_a):
    def uc(d): return C['us_d'] if d<.35 else(C['us_w'] if d<.7 else C['us'])
    def tc(d): return C['tof_d'] if d<.35 else(C['tof_w'] if d<.7 else C['tof'])
    def beam(off_deg,dm,col):
        wa=p.theta+math.radians(off_deg)
        rx,ry=cam.w2s(p.x,p.y); sx,sy=cam.w2s(p.x+dm*math.cos(wa),p.y+dm*math.sin(wa))
        al=wa+math.radians(4.); ar=wa-math.radians(4.)
        pts=[(rx,ry),cam.w2s(p.x+dm*math.cos(al),p.y+dm*math.sin(al)),
             cam.w2s(p.x+dm*math.cos(ar),p.y+dm*math.sin(ar))]
        pygame.draw.polygon(s,lc(col,(10,10,20),.65),pts)
        pygame.draw.line(s,col,(rx,ry),(sx,sy),2)
        if dm<2.9: pygame.draw.circle(s,col,(sx,sy),5); pygame.draw.circle(s,C['text'],(sx,sy),2)
    # us_left mierzony przy theta+US_ANG (lewa strona) → rysuj po lewej (+)
    # us_right mierzony przy theta-US_ANG (prawa strona) → rysuj po prawej (-)
    beam(+US_ANG, min(usl,3.),  uc(usl))
    beam(-US_ANG, min(usr,3.),  uc(usr))
    beam(+tof_a,  min(tofl,2.), tc(tofl))
    beam(-tof_a,  min(tofr,2.), tc(tofr))

def draw_robot(s,cam,p,bumps_state=None,stuck=False):
    cx,cy=cam.w2s(p.x,p.y); R=max(11,cam.d2p(ROBOT_R))
    col_body = C['stuck_ev'] if stuck else C['robot']
    pygame.draw.circle(s,(0,0,0),(cx+2,cy+2),R+3)
    pygame.draw.circle(s,C['robot_dk'],(cx,cy),R+3)
    pygame.draw.circle(s,col_body,(cx,cy),R)
    hl=R*1.6; hx=cx+int(hl*math.cos(p.theta)); hy=cy-int(hl*math.sin(p.theta))
    pygame.draw.line(s,C['heading'],(cx,cy),(hx,hy),3)
    pygame.draw.circle(s,C['heading'],(hx,hy),6)
    wb=cam.d2p(0.13); perp=p.theta+math.pi/2
    for si in(-1,1):
        wx=cx+int(wb*si*math.cos(perp)); wy=cy-int(wb*si*math.sin(perp))
        pygame.draw.circle(s,C['wall'],(wx,wy),max(3,R//3+1))
        pygame.draw.circle(s,C['sep'],(wx,wy),max(2,R//3))
    if bumps_state:
        for zone,off in {'FRONT':0,'RIGHT':-math.pi/2,'BACK':math.pi,'LEFT':math.pi/2}.items():
            if bumps_state.get(zone,0):
                a=p.theta+off; bx=cx+int((R+9)*math.cos(a)); by=cy-int((R+9)*math.sin(a))
                pygame.draw.circle(s,C['bump_hit'],(bx,by),8)

def draw_trail(s,cam,trail):
    pts=list(trail); n=len(pts)
    if n<2: return
    step=2 if n>3000 else 1
    for i in range(step,n,step):
        t=i/n; col=lc(C['trail_t'],C['trail_h'],t)
        pygame.draw.line(s,col,cam.w2s(pts[i-step][0],pts[i-step][1]),cam.w2s(pts[i][0],pts[i][1]),1)

def draw_map_overlay(s,fonts,final_src,phys,cam,fps,paused,spd_lbl,map_lbl,
                     show_l,show_t,follow,tof_a,csv_on,vx,vy):
    F=fonts; x0=vx+10; y0=vy+8
    status="⏸ PAUZA" if paused else f"▶ {spd_lbl}"
    st_c=C['warn'] if paused else C['safe']
    st_i=F['md'].render(status,True,st_c); s.blit(st_i,(x0,y0))
    fps_i=F['sm'].render(f"FPS {fps:.0f}",True,C['safe'] if fps>=25 else C['warn'])
    s.blit(fps_i,(x0+160,y0+2))
    map_i=F['sm'].render(map_lbl,True,C['dim']); s.blit(map_i,(x0+280,y0+2))
    y0+=st_i.get_height()+3
    pc=C['accent'] if 'NEURAL' in final_src else (C['danger'] if any(k in final_src for k in ['HARD','BUMPER','STUCK']) else C['warn'])
    ph_i=F['md'].render(f"⬤ {final_src[:16]}",True,pc)
    rr(s,lc(pc,(8,10,18),.85),(x0,y0,ph_i.get_width()+16,ph_i.get_height()+6),r=5)
    s.blit(ph_i,(x0+8,y0+3)); y0+=ph_i.get_height()+6
    td=math.degrees(phys.theta)%360
    pos_t=F['xs'].render(f"X:{phys.x:.1f} Y:{phys.y:.1f}  θ:{td:.0f}°  v:{phys.v_ms:+.2f}",True,C['dim'])
    s.blit(pos_t,(x0,y0)); y0+=pos_t.get_height()+3
    tog_t=F['xs'].render(f"LIDAR:{'ON' if show_l else 'OFF'}  ŚLAD:{'ON' if show_t else 'OFF'}  CSV:{'●' if csv_on else '○'}  TOF±{tof_a:.0f}°  {'[ŚL]' if follow else '[PAN]'}",True,C['dim'])
    s.blit(tog_t,(x0,y0))

# =============================================================================
# PASEK TELEMETRII
# =============================================================================
class TelBar:
    NCOLS=6
    def __init__(self,fonts):
        self.f=fonts
        self.rw_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.lor_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.ros_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.ds_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.pwml_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.pwmr_h=deque([0.]*HISTORY,maxlen=HISTORY)
        self.usl_h=deque([3.]*80,maxlen=80)
        self.usr_h=deque([3.]*80,maxlen=80)
        # Statystyki sesji
        self._session_steps=0; self._session_t0=time.time()
        self._collision_total=0; self._goal_total=0; self._ep_total=0

    def push(self,brain,pwml,pwmr,rw,usl,usr,collisions,goals,ep):
        self.rw_h.append(rw)
        self.lor_h.append(getattr(getattr(brain,'lorenz',None),'x_norm',0.))
        self.ros_h.append(getattr(getattr(brain,'rossler',None),'x_norm',0.))
        self.ds_h.append(getattr(getattr(brain,'double_scroll',None),'x_norm',0.))
        self.pwml_h.append(pwml/100.); self.pwmr_h.append(pwmr/100.)
        self.usl_h.append(usl); self.usr_h.append(usr)
        self._session_steps+=1; self._collision_total=collisions
        self._goal_total=goals; self._ep_total=ep

    def push_from_diag(self,diag,pwml,pwmr,rw,usl,usr,collisions,goals,ep):
        """Wersja push() pobierająca wartości atraktorów z fast_diag (brain=None)."""
        self.rw_h.append(rw)
        self.lor_h.append(float(diag.get('lorenz_x',  0.0)))
        self.ros_h.append(float(diag.get('rossler_x', 0.0)))
        self.ds_h.append(float(diag.get('dscroll_x',  0.0)))
        self.pwml_h.append(pwml/100.); self.pwmr_h.append(pwmr/100.)
        self.usl_h.append(usl); self.usr_h.append(usr)
        self._session_steps+=1; self._collision_total=collisions
        self._goal_total=goals; self._ep_total=ep

    def draw(self,s,rect,diag,pwml,pwmr,phys,fps,paused,spd_lbl,map_lbl,
             step,usl,usr,tofl,tofr,tof_a,zoom,brain,final_src,stuck_cnt,csv_on):
        rx,ry,rw,rh=rect
        pygame.draw.rect(s,C['panel_bg'],rect)
        pygame.draw.line(s,C['sep'],(rx,ry),(rx+rw,ry),2)
        cw=rw//self.NCOLS
        cols=[rx+i*cw for i in range(self.NCOLS)]
        pad=8; fn=self.f
        for ci in range(1,self.NCOLS):
            pygame.draw.line(s,C['sep'],(rx+ci*cw,ry+4),(rx+ci*cw,ry+rh-4),1)

        # COL 0: STATUS + DIAGNOSTICS
        k=cols[0]+pad; y=ry+6
        st="⏸ PAUZA" if paused else f"▶ {spd_lbl}"
        st_c=C['warn'] if paused else C['safe']; st_i=fn['sm_b'].render(st,True,st_c)
        rr(s,lc(st_c,(8,10,18),.88),(k,y,cw-pad*2,st_i.get_height()+6),r=5)
        s.blit(st_i,st_i.get_rect(center=(k+(cw-pad*2)//2,y+st_i.get_height()//2+3))); y+=st_i.get_height()+8
        s.blit(fn['xs'].render(f"FPS {fps:.0f}  krok {step}",True,C['dim']),(k,y)); y+=16
        pc=C['accent'] if 'NEURAL' in final_src else (C['danger'] if any(q in final_src for q in ['HARD','BUMPER','STUCK']) else C['warn'])
        ph_i=fn['sm'].render(f"⬤ {final_src[:14]}",True,pc)
        rr(s,lc(pc,(8,10,18),.85),(k,y,cw-pad*2,ph_i.get_height()+6),r=5)
        s.blit(ph_i,ph_i.get_rect(center=(k+(cw-pad*2)//2,y+ph_i.get_height()//2+3))); y+=ph_i.get_height()+6
        sc_val=diag.get('slow_conf',0.)
        sc_c=C['safe'] if sc_val>=0.22 else C['dim']
        s.blit(fn['xs'].render(f"SLOW conf {sc_val:.2f}",True,sc_c),(k,y)); y+=14
        hbar(s,(k,y,cw-pad*2,6),min(sc_val,1.),sc_c); y+=10
        td=math.degrees(phys.theta)%360
        for a2,b2 in [(f"X:{phys.x:.2f}",f"Y:{phys.y:.2f}"),(f"θ:{td:.0f}°",f"v:{phys.v_ms:+.2f}")]:
            s.blit(fn['xs'].render(a2,True,C['text']),(k,y))
            s.blit(fn['xs'].render(b2,True,C['text']),(k+cw//2,y)); y+=17
        if stuck_cnt>0:
            s.blit(fn['sm'].render(f" STUCK {stuck_cnt}kr",True,C['stuck_ev']),(k,y)); y+=16
        if diag.get('stagnant'):
            s.blit(fn['xs'].render(f"⚠ STAGNACJA",True,C['warn']),(k,y)); y+=14
        csv_c=C['csv_on'] if csv_on else C['dim']
        s.blit(fn['xs'].render(f"CSV {'●REC' if csv_on else '○OFF'}",True,csv_c),(k,y))

        # COL 1: US + TOF + sesja
        k=cols[1]+pad; y=ry+6
        s.blit(fn['xs'].render("━ SENSORY ━",True,C['accent']),(k,y)); y+=17
        gr=min(32,(cw-pad*2)//4)
        for i,(lb,d,mx2,co) in enumerate([("US-L",usl,3.,C['us']),("US-R",usr,3.,C['us'])]):
            gcx=k+gr+i*(gr*2+10); gcy=y+gr+2; vn=1.-min(d/mx2,1.)
            gc=C['us_d'] if d<.35 else(C['us_w'] if d<.7 else co)
            gauge(s,gcx,gcy,gr,vn,gc,w=4)
            dv=fn['xs'].render(f"{d:.2f}",True,gc); s.blit(dv,dv.get_rect(center=(gcx,gcy+gr-8)))
            lb2=fn['xs'].render(lb,True,C['dim']); s.blit(lb2,lb2.get_rect(center=(gcx,gcy+gr+5)))
        y+=gr*2+22
        for lb,d,mx2,co in [("TOF-L",tofl,2.,C['tof']),("TOF-R",tofr,2.,C['tof'])]:
            dc=C['tof_d'] if d<.35 else(C['tof_w'] if d<.7 else co)
            s.blit(fn['xs'].render(f"{lb} {d:.2f}m",True,dc),(k,y)); y+=14
            hbar(s,(k,y,cw-pad*2,8),1.-min(d/mx2,1.),dc); y+=12
        y+=4
        dt_sess=time.time()-self._session_t0
        gps=self._goal_total/max(dt_sess,1)
        s.blit(fn['xs'].render(f"EP:{self._ep_total}  Cele:{self._goal_total}",True,C['dim']),(k,y)); y+=14
        s.blit(fn['xs'].render(f"Coll:{self._collision_total}  {gps:.2f}c/s",True,
                               C['danger'] if self._collision_total>50 else C['dim']),(k,y))

        # COL 2: SILNIKI
        k=cols[2]+pad; y=ry+6
        s.blit(fn['xs'].render("━ SILNIKI [PWM%] ━",True,C['dim']),(k,y)); y+=17
        bw2=cw-pad*2
        for lb,pw,co in [("L:",pwml,C['safe']),("R:",pwmr,C['warn'])]:
            s.blit(fn['sm'].render(f"{lb}{pw:+5.1f}",True,C['text']),(k,y))
            bibar(s,(k+62,y,bw2-62,13),pw/100.,C['safe'],C['warn']); y+=17
        wave(s,(k,y,bw2,30),self.pwml_h,C['safe'],th=1)
        wave(s,(k,y,bw2,30),self.pwmr_h,C['warn'],th=1,zl=False); y+=34

        # COL 3: LIDAR ZONES
        k=cols[3]+pad; y=ry+6
        s.blit(fn['xs'].render("━ LIDAR ZONES ━",True,C['ld_far']),(k,y)); y+=17
        lz=diag.get('lidar_zones',{})
        zw3=(cw-pad*2)//4
        for zi,zn in enumerate(['FRONT','RIGHT','BACK','LEFT']):
            zxi=k+zi*(zw3+2); d=lz.get(zn,3.); dn=max(0.,1.-d/3.)
            zc=lc(C['safe'],C['danger'],dn)
            hbar(s,(zxi,y,zw3,12),dn,zc)
            ns=fn['xs'].render(zn[:3],True,C['dim']); s.blit(ns,ns.get_rect(center=(zxi+zw3//2,y+22)))
            ds2=fn['xs'].render(f"{d:.1f}",True,zc); s.blit(ds2,ds2.get_rect(center=(zxi+zw3//2,y+36)))
        y+=52
        # Min dist bar
        md=diag.get('min_dist',3.); mdc=C['danger'] if md<.4 else(C['warn'] if md<.8 else C['safe'])
        s.blit(fn['xs'].render(f"min_d {md:.2f}m",True,mdc),(k,y)); y+=14
        hbar(s,(k,y,cw-pad*2,8),max(0.,1.-md/3.),mdc)

        # COL 4: NAGRODA
        k=cols[4]+pad; y=ry+6
        s.blit(fn['xs'].render("━ NAGRODA ━",True,C['dim']),(k,y)); y+=17
        rw2=diag.get('last_reward',0.); rw_c=C['rw_p'] if rw2>=0 else C['rw_n']
        s.blit(fn['sm_b'].render(f"rw  {rw2:+.3f}",True,rw_c),(k,y)); y+=18
        rw_wave(s,(k,y,cw-pad*2,42),self.rw_h); y+=46
        _esc_st=diag.get('safety_state',0); _esc_cyc=diag.get('safety_cycles_left',0)
        if _esc_st==1:
            s.blit(fn['sm'].render(f"⬅ COFA ({_esc_cyc})",True,C['danger']),(k,y)); y+=16
        elif _esc_st==2:
            s.blit(fn['sm'].render(f"↻ OBRÓT ({_esc_cyc})",True,C['warn']),(k,y)); y+=16
        _osc=diag.get('oscillating',False); _osc_cnt=diag.get('osc_count',0)
        if _osc: s.blit(fn['xs'].render(f"⟷ OSCYLACJA #{_osc_cnt}",True,C['danger']),(k,y))

        # COL 5: ATRAKTORY
        k=cols[5]+pad; y=ry+6
        s.blit(fn['xs'].render("━ ATRAKTORY ━",True,C['dim']),(k,y)); y+=17
        ww2=cw-pad*2; ah=28
        for lb,h,co in [("Lorenz",self.lor_h,C['lorenz']),
                        ("Rössler",self.ros_h,C['rossler']),
                        ("DblScrl",self.ds_h,C['dscroll'])]:
            s.blit(fn['sm'].render(lb,True,co),(k,y)); y+=14
            wave(s,(k,y,ww2,ah),h,co,th=2); y+=ah+5
        # DS state machine visualization – odczyt z diag (brain nie dostępny)
        ds_mode = str(diag.get('dscroll_mode', 'IDLE'))
        ds_amp  = float(diag.get('dscroll_amp', 0.85))
        mode_col = {'BOOST':C['danger'],'RELEASE':C['warn'],
                    'CROSSOVER':C['rossler'],'IDLE':C['dim']}.get(ds_mode, C['dim'])
        s.blit(fn['xs'].render(f"MODE:{ds_mode}  A={ds_amp:+.2f}",True,mode_col),(k,y)); y+=14
        amp_n = max(0., min(1., (ds_amp + 1.8) / 3.6))
        hbar(s,(k,y,ww2,7),amp_n,mode_col); y+=10
        # Wartości bieżące
        lor_v = float(diag.get('lorenz_x',0)); ros_v = float(diag.get('rossler_x',0))
        ds_v  = float(diag.get('dscroll_x',0))
        s.blit(fn['xs'].render(f"L:{lor_v:+.3f} R:{ros_v:+.3f} D:{ds_v:+.3f}",
                               True,C['dim']),(k,y)); y+=12
        # Predyktor
        p_mae  = float(diag.get('predictor_mae', 0))
        p_conf = float(diag.get('predictor_conf',0))
        pc2 = C['safe'] if p_mae < 0.3 else (C['warn'] if p_mae < 0.6 else C['danger'])
        s.blit(fn['xs'].render(f"PRED mae:{p_mae:.3f} conf:{p_conf:.2f}",True,pc2),(k,y))

# =============================================================================
# PRZYCISKI
# =============================================================================
class Btn:
    def __init__(self,rect,label,icon='',color=None,font=None,r=8):
        self.rect=pygame.Rect(rect); self.label=label; self.icon=icon
        self.color=color or C['btn_bg']; self.font=font; self.r=r; self._t=0.
    def draw(self,s):
        col=C['btn_hi'] if time.time()-self._t<.18 else self.color
        pygame.draw.rect(s,col,self.rect,border_radius=self.r)
        pygame.draw.rect(s,C['btn_brd'],self.rect,1,border_radius=self.r)
        if self.font:
            lb=(self.icon+' '+self.label).strip() if self.icon else self.label
            img=self.font.render(lb,True,C['btn_txt']); s.blit(img,img.get_rect(center=self.rect.center))
    def hit(self,pos): return self.rect.collidepoint(pos)
    def press(self): self._t=time.time()

def mk_btns(bar_rect,f):
    bx,by,bw,bh=bar_rect; row_h=(bh-10)//2; mg=5; col_w=(bw-mg*7)//6
    R1=[('pause',"PAUZA","⏸",None),('map',"MAPA","🗺",None),
        ('reset',"RESET","↺",None),('fit',"FIT","⊞",None),
        ('lidar',"LIDAR","📡",None),('trail',"ŚLAD","〰",None)]
    R2=[('csv',"CSV","⏺",None),('tof_dn',"TOF−","◄",(32,25,52)),
        ('tof_up',"TOF+","►",(32,25,52)),('spd_dn',"SPD−","",( 22,38,22)),
        ('spd_up',"SPD+","+",(22,38,22)),('quit',"WYJŚCIE","✕",(50,20,20))]
    btns={}
    for row_i,row in enumerate([R1,R2]):
        ry2=by+mg+row_i*(row_h+mg)
        for ci,(key,lbl,icon,col) in enumerate(row):
            bx2=bx+mg+ci*(col_w+mg)
            btns[key]=Btn((bx2,ry2,col_w,row_h),lbl,icon,color=col,font=f,r=8)
    return btns

# =============================================================================
# KLASA SYMULACJI  ArenaEval
# =============================================================================
# =============================================================================
# ArenaEnv – czyste środowisko symulacji
# Obowiązki: fizyka robota, odczyty sensorów, rendering pygame
# BEZ mózgu, BEZ CSV, BEZ nagród, BEZ VML
# Interfejs:
#   env = ArenaEnv(map_name)
#   sensors = env.reset()
#   sensors = env.step(pwm_l, pwm_r)
#   running = env.render(pwm_l, pwm_r, action_name, source, fast_diag, slow_diag, **opts)
# =============================================================================
def _draw_goal(screen, cam, gx, gy, phys, flash, font=None):
    """
    Rysuje punkt docelowy:
    - Pulsujące okręgi (żółte → zielone po trafieniu)
    - Krzyż celowniczy
    - Linia od robota do celu
    - Etykieta z dystansem
    """
    sx, sy = cam.w2s(gx, gy)
    z      = cam.zoom

    hit_col  = C['goal_reach']
    ring_col = hit_col if flash > 0 else C['goal_ring']
    fill_col = lc(hit_col, C['goal'], 0.5) if flash > 0 else C['goal']

    # Pulsacja: przy trafieniu promień rośnie i zanika
    pulse = (flash / 25.0) if flash > 0 else 0.0
    r_base = max(6, int(1.2 * z))
    r_outer = r_base + int(pulse * r_base * 1.8)

    # Zewnętrzny pierścień (pulsuje)
    if r_outer > r_base:
        s2 = pygame.Surface((r_outer*2+4, r_outer*2+4), pygame.SRCALPHA)
        alpha = int(180 * pulse)
        pygame.draw.circle(s2, (*ring_col, alpha), (r_outer+2, r_outer+2), r_outer, 2)
        screen.blit(s2, (sx - r_outer - 2, sy - r_outer - 2))

    # Środkowe kółko
    pygame.draw.circle(screen, fill_col, (sx, sy), r_base)
    pygame.draw.circle(screen, ring_col, (sx, sy), r_base, 2)

    # Krzyż celowniczy
    arm = max(10, int(2.0 * z))
    gap = max(3,  int(0.5 * z))
    pygame.draw.line(screen, ring_col, (sx - arm, sy), (sx - gap, sy), 2)
    pygame.draw.line(screen, ring_col, (sx + gap, sy), (sx + arm, sy), 2)
    pygame.draw.line(screen, ring_col, (sx, sy - arm), (sx, sy - gap), 2)
    pygame.draw.line(screen, ring_col, (sx, sy + gap), (sx, sy + arm), 2)

    # Linia robot → cel
    rx, ry = cam.w2s(phys.x, phys.y)
    dist   = math.hypot(gx - phys.x, gy - phys.y)
    line_col = lc(C['goal'], C['goal_reach'], max(0., 1. - dist / 20.))
    pygame.draw.line(screen, (*line_col, 80), (rx, ry), (sx, sy), 1)

    # Etykieta dystansu
    if font is not None:
        lbl = font.render(f"{dist:.1f}m", True, ring_col)
        screen.blit(lbl, (sx + r_base + 4, sy - lbl.get_height()//2))


class ArenaEnv:
    def __init__(self, map_name: str = 'box', headless: bool = False):
        self.map_name  = map_name
        self.map_idx   = MAPS_LIST.index(map_name) if map_name in MAPS_LIST else 0
        self.headless  = headless
        self._tof_a    = TOF_ANG_DEF
        self._screen   = None
        self._clock    = None
        self._fonts    = {}
        self._btns     = {}
        self._cam      = None
        self._mc       = None
        self._touch    = None
        self._paused   = False
        self._spd_i    = 2
        self._show_l   = True
        self._show_t   = True
        self._follow   = True
        self._panning  = False
        self.trail     = deque(maxlen=25000)
        self.episode   = 0
        self.total_steps = 0
        self.collisions  = 0
        self._prev_collide = False
        self._build_map()
        if not headless:
            self._init_pygame()

    # ── Budowa mapy ────────────────────────────────────────────────────
    def _build_map(self):
        mt = MAPS_LIST[self.map_idx % len(MAPS_LIST)]
        self.map_name  = mt
        self._map_seed = random.randint(0, 2**31)   # nowy seed = nowa wariacja
        result = MAP_BUILDERS[mt](seed=self._map_seed, jitter=MAP_JITTER)
        self.walls, self.obs_rect, self.obs_circles, self.extra_segs, self.mw, self.mh = result
        self.all_segs = list(self.walls) + list(self.extra_segs)
        for ox, oy, w, h in self.obs_rect:
            self.all_segs += [(ox,oy,ox+w,oy),(ox+w,oy,ox+w,oy+h),
                              (ox+w,oy+h,ox,oy+h),(ox,oy+h,ox,oy)]
        sx = self.mw / 2 + random.uniform(-1, 1)
        sy = self.mh / 2 + random.uniform(-1, 1)
        self.phys = RobotPhysics(x=sx, y=sy, theta=random.uniform(-math.pi, math.pi))
        self._stuck_cnt = 0; self._stuck_lx = sx; self._stuck_ly = sy
        self._steps_on_map = 0   # licznik kroków na bieżącej mapie (auto-advance)
        self.trail.clear()
        self.usl = self.usr = 3.0
        # Cel (tylko dla mapy 'open') ─────────────────────────────────────────
        self.goals_reached = 0
        self._goal_flash   = 0   # klatki efektu trafienia (rendering)
        if mt == 'open':
            self._spawn_goal()
        else:
            self.goal_x = None
            self.goal_y = None
        self.tofl = self.tofr = 2.0

    def _spawn_goal(self):
        """Losuje nową pozycję celu w wolnym miejscu mapy (open map)."""
        GOAL_R     = 1.2   # promień strefy dotknięcia celu [m]
        MIN_DIST   = 8.0   # minimalna odległość od robota przy spawnie
        for _ in range(300):
            gx = random.uniform(3., self.mw - 3.)
            gy = random.uniform(3., self.mh - 3.)
            # Nie bliżej niż MIN_DIST od robota
            if math.hypot(gx - self.phys.x, gy - self.phys.y) < MIN_DIST:
                continue
            # Nie w środku żadnej przeszkody prostokątnej
            in_obs = any(ox <= gx <= ox+ow and oy <= gy <= oy+oh
                         for (ox, oy, ow, oh) in self.obs_rect)
            # Nie w środku żadnej kolumny
            in_circ = any(math.hypot(gx-cx, gy-cy) < cr + 0.5
                          for (cx, cy, cr) in self.obs_circles)
            if not in_obs and not in_circ:
                self.goal_x = gx
                self.goal_y = gy
                return
        # Fallback: środek mapy
        self.goal_x = self.mw / 2
        self.goal_y = self.mh / 2

    def _init_pygame(self):
        if not pygame.get_init(): pygame.init()
        W, H = TARGET_W, TARGET_H
        self._screen = pygame.display.set_mode((W, H), pygame.RESIZABLE)
        pygame.display.set_caption(
            f'SWARM Arena – {MAP_LABELS.get(self.map_name, self.map_name)}'
            f'  [seed {self._map_seed & 0xFFFF:04X}]'
        )
        self._clock  = pygame.time.Clock()
        self._fonts  = {k: mkf(sz, bd) for k, sz, bd in [
            ('hd',34,True),('lg',27,True),('md',23,False),
            ('sm',20,False),('sm_b',20,True),('xs',17,False)]}
        self._cam   = Camera(self._map_rect(), self.mw, self.mh)
        self._mc    = MapCache()
        self._btns  = mk_btns(self._btn_rect(), self._fonts['sm_b'])
        self._tel   = TelBar(self._fonts)
        self._touch = TouchTracker()
        self._fps_t = time.time(); self._fps_n = 0; self._fps_d = 30.0
        self._running = True

    def _map_rect(self):
        W2, H2 = self._screen.get_size(); return (0, 0, W2, H2 - TEL_H - BTN_H)
    def _tel_rect(self):
        W2, H2 = self._screen.get_size(); return (0, H2 - TEL_H - BTN_H, W2, TEL_H)
    def _btn_rect(self):
        W2, H2 = self._screen.get_size(); return (0, H2 - BTN_H, W2, BTN_H)

    # ── Publiczny interfejs środowiska ──────────────────────────────────
    def reset(self) -> dict:
        """Resetuje pozycję robota. Zwraca surowy sensor_dict."""
        p = self.phys
        sx = self.mw / 2 + random.uniform(-1, 1)
        sy = self.mh / 2 + random.uniform(-1, 1)
        p.x = sx; p.y = sy; p.theta = random.uniform(-math.pi, math.pi)
        p._pwm_l = 0.; p._pwm_r = 0.; p.vl = 0.; p.vr = 0.
        self._stuck_cnt = 0; self._stuck_lx = sx; self._stuck_ly = sy
        self.trail.clear(); self.episode += 1
        return self._read_sensors()

    def step(self, pwm_l: float, pwm_r: float, dt: float = DT) -> dict:
        """
        Wykonuje krok fizyczny z zadanym PWM.
        Zwraca surowy sensor_dict (metry, ticki, 0/1).
        BEZ decyzji, BEZ nagrody.
        """
        p = self.phys
        p.update(float(pwm_l), float(pwm_r), dt)
        x_b, y_b = p.x, p.y
        resolve_collisions(p, self.all_segs)
        clamp_to_map(p, self.mw, self.mh)
        # Detekcja kolizji
        if abs(p.x - x_b) > 0.003 or abs(p.y - y_b) > 0.003:
            if not self._prev_collide: self.collisions += 1
            self._prev_collide = True
        else:
            self._prev_collide = False
        # Stuck detection (czysty – tylko pozycja)
        if (abs(p.x - self._stuck_lx) < 0.005 and abs(p.y - self._stuck_ly) < 0.005):
            self._stuck_cnt += 1
        else:
            self._stuck_cnt = 0
        self._stuck_lx = p.x; self._stuck_ly = p.y
        self.trail.append((p.x, p.y))
        self.total_steps += 1
        self._steps_on_map += 1

        # Detekcja trafienia w cel (tylko mapa 'open')
        if self.map_name == 'open' and self.goal_x is not None:
            dist_goal = math.hypot(p.x - self.goal_x, p.y - self.goal_y)
            if dist_goal < 1.2:   # promień trafienia = 1.2 m
                self.goals_reached += 1
                self._goal_flash = 25   # klatki efektu trafienia
                print(f"[GOAL] trafiony #{self.goals_reached}  "
                      f"({self.goal_x:.1f},{self.goal_y:.1f})  "
                      f"krok={self.total_steps}")
                self._spawn_goal()
        if self._goal_flash > 0:
            self._goal_flash -= 1

        # Auto-advance: przejdź na następną mapę po AUTO_ADVANCE_STEPS krokach
        if AUTO_ADVANCE_STEPS > 0 and self._steps_on_map >= AUTO_ADVANCE_STEPS:
            self.map_idx = (self.map_idx + 1) % len(MAPS_LIST)
            self._build_map()
            print(f"[AUTO-ADVANCE] → {self.map_name.upper()}  seed={self._map_seed}")
            if not self.headless and self._cam is not None:
                self._cam.__init__(self._map_rect(), self.mw, self.mh)
            if not self.headless and self._mc is not None:
                self._mc.__init__()
            if not self.headless and self._screen is not None:
                lbl = MAP_LABELS.get(self.map_name, self.map_name)
                pygame.display.set_caption(f'SWARM Arena – {lbl}  [seed {self._map_seed & 0xFFFF:04X}]')

        sensors = self._read_sensors()
        return sensors

    def _read_sensors(self) -> dict:
        """Surowe odczyty sensorów – format identyczny jak ESP32.
        build_sensors() używa stałego TOF_ANG_DEF.
        Jeśli użytkownik zmienił _tof_a, nadpisujemy ToF tutaj.
        """
        p = self.phys
        sd = build_sensors(p, self.all_segs)
        # Nadpisz ToF jeśli kąt zmieniony przez użytkownika (przycisk tof_dn/tof_up)
        if abs(self._tof_a - TOF_ANG_DEF) > 0.1:
            ang_tof = math.radians(self._tof_a)
            sd['tof_left']  = ray_cast(self.all_segs, p.x, p.y, p.theta + ang_tof, 2.)
            sd['tof_right'] = ray_cast(self.all_segs, p.x, p.y, p.theta - ang_tof, 2.)
        # Cache US/ToF dla renderera
        self.usl  = sd['us_left']; self.usr  = sd['us_right']
        self.tofl = sd['tof_left']; self.tofr = sd['tof_right']
        # Informacja o celu (otwarta przestrzeń) – do ewentualnego użycia przez mózg
        if self.map_name == 'open' and self.goal_x is not None:
            dx = self.goal_x - self.phys.x
            dy = self.goal_y - self.phys.y
            sd['target_dist_m']      = float(math.hypot(dx, dy))
            bearing = math.atan2(dy, dx) - self.phys.theta
            bearing = math.atan2(math.sin(bearing), math.cos(bearing))  # normalizacja ±π
            sd['target_bearing_deg'] = float(math.degrees(bearing))
        else:
            sd['target_dist_m']      = -1.0
            sd['target_bearing_deg'] = 0.0
        return sd

    # ── Rendering pygame ────────────────────────────────────────────────
    def render(self,
               pwm_l: float, pwm_r: float,
               action_name: str, source: str,
               fast_diag: dict, slow_diag: dict,
               bumps: dict = None) -> bool:
        """
        Rysuje klatkę. Obsługuje zdarzenia pygame.
        Zwraca False gdy użytkownik zamknie okno / naciśnie ESC/Q.
        Wywołaj co krok symulacji z main.py.
        """
        if self.headless or self._screen is None:
            return True

        W2, H2 = self._screen.get_size()
        MR = self._map_rect(); TR = self._tel_rect(); BR = self._btn_rect()

        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: return False
            elif ev.type == pygame.MOUSEWHEEL:
                mx, my = pygame.mouse.get_pos()
                self._cam.zoom_at(mx, my, 1.15 if ev.y > 0 else 1/1.15)
                self._follow = False
            elif ev.type == pygame.MOUSEBUTTONDOWN:
                if ev.button in (2, 3): self._cam.pan_start(*ev.pos); self._panning = True
                elif ev.button == 1:
                    for key, btn in self._btns.items():
                        if btn.hit(ev.pos): btn.press(); self._handle_btn(key); break
            elif ev.type == pygame.MOUSEBUTTONUP:
                if ev.button in (2, 3): self._cam.pan_end(); self._panning = False
            elif ev.type == pygame.MOUSEMOTION:
                if self._panning: self._cam.pan_move(*ev.pos); self._follow = False
            elif ev.type == pygame.FINGERDOWN:
                px, py = int(ev.x*W2), int(ev.y*H2)
                if py > H2 - BTN_H:
                    for key, btn in self._btns.items():
                        if btn.hit((px, py)): btn.press(); self._handle_btn(key); break
                else: self._touch.down(ev.finger_id, px, py)
            elif ev.type == pygame.FINGERUP: self._touch.up(ev.finger_id)
            elif ev.type == pygame.FINGERMOTION:
                px, py = int(ev.x*W2), int(ev.y*H2)
                res = self._touch.move(ev.finger_id, px, py, W2, H2, self._cam, MR[3])
                if res == 'pan': self._follow = False
            elif ev.type == pygame.KEYDOWN:
                k = ev.key
                if k in (pygame.K_ESCAPE, pygame.K_q): return False
                elif k == pygame.K_SPACE: self._paused = not self._paused
                elif k == pygame.K_m: self._handle_btn('map')
                elif k == pygame.K_r: self._handle_btn('reset')
                elif k in (pygame.K_HOME, pygame.K_KP0): self._cam.fit(); self._follow = True
                elif k == pygame.K_f: self._follow = not self._follow
                elif k in (pygame.K_PLUS, pygame.K_EQUALS, pygame.K_KP_PLUS):
                    self._spd_i = min(self._spd_i+1, len(SPEEDS)-1)
                elif k in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    self._spd_i = max(self._spd_i-1, 0)
                elif k == pygame.K_l: self._show_l = not self._show_l
                elif k == pygame.K_t: self._show_t = not self._show_t
                elif k in (pygame.K_LEFTBRACKET,): self._tof_a = max(TOF_MIN, self._tof_a - 5.)
                elif k in (pygame.K_RIGHTBRACKET,): self._tof_a = min(TOF_MAX, self._tof_a + 5.)
            elif ev.type == pygame.VIDEORESIZE:
                self._screen = pygame.display.set_mode((ev.w, ev.h), pygame.RESIZABLE)
                self._cam.resize(MR); self._btns = mk_btns(BR, self._fonts['sm_b'])

        self._cam.resize(MR)
        if self._follow:
            self._cam.follow(self.phys.x, self.phys.y, margin_px=120)

        self._screen.fill(C['bg'])
        self._screen.set_clip(pygame.Rect(MR))
        self._mc.blit(self._screen, self._cam,
                      self.walls, self.obs_rect, self.obs_circles, self.extra_segs,
                      MR[0], MR[1], MR[2], MR[3])

        if self._show_t: draw_trail(self._screen, self._cam, self.trail)

        # Cel (mapa open) ─────────────────────────────────────────────────────
        if self.map_name == 'open' and self.goal_x is not None:
            _draw_goal(self._screen, self._cam, self.goal_x, self.goal_y,
                       self.phys, self._goal_flash, self._fonts.get('sm'))

        if self._show_l:
            p = self.phys
            for i in range(16):
                ang = p.theta + math.radians(i * 22.5)
                d   = ray_cast(self.all_segs, p.x, p.y, ang, 6.)
                ep  = self._cam.w2s(p.x + d*math.cos(ang), p.y + d*math.sin(ang))
                occ = max(0., min(1., 1. - d/6.))
                col = lc(C['ld_far'], C['ld_near'], occ)
                pygame.draw.line(self._screen, col, self._cam.w2s(p.x, p.y), ep, 1)
                if occ > 0.6: pygame.draw.circle(self._screen, C['ld_near'], ep, 3)

        draw_sensors(self._screen, self._cam, self.phys,
                     self.usl, self.usr, self.tofl, self.tofr, self._tof_a)
        draw_robot(self._screen, self._cam, self.phys,
                   bumps or {}, stuck=(self._stuck_cnt > 0))
        self._screen.set_clip(None)

        final_src = f"{source}"
        draw_map_overlay(self._screen, self._fonts, final_src, self.phys,
                         self._cam, self._fps_d, self._paused,
                         SPD_L[self._spd_i], MAP_LABELS.get(self.map_name, self.map_name),
                         self._show_l, self._show_t, self._follow,
                         self._tof_a, False, MR[0], MR[1])

        # TelBar: atraktory i reward z fast_diag (brain żyje w main.py)
        self._tel.push_from_diag(fast_diag, pwm_l, pwm_r,
                                  fast_diag.get('last_reward', 0.0),
                                  self.usl, self.usr,
                                  self.collisions, self.goals_reached, self.episode)
        self._tel.draw(self._screen, TR, fast_diag, pwm_l, pwm_r, self.phys,
                       self._fps_d, self._paused, SPD_L[self._spd_i],
                       MAP_LABELS.get(self.map_name, self.map_name),
                       self.total_steps, self.usl, self.usr, self.tofl, self.tofr,
                       self._tof_a, self._cam.zoom, None, source, self._stuck_cnt, False)

        pygame.draw.rect(self._screen, C['panel_bg'], BR)
        pygame.draw.line(self._screen, C['sep'], (0, BR[1]), (W2, BR[1]), 2)
        for key, btn in self._btns.items():
            if key == 'pause': btn.label = 'WZNÓW' if self._paused else 'PAUZA'
            btn.draw(self._screen)

        pygame.display.flip()
        self._clock.tick(TARGET_FPS)
        self._fps_n += 1
        if time.time() - self._fps_t >= 1.:
            self._fps_d = self._fps_n / (time.time() - self._fps_t)
            self._fps_n = 0; self._fps_t = time.time()
        return True

    def _handle_btn(self, key: str):
        if key == 'map':
            self.map_idx = (self.map_idx + 1) % len(MAPS_LIST)
            self._build_map()
            self._cam.__init__(self._map_rect(), self.mw, self.mh)
            self._mc.__init__(); self._follow = True
            lbl = MAP_LABELS.get(self.map_name, self.map_name)
            pygame.display.set_caption(f'SWARM Arena – {lbl}  [seed {self._map_seed & 0xFFFF:04X}]')
        elif key == 'reset':
            self.reset()
            self._mc.__init__(); self._cam.fit(); self._follow = True
        elif key == 'fit':   self._cam.fit(); self._follow = True
        elif key == 'lidar': self._show_l = not self._show_l
        elif key == 'trail': self._show_t = not self._show_t
        elif key == 'tof_dn': self._tof_a = max(TOF_MIN, self._tof_a - 5.)
        elif key == 'tof_up': self._tof_a = min(TOF_MAX, self._tof_a + 5.)
        elif key == 'spd_dn': self._spd_i = max(self._spd_i - 1, 0)
        elif key == 'spd_up': self._spd_i = min(self._spd_i + 1, len(SPEEDS) - 1)
        elif key == 'quit':  pass  # main.py obsługuje quit przez render() → False

    def is_paused(self) -> bool: return self._paused
    def speed_multiplier(self) -> float: return SPEEDS[self._spd_i]
    def close(self):
        if self._screen: pygame.quit()

class TouchTracker:
    def __init__(self): self._t={}; self._pd=None
    def down(self,fid,x,y): self._t[fid]=(x,y); self._upd()
    def up(self,fid): self._t.pop(fid,None); self._pd=None
    def move(self,fid,x,y,W,H,cam,map_h):
        old=self._t.get(fid); self._t[fid]=(x,y)
        if len(self._t)==1 and old:
            if y<map_h:
                cam.pan_by(x-old[0],y-old[1]); return 'pan'
        elif len(self._t)==2: return self._pinch(cam)
        return None
    def _upd(self):
        if len(self._t)==2:
            pts=list(self._t.values())
            self._pd=math.hypot(pts[1][0]-pts[0][0],pts[1][1]-pts[0][1])
    def _pinch(self,cam):
        pts=list(self._t.values()); d=math.hypot(pts[1][0]-pts[0][0],pts[1][1]-pts[0][1])
        if self._pd and self._pd>10:
            cx=(pts[0][0]+pts[1][0])//2; cy=(pts[0][1]+pts[1][1])//2
            cam.zoom_at(cx,cy,d/self._pd)
        self._pd=d; return 'pinch'

# =============================================================================
# MAIN
# =============================================================================
def main():
    """Shortcut: uruchamia system w trybie arena (identyczny z: python main.py --arena)."""
    import sys
    # Wstrzyknij --arena do argv i przekaż do main.py
    if '--arena' not in sys.argv:
        sys.argv.insert(1, '--arena')
    try:
        import main as _main
        _main.main()
    except Exception as e:
        import traceback
        # Zapisz błąd do pliku – widoczny na Androidzie gdzie konsola jest ukryta
        with open('cdc_crash.log', 'a') as f:
            import time
            f.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] arena_eval.main() crash:\n")
            traceback.print_exc(file=f)
        raise


if __name__ == '__main__':
    main()
