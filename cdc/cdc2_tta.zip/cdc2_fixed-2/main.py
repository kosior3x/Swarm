#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
main.py – CDC v1.3.7  |  Jedyny orkiestrator systemu
====================================================
Zmiany względem v1.2:
  [v1.3.7 – lifelong learning]
  - Usunięto jawne fast.load() / slow.load() – konstruktory wczytują stan automatycznie
  - Dodano flagę --force-new do resetowania wszystkich sieci
  - Lepsze logowanie wczytywania/zapisu

Tryby:
  python main.py [kroki] [mapa]           – headless (brak pygame)
  python main.py --arena [kroki] [mapa]   – arena z pygame
  python main.py --force-new ...          – wymusza reset wag

Każdy błąd jest zapisywany do cdc_crash.log (widoczny na Androidzie).
"""

import sys
import os
import time
import traceback

# ── Log startowy – zawsze widoczny nawet gdy konsola ukryta (Android) ─────────
_LOG = 'cdc_crash.log'


def _log(msg: str):
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    try:
        with open(_LOG, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass


def _crash(exc: Exception):
    _log(f"CRASH: {type(exc).__name__}: {exc}")
    try:
        with open(_LOG, 'a', encoding='utf-8') as f:
            traceback.print_exc(file=f)
    except Exception:
        pass
    traceback.print_exc()


# =============================================================================
# IMPORTY MÓZGU – z crash logging
# =============================================================================
try:
    import csv
    import math
    from collections import deque
    from datetime import datetime
    from typing import Dict, Any, Optional, Tuple
    import numpy as np
    _log("numpy OK")
except Exception as e:
    _crash(e); sys.exit(1)

try:
    from config import SwarmConfig
    from swarm_fast import SwarmFastBrain, Action
    from swarm_slow import SwarmSlowBrain, SlowConfig
    _log("Brain modules OK")
except Exception as e:
    _crash(e); sys.exit(1)


# =============================================================================
# WBUDOWANY SYMULATOR HEADLESS
# =============================================================================

def _ray_seg(rx, ry, rdx, rdy, x1, y1, x2, y2) -> Optional[float]:
    sdx = x2 - x1; sdy = y2 - y1
    d = rdx * sdy - rdy * sdx
    if abs(d) < 1e-12: return None
    t = ((x1 - rx) * sdy - (y1 - ry) * sdx) / d
    u = ((x1 - rx) * rdy - (y1 - ry) * rdx) / d
    return t if (t > 1e-4 and 0.0 <= u <= 1.0) else None


def _cast(x, y, angle, segs, max_r=3.0) -> float:
    dx = math.cos(angle); dy = math.sin(angle)
    best = max_r
    for seg in segs:
        t = _ray_seg(x, y, dx, dy, *seg)
        if t is not None and t < best:
            best = t
    return best


def _box(ox, oy, w, h):
    return [(ox,oy,ox+w,oy),(ox+w,oy,ox+w,oy+h),(ox+w,oy+h,ox,oy+h),(ox,oy+h,ox,oy)]


def _build_map(name: str) -> Tuple[list, Tuple[float, float, float]]:
    if name == 'corridor':
        s = _box(0,0,20,4); s += [(8,0,8,2.8),(12,1.2,12,4)]; return s,(1.5,2,0)
    elif name == 'box':
        s = _box(0,0,14,14)
        for o in [(3,3,2,2),(9,3,2,2),(3,9,2,2),(9,9,2,2),(6,5.5,2,3)]: s += _box(*o)
        return s,(1.5,1.5,0.3)
    elif name == 'maze':
        s = _box(0,0,18,18)
        for o in [(2,2,1,8),(4,4,8,1),(4,4,1,6),(9,4,1,8),(4,10,6,1),
                  (12,2,1,9),(14,4,1,9),(2,14,11,1)]: s += _box(*o)
        return s,(1,1,0)
    else:
        s = _box(0,0,20,20)
        for o in [(4,4,1,5),(10,2,1,4),(14,8,1,5),(3,12,6,1),(12,13,5,1)]: s += _box(*o)
        return s,(1.5,1.5,0)


_ENC_TICK_M = 0.015   # 1.5 cm / tick


class _HeadlessSim:
    WB = 0.28; MS = 0.75; R = 0.18; LMAX = 3.0
    _US  = math.radians(18)
    _TOF = math.radians(30)

    def __init__(self, segs, start):
        self.segs = segs
        self.x, self.y, self.theta = float(start[0]), float(start[1]), float(start[2])
        self._vl = 0.0; self._vr = 0.0
        self.collisions = 0; self.episode = 0; self._prev_coll = False

    def reset(self) -> dict:
        self._vl = self._vr = 0.0; self.episode += 1
        return self._sensors(0.033)

    def step(self, pwm_l: float, pwm_r: float, dt: float = 0.033) -> dict:
        self._vl = float(np.clip(pwm_l/100, -1, 1)) * self.MS
        self._vr = float(np.clip(pwm_r/100, -1, 1)) * self.MS
        v = (self._vl + self._vr) * 0.5
        w = (self._vr - self._vl) / self.WB
        self.theta += w * dt
        self.theta = math.atan2(math.sin(self.theta), math.cos(self.theta))
        self.x += v * math.cos(self.theta) * dt
        self.y += v * math.sin(self.theta) * dt
        self._pushout()
        return self._sensors(dt)

    def _pushout(self):
        R = self.R
        for (x1,y1,x2,y2) in self.segs:
            dx=x2-x1; dy=y2-y1; l2=dx*dx+dy*dy
            if l2 < 1e-12: continue
            t = max(0., min(1., ((self.x-x1)*dx + (self.y-y1)*dy) / l2))
            nx = self.x-(x1+t*dx); ny = self.y-(y1+t*dy); d2 = nx*nx+ny*ny
            if d2 < R*R:
                d = math.sqrt(d2) if d2 > 1e-12 else 1e-9
                p = (R-d+0.004)/d; self.x += nx*p; self.y += ny*p

    def _sensors(self, dt: float) -> dict:
        x, y, th = self.x, self.y, self.theta; MAX = self.LMAX
        step = 2*math.pi/16
        pts = [(math.degrees(i*step)%360, _cast(x,y,th+i*step,self.segs,MAX)) for i in range(16)]
        d_f = _cast(x, y, th,          self.segs, 0.35)
        d_r = _cast(x, y, th+math.pi, self.segs, 0.30)
        return {
            'lidar_points': pts,
            'us_left':      _cast(x, y, th+self._US,  self.segs, 3.),
            'us_right':     _cast(x, y, th-self._US,  self.segs, 3.),
            'tof_left':     _cast(x, y, th+self._TOF, self.segs, 2.),
            'tof_right':    _cast(x, y, th-self._TOF, self.segs, 2.),
            'encoder_l':    int(round(self._vl * dt / _ENC_TICK_M)),
            'encoder_r':    int(round(self._vr * dt / _ENC_TICK_M)),
            'bumper_front': 1 if d_f < self.R + 0.04 else 0,
            'rear_bumper':  1 if d_r < self.R + 0.04 else 0,
        }


# =============================================================================
# CSV
# =============================================================================

_CSV_COLS = [
    'step','episode','t_s','x','y','theta_deg',
    'pwm_l','pwm_r','action','source',
    'reward','ep_reward','epsilon',
    'min_dist','lidar_front_m','lidar_left_m','lidar_right_m','lidar_back_m',
    'lidar_left_min','lidar_right_min',
    'us_left','us_right','tof_left','tof_right',
    'bumper_front','bumper_rear',
    'collisions','stuck_cnt',
    'slow_action','slow_conf','vml_active','vml_id',
    'ice_concepts','mem_cells',
    'predictor_mae','predictor_conf',
    'brain_speed','brain_steer',
    'lorenz_x','rossler_x','dscroll_x','dscroll_mode','dscroll_amp',
    'pwm_dl','pwm_dr',
]


def _csv_row(step, episode, t, env, pwm_l, pwm_r,
             action, source, sensors, ep_reward,
             fast_diag, slow_diag, prev_pwm_l, prev_pwm_r) -> dict:
    lz = fast_diag.get('lidar_zones', {})
    if hasattr(env, 'phys'):
        px, py, pth = env.phys.x, env.phys.y, env.phys.theta
        colls = env.collisions; stuck = getattr(env, '_stuck_cnt', 0)
    else:
        px, py, pth = env.x, env.y, env.theta
        colls = env.collisions; stuck = 0
    return {
        'step':          step,
        'episode':       episode,
        't_s':           f'{t:.3f}',
        'x':             f'{px:.3f}',
        'y':             f'{py:.3f}',
        'theta_deg':     f'{math.degrees(pth)%360:.1f}',
        'pwm_l':         f'{pwm_l:.2f}',
        'pwm_r':         f'{pwm_r:.2f}',
        'action':        action.name,
        'source':        source,
        'reward':        f'{fast_diag.get("last_reward", 0):.3f}',
        'ep_reward':     f'{ep_reward:.3f}',
        'epsilon':       f'{fast_diag.get("epsilon", 0):.4f}',
        'min_dist':      f'{fast_diag.get("min_dist", 0):.3f}',
        'lidar_front_m': f'{lz.get("FRONT", 0):.2f}',
        'lidar_left_m':  f'{lz.get("LEFT",  0):.2f}',
        'lidar_right_m': f'{lz.get("RIGHT", 0):.2f}',
        'lidar_back_m':  f'{lz.get("BACK",  0):.2f}',
        'lidar_left_min':  f'{fast_diag.get("lidar_left_min", 0):.2f}',
        'lidar_right_min': f'{fast_diag.get("lidar_right_min", 0):.2f}',
        'us_left':       f'{sensors.get("us_left", 0):.3f}',
        'us_right':      f'{sensors.get("us_right", 0):.3f}',
        'tof_left':      f'{sensors.get("tof_left", 0):.3f}',
        'tof_right':     f'{sensors.get("tof_right", 0):.3f}',
        'bumper_front':  sensors.get('bumper_front', 0),
        'bumper_rear':   sensors.get('rear_bumper', 0),
        'collisions':    colls,
        'stuck_cnt':     stuck,
        'slow_action':   slow_diag.get('slow_proposed') or '',
        'slow_conf':     f'{slow_diag.get("slow_conf", 0):.3f}',
        'vml_active':    int(slow_diag.get('vml_active', False)),
        'vml_id':        slow_diag.get('vml_id', ''),
        'ice_concepts':  slow_diag.get('ice_concepts', 0),
        'mem_cells':     slow_diag.get('mem_cells', 0),
        'predictor_mae': f'{fast_diag.get("predictor_mae", 0):.4f}',
        'predictor_conf':f'{fast_diag.get("predictor_conf", 0):.3f}',
        'brain_speed':   f'{fast_diag.get("brain_speed", 0):.3f}',
        'brain_steer':   f'{fast_diag.get("brain_steer", 0):.3f}',
        'lorenz_x':      f'{fast_diag.get("lorenz_x", 0):.4f}',
        'rossler_x':     f'{fast_diag.get("rossler_x", 0):.4f}',
        'dscroll_x':     f'{fast_diag.get("dscroll_x", 0):.4f}',
        'dscroll_mode':  fast_diag.get('dscroll_mode', ''),
        'dscroll_amp':   f'{fast_diag.get("dscroll_amp", 0):.3f}',
        'pwm_dl':        f'{abs(pwm_l - prev_pwm_l):.2f}',
        'pwm_dr':        f'{abs(pwm_r - prev_pwm_r):.2f}',
    }


# =============================================================================
# RDZEŃ PĘTLI
# =============================================================================

def _get_pos(env) -> Tuple[float, float]:
    if hasattr(env, 'phys'): return env.phys.x, env.phys.y
    return env.x, env.y


def _run(env, fast: SwarmFastBrain, slow: SwarmSlowBrain,
         n_steps: int, dt: float, csv_path: str,
         arena_mode: bool = False,
         vml_save_interval:  int = 500,
         slow_save_interval: int = 1000,
         print_interval:     int = 50,
         unlimited: bool = False):

    fh     = open(csv_path, 'w', newline='', encoding='utf-8')
    writer = csv.DictWriter(fh, fieldnames=_CSV_COLS)
    writer.writeheader()

    sensors   = env.reset()
    ep_reward = 0.0
    episode   = getattr(env, 'episode', 0)

    slow_hold: int             = 0
    slow_hold_action: Optional[Action] = None
    _slow_raw          = None
    _slow_conf         = 0.0
    _slow_vml_override = False
    _slow_vml_action   = None
    prev_pwm_l = 0.0; prev_pwm_r = 0.0
    _prev_front_m: float = 3.0
    act_counts: Dict[str, int] = {}
    bumps: dict = {}
    t0 = time.time()

    step = 0
    running = True
    while running and (unlimited or step < n_steps):

        if arena_mode:
            spd   = env.speed_multiplier()
            iters = max(1, int(spd)) if spd >= 1. else 1
            if spd < 1. and (step % max(1, int(round(1./spd)))) != 0:
                if not env.render(prev_pwm_l, prev_pwm_r,
                                  fast.last_action.name if fast.last_action else '',
                                  fast.last_source, {}, {}, bumps):
                    _log("Arena: użytkownik zamknął okno")
                    running = False
                continue
            if env.is_paused():
                if not env.render(prev_pwm_l, prev_pwm_r,
                                  fast.last_action.name if fast.last_action else '',
                                  fast.last_source, {}, {}, bumps):
                    _log("Arena: użytkownik zamknął okno (pauza)")
                    running = False
                continue
        else:
            iters = 1

        for _ in range(iters):
            if not running: break
            if not unlimited and step >= n_steps: break
            t = step * dt

            pos_x, pos_y = _get_pos(env)

            # Hold logic – propozycja Slow z poprzedniego kroku
            if _slow_vml_override and _slow_vml_action is not None:
                final_slow = _slow_vml_action; eff_conf = 1.0
            elif slow_hold > 0 and slow_hold_action is not None:
                _front_for_rev = min(
                    _prev_front_m,
                    sensors.get('us_left',  3.0),
                    sensors.get('us_right', 3.0),
                )
                _rev_open = (slow_hold_action == Action.REVERSE
                             and _front_for_rev > 0.80)
                if _rev_open:
                    slow_hold = 0; slow_hold_action = None
                    final_slow = None; eff_conf = 0.0
                else:
                    final_slow = slow_hold_action; slow_hold -= 1; eff_conf = 1.0
            else:
                if _slow_raw is not None and _slow_conf >= 0.22:
                    if _slow_raw == slow_hold_action: slow_hold = 4
                    else: slow_hold_action = _slow_raw; slow_hold = 4
                    final_slow = _slow_raw; eff_conf = _slow_conf
                else:
                    final_slow = None; eff_conf = 0.0
                    slow_hold = 0; slow_hold_action = None

            # ── FAST BRAIN → PWM ───────────────────────────────────────
            pwm_l, pwm_r, action, source, fast_diag = fast.loop(
                sensors, dt=dt, pos=(pos_x, pos_y),
                slow_action=final_slow, slow_conf=eff_conf,
            )
            fast_diag['dscroll_amp'] = round(fast.double_scroll.current_amplitude, 3)

            _prev_front_m = float(fast_diag.get('lidar_zones', {}).get('FRONT', 3.0))

            if fast_diag.get('hard_safety', False):
                slow_hold = 0; slow_hold_action = None

            if (final_slow is not None and eff_conf >= 0.50 and source == 'NEURAL'):
                source = f"CC({final_slow.name[:3]},{eff_conf:.2f})"

            # ── SLOW BRAIN – aktualizacja PO fast ─────────────────────
            prev_feats = (fast._prev_features
                          if fast._prev_features is not None
                          else np.zeros(fast.cfg.FEATURE_DIM, dtype=np.float32))

            _slow_raw, _slow_conf, _slow_vml_override, _slow_vml_action = slow.step_update(
                features    = prev_feats,
                fast_action = action,
                lorenz_x    = fast.lorenz.x_norm,
                rossler_x   = fast.rossler.x_norm,
                dscroll_x   = fast.double_scroll.x_norm,
                us_front    = min(sensors.get('us_left', 3.), sensors.get('us_right', 3.)),
                tof         = min(sensors.get('tof_left', 2.), sensors.get('tof_right', 2.)),
                reward      = fast.last_reward,
                pos_x       = pos_x,
                pos_y       = pos_y,
            )
            slow_diag = slow.get_diagnostics()

            sensors = env.step(pwm_l, pwm_r, dt)
            ep_reward += fast.last_reward
            episode = getattr(env, 'episode', episode)

            if arena_mode:
                bumps = {'FRONT': sensors.get('bumper_front', 0),
                         'BACK':  sensors.get('rear_bumper',  0)}
                if not env.render(pwm_l, pwm_r, action.name, source,
                                  fast_diag, slow_diag, bumps):
                    _log("Arena: użytkownik zamknął okno")
                    running = False; break

            if step > 0:
                if step % vml_save_interval  == 0: slow.vml.save_to_disk()
                if step % slow_save_interval == 0: slow.save()
                if step % 1000              == 0:
                    slow.vml.degrade_unused(current_step=step, forget_after=20000)

            try:
                writer.writerow(_csv_row(
                    step, episode, t, env, pwm_l, pwm_r,
                    action, source, sensors, ep_reward,
                    fast_diag, slow_diag, prev_pwm_l, prev_pwm_r,
                ))
            except Exception as e:
                _log(f"CSV write error step {step}: {e}")

            prev_pwm_l = pwm_l; prev_pwm_r = pwm_r
            ak = action.name; act_counts[ak] = act_counts.get(ak, 0) + 1

            if step % print_interval == 0:
                lz  = fast_diag.get('lidar_zones', {})
                vst = slow_diag.get('vml_active', False)
                _log(f'[{step:6d}] ({pos_x:.1f},{pos_y:.1f})'
                     f' PWM=({pwm_l:+5.0f},{pwm_r:+5.0f})'
                     f' {ak:<14} {source[:14]:<14}'
                     f' F={lz.get("FRONT",0):.1f}'
                     f' L={lz.get("LEFT",0):.1f}'
                     f' R={lz.get("RIGHT",0):.1f}'
                     f' r={fast.last_reward:+.2f}'
                     f' ice={slow_diag.get("ice_concepts",0)}'
                     f'{" VML!" if vst else ""}')
            step += 1

    fh.flush(); fh.close()
    elapsed = max(time.time() - t0, 0.001)
    total   = sum(act_counts.values()) or 1

    _log(f'Koniec: {step} kroków / {elapsed:.1f}s ({step/elapsed:.0f} k/s)')
    _log(f'CSV: {csv_path}')
    _log(f'ICE: {slow.get_diagnostics().get("ice_concepts",0)}  '
         f'VML: {len(slow.vml.records)} manewrów  '
         f'Kolizje: {getattr(env,"collisions",0)}')

    print('\nRozkład akcji:')
    for k, v in sorted(act_counts.items(), key=lambda x: -x[1]):
        bar = '█' * int(28 * v / total)
        print(f'  {k:<22} {v:5d}  ({100*v/total:5.1f}%)  {bar}')

    # Końcowy zapis – konstruktory zapisały przy starcie, teraz tylko uzupełnienie
    try:
        fast.save()
        slow.save()
        if fast.cfg.USE_LIDAR_PREDICTOR:
            fast.predictor_net.save(fast.cfg.PREDICTOR_FILE)
        slow.vml.save_to_disk()
        _log('Wagi + VML zapisane.')
    except Exception as e:
        _log(f'Błąd zapisu wag: {e}')

    if arena_mode and hasattr(env, 'close'):
        try: env.close()
        except Exception: pass


# =============================================================================
# MAIN
# =============================================================================

def main():
    try:
        _log(f"main.py start  argv={sys.argv}")

        args  = [a for a in sys.argv[1:] if a != '--arena']
        arena = '--arena' in sys.argv
        force_new = '--force-new' in sys.argv

        if force_new:
            # odfiltruj z argumentów, żeby nie pomylić z liczbą kroków
            args = [a for a in args if a != '--force-new']

        _unlimited = False
        if arena and len(args) == 0:
            n_steps  = sys.maxsize
            _unlimited = True
        elif len(args) >= 1:
            n_steps  = int(args[0])
        else:
            n_steps  = 3000
        map_name = args[1]       if len(args) >= 2 else ('maze' if arena else 'corridor')
        dt       = 0.063 if arena else 0.033

        _log(f"Tryb={'ARENA' if arena else 'HEADLESS'}  mapa={map_name}  "
             f"kroki={'∞ (do zamknięcia)' if _unlimited else n_steps}"
             f"{' FORCE_NEW' if force_new else ''}")

        # ── Mózgi ──────────────────────────────────────────────────────
        cfg_fast = SwarmConfig()
        cfg_slow = SlowConfig()

        if force_new:
            cfg_fast.FORCE_NEW_BRAIN     = True
            cfg_fast.FORCE_NEW_PREDICTOR = True
            cfg_slow.FORCE_NEW_BRAIN     = True
            _log("Wymuszony reset wszystkich sieci (--force-new)")

        fast = SwarmFastBrain(cfg_fast)
        slow = SwarmSlowBrain(cfg_slow,
                              lorenz=fast.lorenz,
                              rossler=fast.rossler,
                              dscroll=fast.double_scroll)

        # Przekazanie VMLExecutor do ImpulseBiasController (dla lookup_by_delta w BREACH)
        fast.cc._executor = slow.executor

        _log("Mózgi gotowe (stan wczytany automatycznie)")

        # ── Środowisko ─────────────────────────────────────────────────
        if arena:
            _log("Ładowanie arena_eval...")
            try:
                from arena_eval import ArenaEnv
                _log("arena_eval importowany OK")
            except Exception as e:
                _crash(e)
                _log("FALLBACK: tryb headless (brak arena_eval)")
                arena = False

        if arena:
            try:
                env = ArenaEnv(map_name=map_name, headless=False)
                _log(f"ArenaEnv({map_name}) OK")
            except Exception as e:
                _crash(e)
                _log("FALLBACK: tryb headless (błąd ArenaEnv)")
                arena = False

        if not arena:
            segs, start = _build_map(map_name)
            env = _HeadlessSim(segs, start)
            dt = 0.033
            _log(f"HeadlessSim({map_name}) OK")

        # ── CSV ─────────────────────────────────────────────────────────
        stamp    = datetime.now().strftime('%Y%m%d_%H%M%S')
        csv_path = f'cdc_{stamp}_{map_name}.csv'

        _log(f'Fast: 108→{cfg_fast.HIDDEN_1}→{cfg_fast.HIDDEN_2}→{cfg_fast.HIDDEN_3}→8')
        _log(f'Slow: 112→{cfg_slow.HIDDEN_1}→{cfg_slow.HIDDEN_2}→{cfg_slow.HIDDEN_3}→8')

        # ── Kalibracja atraktorów ───────────────────────────────────────
        if not getattr(cfg_fast, 'SKIP_CALIBRATION', False):
            _log("[CALIB] Start kalibracji atraktorów...")
            try:
                fast.calibrate_attractors(env, cfg_fast)
                _log("[CALIB] Kalibracja zakończona")
            except Exception as e:
                _log(f"[CALIB] Błąd kalibracji (pomijam): {e}")

        _run(env, fast, slow,
             n_steps    = n_steps,
             dt         = dt,
             csv_path   = csv_path,
             arena_mode = arena,
             unlimited  = _unlimited,
             vml_save_interval  = 500,
             slow_save_interval = 1000,
             print_interval     = 50)

    except Exception as e:
        _crash(e)
        sys.exit(1)


if __name__ == '__main__':
    main()