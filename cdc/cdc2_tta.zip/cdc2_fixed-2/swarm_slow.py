#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
swarm_slow.py – Wolny mózg SWARM  (CDC v1.3.7)
=======================================================
Zmiany:
  [v1.3.7 – lifelong learning]
  - Automatyczne wczytywanie stanu przy starcie (bez resetowania)
  - Flaga FORCE_NEW_BRAIN w SlowConfig
  - Zabezpieczenie przed nadpisaniem pliku przy starcie
  - Lepsze logowanie wczytywania/zapisu

  [B6] H2: 64→88  (+≈2000 params w W2 względem oryginalnej H2=64)
       H3: 32→56  (+≈2000 params w W3)
  Reszta architektury bez zmian.
"""

import math
import os
import pickle
import random
from collections import deque
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Any

import numpy as np

from swarm_fast import Action


# =============================================================================
# GAIN MOD ACTIVATION
# =============================================================================

class GainModActivation:
    """Aktywacja z modulacją wzmocnienia przez atraktor Lorenza."""
    def __init__(self, beta: float = 0.2):
        self.beta = beta; self._gain = 1.0; self._cache = None

    def forward(self, z, chaos):
        self._gain = max(0.01, 1.0 + self.beta * float(chaos))  # clamp: gain nigdy ujemny
        a = np.maximum(0.0, z) * self._gain
        self._cache = (z, a); return a

    def backward(self, d):
        z, _ = self._cache
        return d * self._gain * (z > 0).astype(np.float64)


# =============================================================================
# SLOW CONFIG  (autorytatywna definicja – tu są prawdziwe wymiary)
# =============================================================================

@dataclass
class SlowConfig:
    INPUT_DIM:  int   = 112
    HIDDEN_1:   int   = 96     # bez zmian
    HIDDEN_2:   int   = 88     # [B6] ▲ 64→88  (+≈2000 params)
    HIDDEN_3:   int   = 56     # [B6] ▲ 32→56  (+≈2000 params)
    N_ACTIONS:  int   = 8

    LR:           float = 0.00008
    CLIP_GRAD:    float = 0.5
    GAMMA:        float = 0.92
    REPLAY_CAP:   int   = 5000
    REPLAY_BATCH: int   = 32
    TRAIN_FREQ:   int   = 4
    LORENZ_BETA:  float = 0.22

    VAL_STEPS:        int   = 6
    VAL_US_MIN:       float = 0.15
    VAL_TOF_MIN:      float = 0.12
    VAL_SCORE_MIN:    float = 0.20

    CONF_THRESHOLD:   float = 0.22
    COOLDOWN:         int   = 2

    ICE_MIN_SEQ:      int   = 1
    ICE_DECAY:        float = 0.95
    ICE_SUCCESS_BOOST:float = 0.3

    MEM_RESOLUTION:   float = 0.5
    MEM_DECAY:        float = 0.98
    MEM_BONUS_MAX:    float = 0.5

    BRAIN_FILE: str  = "brain_slow.pkl"
    AUTO_SAVE:  int  = 300
    MAX_SEQ_LEN: int = 15

    # [v1.3.7 – lifelong learning] Kontrola wczytywania
    FORCE_NEW_BRAIN: bool = False   # ignoruje brain_slow.pkl i startuje od losowych wag


# =============================================================================
# CONCEPT ENCODER / VALIDATOR
# =============================================================================

_CONCEPT_TABLE = {
    Action.FORWARD:         np.array([1, 0, 0, 0], dtype=np.float32),
    Action.REVERSE:         np.array([1, 1, 0, 0], dtype=np.float32),
    Action.TURN_LEFT:       np.array([0, 1, 0, 0], dtype=np.float32),
    Action.TURN_RIGHT:      np.array([0, 0, 1, 0], dtype=np.float32),
    Action.SPIN_LEFT:       np.array([0, 1, 1, 0], dtype=np.float32),
    Action.SPIN_RIGHT:      np.array([0, 0, 1, 1], dtype=np.float32),
    Action.STOP:            np.array([0, 0, 0, 0], dtype=np.float32),
    Action.ESCAPE_MANEUVER: np.array([1, 1, 1, 0], dtype=np.float32),
}


class ConceptEncoder:
    @staticmethod
    def encode(action: Optional[Action]) -> np.ndarray:
        if action is None: return np.zeros(4, dtype=np.float32)
        return _CONCEPT_TABLE.get(action, np.zeros(4, dtype=np.float32)).copy()

    @staticmethod
    def build_input(features: np.ndarray, action: Optional[Action]) -> np.ndarray:
        return np.concatenate([features, ConceptEncoder.encode(action)]).astype(np.float32)


class ConceptValidator:
    _DELTA = {
        Action.FORWARD:         -0.03,
        Action.REVERSE:         +0.08,
        Action.TURN_LEFT:       -0.02,
        Action.TURN_RIGHT:      -0.02,
        Action.SPIN_LEFT:        0.00,
        Action.SPIN_RIGHT:       0.00,
        Action.STOP:             0.00,
        Action.ESCAPE_MANEUVER: +0.10,
    }

    def __init__(self, cfg: SlowConfig):
        self.cfg = cfg

    def score(self, action: Optional[Action], us_front: float, tof: float) -> float:
        if action is None: return 1.0
        d = self._DELTA.get(action, 0.0)
        su, st = float(us_front), float(tof)
        for _ in range(self.cfg.VAL_STEPS):
            su = max(0.0, su + d); st = max(0.0, st + d * 0.8)
        us_ok = su >= self.cfg.VAL_US_MIN; tof_ok = st >= self.cfg.VAL_TOF_MIN
        if not us_ok and not tof_ok: return 0.0
        if not us_ok or not tof_ok: return 0.35
        m = ((su - self.cfg.VAL_US_MIN) + (st - self.cfg.VAL_TOF_MIN)) / 4.0
        return float(np.clip(0.5 + 0.5 * m, 0.0, 1.0))

    def score_sequence(self, actions: List[Action], us_front: float, tof: float) -> float:
        if not actions: return 1.0
        su, st = float(us_front), float(tof)
        steps_per = max(1, self.cfg.VAL_STEPS // len(actions))
        for action in actions:
            d = self._DELTA.get(action, 0.0)
            for _ in range(steps_per):
                su = max(0.0, su + d); st = max(0.0, st + d * 0.8)
        us_ok = su >= self.cfg.VAL_US_MIN; tof_ok = st >= self.cfg.VAL_TOF_MIN
        if not us_ok and not tof_ok: return 0.0
        if not us_ok or not tof_ok: return 0.35
        m = ((su - self.cfg.VAL_US_MIN) + (st - self.cfg.VAL_TOF_MIN)) / 4.0
        return float(np.clip(0.5 + 0.5 * m, 0.0, 1.0))

    def simulate_min_distance(self, actions, us_front, tof):
        if not actions: return min(us_front, tof)
        su, st = float(us_front), float(tof)
        steps_per = max(1, self.cfg.VAL_STEPS // len(actions))
        min_dist = min(su, st)
        for action in actions:
            d = self._DELTA.get(action, 0.0)
            for _ in range(steps_per):
                su = max(0.0, su + d); st = max(0.0, st + d * 0.8)
                min_dist = min(min_dist, su, st)
        return min_dist

    def is_safe(self, actions, us_front, tof, floor=0.04):
        return self.simulate_min_distance(actions, us_front, tof) >= floor


# =============================================================================
# SLOW BRANCH NETWORK  (112 → 96 → 88 → 56 → 8)
# =============================================================================

class SlowBranchNetwork:
    def __init__(self, cfg: SlowConfig):
        self.cfg = cfg
        self.lr = cfg.LR
        I, H1, H2, H3, A = cfg.INPUT_DIM, cfg.HIDDEN_1, cfg.HIDDEN_2, cfg.HIDDEN_3, cfg.N_ACTIONS

        def W(r, c): return np.random.randn(r, c).astype(np.float64) * np.sqrt(2.0 / r)
        def b(n):    return np.zeros(n, dtype=np.float64)

        self.W1, self.b1 = W(I,  H1), b(H1)
        self.W2, self.b2 = W(H1, H2), b(H2)
        self.W3, self.b3 = W(H2, H3), b(H3)
        self.Wq, self.bq = W(H3, A) * 0.5, b(A)

        beta = 0.2
        self.act1 = GainModActivation(beta * 1.1)
        self.act2 = GainModActivation(beta * 0.85)
        self.act3 = GainModActivation(beta * 0.6)
        self.cache: Dict = {}

    def forward(self, x: np.ndarray, lorenz_x: float) -> np.ndarray:
        a1 = self.act1.forward(np.dot(x.astype(np.float64), self.W1) + self.b1, lorenz_x)
        a2 = self.act2.forward(np.dot(a1, self.W2) + self.b2, lorenz_x)
        a3 = self.act3.forward(np.dot(a2, self.W3) + self.b3, lorenz_x)
        q  = np.clip(np.dot(a3, self.Wq) + self.bq, -5.0, 5.0)
        self.cache = dict(x=x.astype(np.float64), a1=a1, a2=a2, a3=a3, q=q)
        return q

    def backward(self, target_q: np.ndarray):
        if 'x' not in self.cache: return
        c = self.cache; clip = self.cfg.CLIP_GRAD * 0.1
        dq = c['q'] - target_q
        d3 = self.act3.backward(np.dot(dq, self.Wq.T))
        d2 = self.act2.backward(np.dot(d3, self.W3.T))
        d1 = self.act1.backward(np.dot(d2, self.W2.T))
        for w, dw, bv, db in [
            (self.Wq, np.outer(c['a3'], dq), self.bq, dq),
            (self.W3, np.outer(c['a2'], d3), self.b3, d3),
            (self.W2, np.outer(c['a1'], d2), self.b2, d2),
            (self.W1, np.outer(c['x'],  d1), self.b1, d1),
        ]:
            w  -= self.lr * np.clip(dw, -clip, clip)
            bv -= self.lr * np.clip(db, -clip, clip)
        for w in (self.W1, self.W2, self.W3, self.Wq):
            np.clip(w, -10.0, 10.0, out=w)

    def get_weights(self) -> Dict[str, np.ndarray]:
        return {k: getattr(self, k).copy() for k in ('W1','b1','W2','b2','W3','b3','Wq','bq')}

    def set_weights(self, d: Dict[str, np.ndarray]):
        for k, v in d.items():
            if hasattr(self, k) and getattr(self, k).shape == v.shape:
                getattr(self, k)[:] = v


# =============================================================================
# CONCEPT GRAPH (ICE)
# =============================================================================

class ConceptGraph:
    @dataclass
    class Concept:
        actions:   List[Action]
        strength:  float = 1.0
        uses:      int   = 0
        successes: int   = 0

    def __init__(self, cfg: SlowConfig):
        self.cfg = cfg
        self.concepts: List['ConceptGraph.Concept'] = []

    def record(self, actions: List[Action], reward: float):
        if len(actions) < self.cfg.ICE_MIN_SEQ: return
        for c in self.concepts:
            if c.actions == actions:
                c.strength = min(1.0, c.strength + self.cfg.ICE_SUCCESS_BOOST * max(0, reward))
                c.successes += 1; return
        self.concepts.append(self.Concept(actions=actions[:], strength=max(0.1, reward)))

    def reject(self, actions: List[Action], penalty: float = 0.5):
        for c in self.concepts:
            if c.actions == actions:
                c.strength *= penalty
                if c.strength < 0.05: self.concepts.remove(c)
                return

    def decay(self):
        for c in self.concepts: c.strength *= self.cfg.ICE_DECAY
        self.concepts = [c for c in self.concepts if c.strength > 0.05]

    def best(self) -> Optional[List[Action]]:
        if not self.concepts: return None
        top = max(self.concepts, key=lambda c: c.strength)
        top.uses += 1; return top.actions[:]

    def __len__(self): return len(self.concepts)


# =============================================================================
# SPATIAL MEMORY
# =============================================================================

class SpatialMemory:
    def __init__(self, cfg: SlowConfig):
        self.cfg = cfg
        self.grid: Dict[Tuple[int, int], Dict] = {}

    def _key(self, x: float, y: float) -> Tuple[int, int]:
        r = self.cfg.MEM_RESOLUTION
        return (int(x / r), int(y / r))

    def update(self, x: float, y: float, reward: float, escape: Optional[List[Action]] = None):
        k = self._key(x, y)
        if k not in self.grid:
            self.grid[k] = {'reward': 0.0, 'visits': 0, 'escape': None}
        g = self.grid[k]
        g['reward'] = g['reward'] * 0.9 + reward * 0.1
        g['visits'] += 1
        if escape: g['escape'] = escape[:]

    def decay(self):
        for g in self.grid.values(): g['reward'] *= self.cfg.MEM_DECAY

    def escape_seq(self, x: float, y: float) -> Optional[List[Action]]:
        k = self._key(x, y)
        return self.grid.get(k, {}).get('escape')


# =============================================================================
# SLOW REPLAY
# =============================================================================

class SlowReplay:
    def __init__(self, capacity: int):
        self.buf: deque = deque(maxlen=capacity)

    def push(self, x, a, r, x2): self.buf.append((x.copy(), a, r, x2.copy()))
    def sample(self, n): return random.sample(self.buf, min(n, len(self.buf)))
    def __len__(self): return len(self.buf)


# =============================================================================
# SLOW BRAIN
# =============================================================================

class SwarmSlowBrain:
    def __init__(self, cfg: Optional[SlowConfig] = None,
                 lorenz=None, rossler=None, dscroll=None):
        self.cfg    = cfg or SlowConfig()
        self.lorenz  = lorenz
        self.rossler = rossler
        self.dscroll = dscroll
        self.net     = SlowBranchNetwork(self.cfg)
        self.val     = ConceptValidator(self.cfg)
        self.ice     = ConceptGraph(self.cfg)
        self.mem     = SpatialMemory(self.cfg)
        self.replay  = SlowReplay(self.cfg.REPLAY_CAP)

        self.step       = 0
        self.epsilon    = 0.15
        self.cooldown   = 0
        self.confidence = 0.0
        self.proposed   = None

        # VML pipeline
        from swarm_maneuvers import VerifiedManeuverLibrary, VMLExecutor
        self.vml      = VerifiedManeuverLibrary()
        self.executor = VMLExecutor(self.vml)

        # PrimitiveLibrary – szybkie wyszukiwanie manewrów przez cKDTree
        from swarm_primitives import PrimitiveLibrary
        self.plib = PrimitiveLibrary()
        if not self.plib.load():
            print("[SLOW] primitives.bin nie załadowany – działam bez prymitywów")
        else:
            self.executor.attach_plib(self.plib)

        self._loop_buffer: list = []
        self._last_vml_id       = None
        self._last_x            = None
        self._last_a_idx        = 0
        self._stuck_actions:  List[Action] = []
        self._stuck_ctr       = 0
        self._last_pos        = None
        self._last_fast_action = None
        self.last_proposed_seq: Optional[List[Action]] = None
        self._last_min_dist    = 1.0

        # [v1.3.7 – lifelong learning] Automatyczne wczytywanie
        if not getattr(self.cfg, 'FORCE_NEW_BRAIN', False):
            loaded = self.load()
            if loaded:
                print(f"[SLOW] Wczytano {self.cfg.BRAIN_FILE} (krok {self.step})")
            else:
                print("[SLOW] Brain startuje od losowych wag")
        else:
            print("[SLOW] FORCE_NEW_BRAIN=True – start od losowych wag")

    # ------------------------------------------------------------------
    def step_update(self, features, fast_action, lorenz_x,
                    rossler_x=0.0, dscroll_x=0.0,
                    us_front=3.0, tof=3.0, reward=0.0,
                    pos_x=0.0, pos_y=0.0):
        self.step += 1
        if self.cooldown > 0: self.cooldown -= 1

        x = ConceptEncoder.build_input(features, fast_action)
        q = self.net.forward(x, lorenz_x)

        if random.random() < self.epsilon:
            a_idx = random.randint(0, self.cfg.N_ACTIONS - 1)
        else:
            a_idx = int(np.argmax(q))

        candidate  = list(Action)[a_idx]
        val_score  = self.val.score(candidate, us_front, tof)
        validated  = val_score >= self.cfg.VAL_SCORE_MIN

        sm   = self._softmax(q)
        conf = 0.7 * float(sm[a_idx]) + 0.3 * val_score
        self.confidence = conf

        self._track_stuck(fast_action, reward, pos_x, pos_y, min_dist=us_front)
        self.last_proposed_seq = [candidate] if candidate is not None else None

        if validated and conf >= self.cfg.CONF_THRESHOLD and self.cooldown == 0:
            self.proposed = candidate
            self.cooldown = self.cfg.COOLDOWN
        else:
            self.proposed = None

        if self._last_x is not None:
            self.replay.push(self._last_x, self._last_a_idx, reward, x)
            self._train(lorenz_x)

        self._last_x    = x.copy()
        self._last_a_idx = a_idx

        self.epsilon = max(0.03, self.epsilon * 0.99999)
        self.mem.decay(); self.ice.decay()

        # [v1.3.7] Zapis tylko jeśli krok > 0 (nie przy starcie)
        if self.step > 0 and self.step % self.cfg.AUTO_SAVE == 0:
            self.save()

        # Detekcja pętli → VML
        self._loop_buffer.append((pos_x, pos_y))
        if len(self._loop_buffer) > 90: self._loop_buffer.pop(0)
        if len(self._loop_buffer) == 90:
            xs  = [p[0] for p in self._loop_buffer]
            ys  = [p[1] for p in self._loop_buffer]
            span = math.hypot(max(xs) - min(xs), max(ys) - min(ys))
            if span < 5.0 and not self.executor.is_active:
                started = self.executor.try_start(pos_x, pos_y)
                if started and self.dscroll is not None:
                    self.dscroll.request_boost()

        vml_action, vml_override = None, False
        if self.executor.is_active:
            vml_action, vml_override = self.executor.step(
                hard_safety=False, reward=reward
            )
            if vml_override and vml_action:
                self.proposed   = vml_action
                self.confidence = 1.0
                self._last_vml_id = self.executor.active_id

        return self.proposed, conf, vml_override, vml_action

    # ------------------------------------------------------------------
    def _track_stuck(self, action: Optional[Action], reward: float,
                     x: float, y: float, min_dist: float = 1.0):
        self._last_min_dist = min_dist
        if action is None: return

        self._stuck_actions.append(action)
        if self._last_pos is None:
            self._last_pos = (x, y)

        flush = False
        if action != self._last_fast_action:
            self._stuck_ctr = 0
            flush = len(self._stuck_actions) >= 6
        else:
            self._stuck_ctr += 1

        if len(self._stuck_actions) >= self.cfg.MAX_SEQ_LEN:
            flush = True

        if flush:
            seq    = self._stuck_actions[:]
            unique = set(seq)
            if len(unique) >= 2:
                print(f"[OBSERVER RECORD] len={len(seq)} unique={len(unique)} last={action.name}")
                self.ice.record(seq, reward)
                if self._last_pos:
                    self.mem.update(self._last_pos[0], self._last_pos[1], reward, seq)
                if self.vml is not None:
                    _us    = float(self._last_min_dist)
                    _score = self.val.score_sequence(seq, _us, _us)
                    if _score >= 0.25:   # zgodne z progiem promote() w VML
                        _px, _py = self._last_pos
                        self.vml.promote(seq, _score, _px, _py, reward)
                        print(f"[ICE→VML] promote score={_score:.2f} len={len(seq)}")
            else:
                print(f"[OBSERVER SKIP] monotonna ({len(seq)}×{list(unique)[0].name if unique else '?'})")
            self._stuck_actions = [action]
            self._last_pos      = (x, y)

        self._last_fast_action = action
        self.mem.update(x, y, reward)

    # ------------------------------------------------------------------
    def get_ice_escape(self, x: float, y: float) -> Optional[List[Action]]:
        seq = self.mem.escape_seq(x, y)
        if seq: print(f"[ICE ESCAPE] SpatialMemory len={len(seq)}"); return seq
        best = self.ice.best()
        if best: print(f"[ICE BEST] ConceptGraph len={len(best)}")
        return best

    def reject_unsafe(self, actions: List[Action]):
        print(f"[SLOW UNSAFE] karanie konceptu {[a.name for a in actions]}")
        self.ice.reject(actions, penalty=0.5)
        self.cooldown = max(self.cooldown, 3)

    # ------------------------------------------------------------------
    def _train(self, lorenz_x: float):
        if self.step % self.cfg.TRAIN_FREQ != 0 or len(self.replay) < self.cfg.REPLAY_BATCH: return
        batch = self.replay.sample(self.cfg.REPLAY_BATCH)
        for x, a, r, x2 in batch:
            q2  = self.net.forward(x2, lorenz_x)
            tgt = self.net.forward(x,  lorenz_x).copy()
            tgt[a] = r + self.cfg.GAMMA * float(np.max(q2))
            self.net.backward(tgt)

    # ------------------------------------------------------------------
    def get_diagnostics(self) -> Dict[str, Any]:
        return {
            'slow_step':     self.step,
            'slow_proposed': self.proposed.name if self.proposed else None,
            'slow_conf':     round(self.confidence, 3),
            'slow_cooldown': self.cooldown,
            'ice_concepts':  len(self.ice),
            'mem_cells':     len(self.mem.grid),
            'vml_active':    self.executor.is_active,
            'vml_id':        self.executor.active_id or '',
        }

    # ------------------------------------------------------------------
    def save(self):
        data = {'weights': self.net.get_weights(), 'step': self.step, 'epsilon': self.epsilon}
        try:
            tmp = self.cfg.BRAIN_FILE + '.tmp'
            with open(tmp, 'wb') as f: pickle.dump(data, f)
            os.replace(tmp, self.cfg.BRAIN_FILE)
            print(f"[SLOW] Zapisano {self.cfg.BRAIN_FILE} (krok {self.step})")
        except Exception as e:
            print(f"[SLOW] Błąd zapisu: {e}")

    def load(self) -> bool:
        if not os.path.exists(self.cfg.BRAIN_FILE): return False
        try:
            with open(self.cfg.BRAIN_FILE, 'rb') as f:
                data = pickle.load(f)
            self.net.set_weights(data.get('weights', {}))
            self.step    = data.get('step', 0)
            self.epsilon = data.get('epsilon', 0.15)
            return True
        except Exception:
            return False

    @staticmethod
    def _softmax(x: np.ndarray) -> np.ndarray:
        e = np.exp(np.clip(x - np.max(x), -10, 10))
        return e / (e.sum() + 1e-8)


# =============================================================================
# SATURATION LATCH (Hold-and-Burst)
# =============================================================================

class SaturationLatch:
    def __init__(self, latch_steps: int = 4):
        self.latch_steps = latch_steps
        self._countdown  = 0
        self._high_state = False

    def update(self, ds_x: float, breach_detected: bool) -> float:
        if self._high_state:
            self._countdown -= 1
            if self._countdown <= 0:
                self._high_state = False; return -0.5
            return 1.0
        if breach_detected and ds_x > 0.3:
            self._high_state = True; self._countdown = self.latch_steps; return 1.0
        return 0.0

    @property
    def is_latched(self) -> bool: return self._high_state


# =============================================================================
# IMPULSE BIAS CONTROLLER – Meta-Arbiter
# =============================================================================

class ImpulseBiasController:
    MODE_BREACH = 'BREACH'
    MODE_CRUISE = 'CRUISE'
    MODE_CHAOS  = 'CHAOS'

    def __init__(self, latch_steps: int = 4,
                 breach_margin_m: float = 0.15,
                 breach_depth_m:  float = 0.8,
                 cruise_front_m:  float = 1.5):
        self.breach_margin_m = breach_margin_m
        self.breach_depth_m  = breach_depth_m
        self.cruise_front_m  = cruise_front_m
        self.latch           = SaturationLatch(latch_steps)
        self._mode           = self.MODE_CRUISE
        self._executor       = None  # ustawiany z zewnątrz po inicjalizacji SlowBrain

    @property
    def mode(self) -> str: return self._mode

    def _detect_breach(self, front_dist_m, side_left_m, side_right_m) -> bool:
        narrow = (side_left_m < self.breach_margin_m or side_right_m < self.breach_margin_m)
        return narrow and front_dist_m > self.breach_depth_m

    def integrate(self,
                  pwm_fast:     Tuple[float, float],
                  pwm_slow:     Optional[Tuple[float, float]],
                  slow_conf:    float,
                  lorenz_x:     float,
                  rossler_x:    float,
                  dscroll_x:    float,
                  front_dist_m: float,
                  side_left_m:  float,
                  side_right_m: float,
                  stagnant:     bool = False,
                  bumper:       bool = False) -> Tuple[float, float]:
        fl, fr = pwm_fast
        breach = self._detect_breach(front_dist_m, side_left_m, side_right_m)

        if bumper or stagnant:  self._mode = self.MODE_CHAOS
        elif breach:            self._mode = self.MODE_BREACH
        elif front_dist_m > self.cruise_front_m: self._mode = self.MODE_CRUISE
        else:                   self._mode = self.MODE_CHAOS

        if self._mode == self.MODE_BREACH:
            bias  = self.latch.update(dscroll_x, breach_detected=True)
            # Oblicz wektor wolnej przestrzeni (przód + lateralny bias)
            free_dx = float(np.clip(front_dist_m, 0.0, 3.0))
            free_dy = float(np.clip((side_right_m - side_left_m) * 0.5, -1.0, 1.0))
            # Próba prymitywu z PrimitiveLibrary przez VMLExecutor
            if (self._executor is not None
                    and not self._executor.is_active
                    and self._executor.lookup_by_delta(free_dx, free_dy, 0.0)):
                vml_action, vml_override = self._executor.step(
                    hard_safety=False, reward=0.0
                )
                if vml_override and vml_action is not None:
                    from swarm_fast import PWM_TABLE
                    pwm_l, pwm_r = PWM_TABLE.get(vml_action, (fl, fr))
                    return (float(np.clip(pwm_l, -100, 100)),
                            float(np.clip(pwm_r, -100, 100)))
            # Fallback – klasyczny boost breach
            boost = 1.0 + bias * 0.4
            return (float(np.clip(fl * boost, -100, 100)),
                    float(np.clip(fr * boost, -100, 100)))

        self.latch.update(dscroll_x, breach_detected=False)

        if pwm_slow is None or slow_conf < 0.15:
            return pwm_fast

        if self._mode == self.MODE_CRUISE:
            gate   = float(np.clip(0.70 + 0.30 * rossler_x, 0.50, 1.0))
            weight = float(np.clip(slow_conf * gate, 0.0, 0.90))
        else:
            gate   = float(np.clip(0.55 + 0.45 * abs(lorenz_x), 0.45, 1.0))
            weight = float(np.clip(slow_conf * gate, 0.0, 0.95))

        sl, sr = pwm_slow
        pl = (1.0 - weight) * fl + weight * sl
        pr = (1.0 - weight) * fr + weight * sr
        return float(np.clip(pl, -100, 100)), float(np.clip(pr, -100, 100))


# =============================================================================
# CORPUS CALLOSUM (legacy static wrapper)
# =============================================================================

class CorpusCallosum:
    @staticmethod
    def integrate(pwm_fast, pwm_slow, slow_conf, lorenz_x=0.0, **kwargs):
        if pwm_slow is None or slow_conf < 0.22:
            return pwm_fast[0], pwm_fast[1]
        gate   = float(np.clip(0.5 + 0.5 * lorenz_x, 0.5, 1.0))
        weight = float(np.clip(slow_conf * gate, 0.0, 0.70))
        fl, fr = pwm_fast; sl, sr = pwm_slow
        pl = (1.0 - weight) * fl + weight * sl
        pr = (1.0 - weight) * fr + weight * sr
        return float(np.clip(pl, -100, 100)), float(np.clip(pr, -100, 100))