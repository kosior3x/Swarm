# config.py  –  CDC v1.3.7
from dataclasses import dataclass


@dataclass
class SwarmConfig:
    # ── Fizyka ────────────────────────────────────────────────────────────────
    ROBOT_RADIUS:       float = 0.18
    WHEEL_BASE:         float = 0.28
    MAX_SPEED_MPS:      float = 0.75
    PWM_MAX:            float = 100.0
    PWM_SMOOTHING:      float = 0.25

    # ── Sensory ───────────────────────────────────────────────────────────────
    LIDAR_MAX_RANGE:       float = 3.0
    LIDAR_HARD_SAFETY_MIN: float = 0.35

    # ── Bezpieczeństwo ────────────────────────────────────────────────────────
    BUMPER_REVERSE_CYCLES:      int   = 15
    BUMPER_COOLDOWN:            int   = 30
    BUMPER_SPIN_OVERHEAD:       int   = 3
    BUMPER_DEG_PER_CYCLE:       float = 3.0
    REAR_BUMPER_FORWARD_CYCLES: int   = 5
    HARD_REFLEX_HOLD_CYCLES:    int   = 7
    SIDE_SAFETY_CD:             int   = 6
    SIDE_SAFETY_HYST:           float = 0.65

    # ── Sieć neuronowa Fast (108→80→88→64→8) ─────────────────────────────────
    FEATURE_DIM:    int   = 108
    HIDDEN_1:       int   = 80
    HIDDEN_2:       int   = 88
    HIDDEN_3:       int   = 64
    N_ACTIONS:      int   = 8
    NN_LR:          float = 0.000001
    NN_CLIP_GRAD:   float = 1.0
    LORENZ_BETA:    float = 0.8
    ROSSLER_BETA:   float = 0.8

    # ── Głowice kierunkowe (dynamiczne PWM) ───────────────────────────────────
    STEER_LR:            float = 0.0005
    STEER_SMOOTH_WEIGHT: float = 0.04

    # ── Q-learning ────────────────────────────────────────────────────────────
    LR:               float = 0.03
    LR_DECAY:         float = 0.99995
    LR_MIN:           float = 0.0015
    GAMMA:            float = 0.9
    EPSILON:          float = 0.10
    EPSILON_DECAY:    float = 0.9999
    EPSILON_MIN:      float = 0.02
    REPLAY_CAPACITY:  int   = 15000
    REPLAY_BATCH:     int   = 64
    REPLAY_FREQ:      int   = 4
    BLOCK_REVERSE:    bool  = False

    # ── Avoidance head ────────────────────────────────────────────────────────
    AVOIDANCE_PENALTY:      float = 1.0
    AVOIDANCE_CAPACITY:     int   = 10000
    AVOIDANCE_DECAY:        float = 0.9998
    AVOIDANCE_MIN_SEVERITY: float = 0.05
    AVOIDANCE_LR_BAD:       float = 0.005
    AVOIDANCE_LR_GOOD:      float = 0.001
    AVOIDANCE_CONTRAST:     float = 0.25
    AVOIDANCE_TRAIN_FREQ:   int   = 8
    AVOIDANCE_DECAY_FREQ:   int   = 50

    # ── Instynkt ──────────────────────────────────────────────────────────────
    INSTINCT_WEIGHT:          float = 3.0
    INSTINCT_REVERSE_PENALTY: float = 0.8
    INSTINCT_FORWARD_BONUS:   float = 8.0

    # ── Stagnacja ─────────────────────────────────────────────────────────────
    STAGNATION_WINDOW:       int   = 55   # relax: robot w luku false-stall przy 40
    STAGNATION_THRESHOLD:    float = 0.25
    STAGNATION_FORCE_CYCLES: int   = 7
    STAGNATION_COOLDOWN:     int   = 100
    STAGNATION_OPEN_MIN:     float = 0.9

    # ── Oscylacja ─────────────────────────────────────────────────────────────
    OSC_WINDOW:  int   = 10
    OSC_PENALTY: float = 6.0

    # ── Progi bezpieczeństwa ──────────────────────────────────────────────────
    SAFETY_BASE_MAX:   float = 0.35
    SAFETY_BASE_MIN:   float = 0.26
    SAFETY_FLOOR:      float = 0.24
    SAFETY_SIDE_RATIO: float = 0.30

    # ── Nawigacja przestrzenna ────────────────────────────────────────────────
    SPATIAL_SPIN_MAX:        float = 0.80
    SPATIAL_SPIN_MIN:        float = 0.10
    SPATIAL_TURN_INNER_MAX:  float = 1.20
    SPATIAL_TURN_INNER_MIN:  float = 0.14
    SPATIAL_TURN_OUTER_MAX:  float = 1.40
    SPATIAL_TURN_OUTER_MIN:  float = 0.20

    # ── Predyktor LIDAR – Lorenz Cartographer (wielokrokowy MLP) ────────────
    USE_LIDAR_PREDICTOR:    bool  = True
    PREDICTOR_FILE:         str   = "predictor_fast.pkl"
    PREDICTOR_K:            int   = 10      # okno historii (10 × 5 = 50 wejść)
    PREDICTOR_LR:           float = 0.002  # learning rate predyktora

    # [v1.3.7] Architektura trójwarstwowa: 50 → 52 → 32 → 16 → H
    PREDICTOR_H1:           int   = 52      # warstwa ukryta 1
    PREDICTOR_H2:           int   = 32      # warstwa ukryta 2
    PREDICTOR_H3:           int   = 16      # warstwa ukryta 3

    # Horyzont predykcji – ile kroków do przodu (T+1 .. T+H)
    PREDICTOR_HORIZON:      int   = 4

    # Średni błąd bezwzględny, przy którym uznajemy predyktor za „niedojrzały”
    PREDICTOR_MAE_FALLBACK: float = 0.50

    # PREDICTOR_HIDDEN – przestarzałe, zachowane dla kompatybilności
    PREDICTOR_HIDDEN:       int   = 52

    # ── Kompatybilność / atraktory ────────────────────────────────────────────
    DSCROLL_SAFETY_BETA:   float = 0.30
    EMERGENCY_MIN:         float = 0.07
    SAFETY_DYNAMIC_RANGE:  float = 0.15
    SAFETY_SLOW_DOWN_DIST: float = 0.40
    SAFETY_SIDE_MULT:      float = 0.8

    BRAIN_FILE:         str   = "brain_fast.pkl"
    AUTO_SAVE_INTERVAL: int   = 100
    PWM_SLEW_RATE:      float = 20.0

    PREDICT_HORIZON: float = 0.8
    PREDICT_STEPS:   int   = 15

    # ── v1.3: AntiStagnation guards ──────────────────────────────────────────
    STAGNATION_PROGRESS_MIN: float = 0.18  # relax: bylo 0.25 zbyt rygorystyczne
    STAGNATION_OPEN_GUARD:   int   = 3
    STAGNATION_FRONT_MIN:    float = 0.80
    STAGNATION_CUM_MIN:      float = 0.40
    STAGNATION_VAR_MIN:      float = 0.08

    # ── v1.3: Reward smoothness ───────────────────────────────────────────────
    SMOOTH_JUMP_THRESHOLD: float = 30.0
    SMOOTH_PENALTY_SCALE:  float = 0.015

    # ── v1.3.1: SPATIAL_TURN neural takeover ─────────────────────────────────
    SPATIAL_NEURAL_STEER_THR: float = 0.30
    SPATIAL_NEURAL_CONF_STEP: int   = 4

    # ── v1.3.3: HARD_SAFETY ping-pong guard ──────────────────────────────────
    HARD_SAFETY_PINGPONG_THRESH: int   = 20
    HARD_SAFETY_ESCAPE_STEPS:    int   = 40

    # ── v1.3: Eksperymentalne flagi ───────────────────────────────────────────
    USE_HYSTERESIS: bool  = True
    USE_HORMONES:   bool  = True
    USE_PROTOTYPES: bool  = True

    # [v1.3.7 – lifelong learning] Kontrola wczytywania
    FORCE_NEW_BRAIN:     bool = False   # ignoruje brain_fast.pkl i startuje od losowych wag
    FORCE_NEW_PREDICTOR: bool = False   # ignoruje predictor_fast.pkl


# Alias
FastConfig = SwarmConfig


@dataclass
class SlowConfig:
    """Slow Brain config – v1.3.7"""
    INPUT_DIM:  int   = 112
    HIDDEN_1:   int   = 96
    HIDDEN_2:   int   = 88
    HIDDEN_3:   int   = 56
    N_ACTIONS:  int   = 8

    LR:           float = 0.00018
    CLIP_GRAD:    float = 1.0
    GAMMA:        float = 0.92
    REPLAY_CAP:   int   = 5000
    REPLAY_BATCH: int   = 32
    TRAIN_FREQ:   int   = 4

    VAL_STEPS:     int   = 6
    VAL_US_MIN:    float = 0.15
    VAL_TOF_MIN:   float = 0.12
    VAL_SCORE_MIN: float = 0.20

    CONF_THRESHOLD: float = 0.22
    COOLDOWN:       int   = 2

    ICE_MIN_SEQ:       int   = 1
    ICE_DECAY:         float = 0.95
    ICE_SUCCESS_BOOST: float = 0.3

    MEM_RESOLUTION: float = 0.5
    MEM_DECAY:      float = 0.98
    MEM_BONUS_MAX:  float = 0.5

    MAX_SEQ_LEN: int = 15
    BRAIN_FILE:  str = "brain_slow.pkl"
    AUTO_SAVE:   int = 200

    # [v1.3.7 – lifelong learning] Kontrola wczytywania
    FORCE_NEW_BRAIN: bool = False   # ignoruje brain_slow.pkl i startuje od losowych wag