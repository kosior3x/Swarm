#!/usr/bin/env python3
# -*- coding: utf-8 -*-
def jls_extract_def():
    return """
    swarm_maneuvers.py – Verified Maneuver Library (VML)
    =====================================================
    CDC v1.2 – Trwała biblioteka proceduralna manewrów ucieczki.
    
    Analogia biologiczna: móżdżek – pamięć proceduralna, która NIE zapomina.
    ICE (hipokamp) zapomina po ~90 krokach. VML przeżywa reset wag sieci.
    
    Statusy manewrów:
      CANDIDATE  → wygenerowany przez ICE, niezweryfikowany
      VERIFIED   → potwierdzony przez ConceptValidator.score_sequence() >= 0.7
      ARCHIVED   → wycofany z aktywnego użycia, zachowany historycznie
    
    Plik dyskowy: maneuvers.json (niezależny od brain_fast.pkl / brain_slow.pkl)
    
    Przepływ:
      ICE wykrywa utknięcie
      → ConceptGraph.best() → sekwencja kandydacka
      → ConceptValidator.score_sequence() >= 0.7?
          TAK → VML.promote(VERIFIED, sekwencja, x, y, reward)
          NIE → pozostaje tylko w ICE
      → Robot w pobliżu tej pozycji za N kroków?
          → VML.lookup(x, y) → ManeuverRecord
          → VMLExecutor.try_start() → 100% PWM override przez czas manewru
    
    Zasady bezpieczeństwa (CDC v1.2 / sekcja 4):
      - VML NIGDY nie nadpisuje SafetyLayer
      - 1. przerwanie Safety: pauza, wznowienie po RESUME_CLEAR_CYCLES czystych krokach
      - 2. przerwanie Safety w TYM SAMYM manewrze: abort + fail_count++
      - fail_count >= AUTO_ARCHIVE_FAILS i success_rate < AUTO_ARCHIVE_RATE → ARCHIVED
    """


jls_extract_def()

import json
import math
import os
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from swarm_fast import Action
from swarm_primitives import PrimitiveLibrary, ACTION_CODES


# =============================================================================
# STATUS MANEWRU
# =============================================================================

class ManeuverStatus(str, Enum):
    CANDIDATE = "CANDIDATE"
    VERIFIED  = "VERIFIED"
    ARCHIVED  = "ARCHIVED"


# =============================================================================
# REKORD MANEWRU
# =============================================================================

@dataclass
class ManeuverRecord:
    """
    Pełny opis jednego zapamiętanego manewru.

    actions      – lista nazw Action (str) – JSON-serializowalne
    positions    – lista (x,y) gdzie manewr był użyty lub zweryfikowany
    avg_reward   – krocząca średnia nagrody (EMA 0.8/0.2)
    """
    maneuver_id:   str
    actions:       List[str]                       # Action.name stringi
    status:        str                             # ManeuverStatus.value
    val_score:     float
    created_at:    float                           # unix timestamp
    last_used:     float                           # unix timestamp
    use_count:     int                   = 0
    success_count: int                   = 0
    fail_count:    int                   = 0
    avg_reward:    float                 = 0.0
    positions:     List[Tuple[float, float]] = field(default_factory=list)

    # ------------------------------------------------------------------
    @property
    def actions_enum(self) -> List[Action]:
        """Konwertuje listę nazw do listy Action."""
        return [Action[a] for a in self.actions]

    @property
    def success_rate(self) -> float:
        total = self.success_count + self.fail_count
        return (self.success_count / total) if total > 0 else 1.0

    @property
    def quality_score(self) -> float:
        """Łączna jakość: val_score × success_rate (do rankingu w lookup)."""
        return self.val_score * self.success_rate

    # ------------------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['positions'] = [list(p) for p in self.positions]
        return d

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> 'ManeuverRecord':
        positions = [tuple(p) for p in d.get('positions', [])]
        return ManeuverRecord(
            maneuver_id   = str(d['maneuver_id']),
            actions       = list(d['actions']),
            status        = str(d['status']),
            val_score     = float(d['val_score']),
            created_at    = float(d['created_at']),
            last_used     = float(d['last_used']),
            use_count     = int(d.get('use_count', 0)),
            success_count = int(d.get('success_count', 0)),
            fail_count    = int(d.get('fail_count', 0)),
            avg_reward    = float(d.get('avg_reward', 0.0)),
            positions     = positions,
        )


# =============================================================================
# VERIFIED MANEUVER LIBRARY
# =============================================================================

class VerifiedManeuverLibrary:
    """
    Trwała biblioteka proceduralna manewrów ucieczki.

    Capacity (CDC v1.2 sekcja 5):
      MAX_VERIFIED  = 200  (VERIFIED aktywne)
      ARCHIVED      = nieograniczone (historia zachowana)

    Wyszukiwanie przestrzenne:
      lookup(x, y) → najlepszy VERIFIED w promieniu SPATIAL_RADIUS [m]
      Ranking: quality_score = val_score × success_rate

    Auto-archiwizacja:
      fail_count >= 2 i success_rate < 0.33 → ARCHIVED (zdyskwalifikowany)
    """

    MAX_VERIFIED       = 200
    SPATIAL_RADIUS     = 2.0    # [m] – zwiększony promień
    AUTO_ARCHIVE_FAILS = 3      # więcej prób przed archiwizacją
    AUTO_ARCHIVE_RATE  = 0.4    # niższy wymagany wskaźnik sukcesu
    MAX_POSITIONS      = 50     # max pozycji na rekord (FIFO)

    def __init__(self, filepath: str = "maneuvers.json"):
        self.filepath = filepath

        # --- Binarna biblioteka prymitywów (CDC v1.2 – eliminacja JSON z RT) ---
        _bin_path = os.path.splitext(filepath)[0] + '.bin'
        if not _bin_path.endswith('.bin'):
            _bin_path = filepath + '.primitives.bin'
        self._plib             = PrimitiveLibrary(_bin_path)
        self._primitives_dirty = False
        # -----------------------------------------------------------------------

        self.records: List[ManeuverRecord] = []
        self.load_from_disk()

    # ------------------------------------------------------------------
    # Widoki – właściwości obliczane na bieżąco
    # ------------------------------------------------------------------

    @property
    def verified(self) -> List[ManeuverRecord]:
        return [r for r in self.records if r.status == ManeuverStatus.VERIFIED]

    @property
    def candidates(self) -> List[ManeuverRecord]:
        return [r for r in self.records if r.status == ManeuverStatus.CANDIDATE]

    @property
    def archived(self) -> List[ManeuverRecord]:
        return [r for r in self.records if r.status == ManeuverStatus.ARCHIVED]

    # ------------------------------------------------------------------
    # Zapis / promocja manewrów
    # ------------------------------------------------------------------

    def promote(self,
                actions:   List[Action],
                val_score: float,
                x: float, y: float,
                reward:    float) -> Optional[str]:
        """
        Próbuje awansować sekwencję do VERIFIED.

        Warunek: val_score >= 0.5 (obniżony próg – fantazja już filtruje)
        Jeśli identyczna sekwencja już istnieje (dowolny status) →
          aktualizuje zamiast duplikować.
        Zwraca: maneuver_id jeśli zapisano, None jeśli odrzucono.
        """
        if val_score < 0.25:   # obniżony próg
            return None
        if len(actions) < 3:
        	return None

        action_names = [a.name for a in actions]

        # Szukaj istniejącego rekordu z identyczną sekwencją
        for rec in self.records:
            if rec.actions == action_names and rec.status != ManeuverStatus.ARCHIVED:
                # Wzmocnij istniejący
                rec.val_score  = max(rec.val_score, val_score)
                rec.avg_reward = rec.avg_reward * 0.8 + reward * 0.2
                rec.positions.append((round(x, 3), round(y, 3)))
                rec.positions = rec.positions[-self.MAX_POSITIONS:]
                if rec.status == ManeuverStatus.CANDIDATE:
                    rec.status = ManeuverStatus.VERIFIED
                    print(f"[VML] CANDIDATE→VERIFIED {rec.maneuver_id} "
                          f"score={val_score:.3f}")
                self._primitives_dirty = True
                return rec.maneuver_id

        # Nowy rekord VERIFIED
        mid = str(uuid.uuid4())[:8]
        now = time.time()
        rec = ManeuverRecord(
            maneuver_id = mid,
            actions     = action_names,
            status      = ManeuverStatus.VERIFIED,
            val_score   = val_score,
            created_at  = now,
            last_used   = now,
            avg_reward  = reward,
            positions   = [(round(x, 3), round(y, 3))],
        )
        self.records.append(rec)
        self._enforce_capacity()
        self._primitives_dirty = True
        print(f"[VML] NOWY VERIFIED {mid} len={len(actions)} "
              f"score={val_score:.3f} @ ({x:.2f},{y:.2f})")
        return mid

    def add_candidate(self,
                      actions: List[Action],
                      x: float, y: float,
                      reward:  float) -> str:
        """
        Zapisuje kandydata z val_score < 0.7 – niezweryfikowanego.
        Kandydaci nie są używani przez VMLExecutor ale mogą być
        poźniej awansowane po dodatkowej walidacji.
        """
        action_names = [a.name for a in actions]
        mid = str(uuid.uuid4())[:8]
        now = time.time()
        rec = ManeuverRecord(
            maneuver_id = mid,
            actions     = action_names,
            status      = ManeuverStatus.CANDIDATE,
            val_score   = 0.0,
            created_at  = now,
            last_used   = now,
            avg_reward  = reward,
            positions   = [(round(x, 3), round(y, 3))],
        )
        self.records.append(rec)
        # Kandydaci nie przebudowują prymitywów – tylko VERIFIED trafia do PLIB
        return mid

    # ------------------------------------------------------------------
    # Wyszukiwanie przestrzenne
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Wyszukiwanie – KD-drzewo (delta) z fallbackiem na skan liniowy
    # ------------------------------------------------------------------

    def lookup(self, x: float, y: float) -> Optional[ManeuverRecord]:
        """
        CDC v1.2 – wyszukiwanie VERIFIED manewru do wykonania.

        Ścieżka szybka (PrimitiveLibrary dostępna):
          Zwraca VERIFIED ManeuverRecord o najwyższym quality_score z binarnej
          biblioteki prymitywów. Parametry x, y zachowane dla kompatybilności
          wstecznej z VMLExecutor.try_start(x, y); wyszukiwanie jest
          niezależne od mapy (oparcie na delta, nie na pozycji bezwzględnej).

        Fallback (brak primitives.bin):
          Oryginalny skan liniowy po pozycjach w SPATIAL_RADIUS.

        Czas ścieżki szybkiej: O(N) argmax na scores – wywoływany rzadko.
        """
        # --- Ścieżka szybka: PrimitiveLibrary z binarnego pliku ---
        if self._plib.is_ready() and self._plib._action_keys:
            idx, _ = self._plib.select_best()
            if idx >= 0:
                key = self._plib.get_action_key(idx)
                if key is not None:
                    # Odwzoruj na ManeuverRecord po krotce akcji
                    for rec in self.verified:
                        if tuple(rec.actions) == key:
                            return rec
                    # Klucz bez pasującego VERIFIED (np. archived po poprzednim save)
                    # → Szukaj kolejnych kandydatów z plib w kolejności malejącego score
                    if len(self._plib.scores) > 1:
                        sorted_idx = np.argsort(self._plib.scores)[::-1]
                        for alt_idx in sorted_idx[1:5]:   # max 4 próby
                            alt_key = self._plib.get_action_key(int(alt_idx))
                            if alt_key is None:
                                continue
                            for rec in self.verified:
                                if tuple(rec.actions) == alt_key:
                                    return rec

        # --- Fallback: oryginalny skan przestrzenny po pozycjach ---
        best: Optional[ManeuverRecord] = None
        best_q = -1.0
        for rec in self.verified:
            for px, py in rec.positions:
                dist = math.sqrt((x - px) ** 2 + (y - py) ** 2)
                if dist <= self.SPATIAL_RADIUS:
                    q = rec.quality_score
                    if q > best_q:
                        best_q = q
                        best = rec
                    break
        return best

    def select_maneuver(self,
                        dx: float, dy: float, dtheta: float
                        ) -> Optional[ManeuverRecord]:
        """
        Wyszukuje VERIFIED ManeuverRecord najlepiej odpowiadający zadanemu
        wektorowi przemieszczenia (dx, dy, dtheta) generowanemu przez planer
        lub sieć neuronową.

        Czas: O(log N) ~< 1 µs (cKDTree).
        Zwraca ManeuverRecord lub None gdy brak biblioteki prymitywów.
        """
        if not self._plib.is_ready() or not self._plib._action_keys:
            return None
        idx, _ = self._plib.select_maneuver(dx, dy, dtheta)
        if idx < 0:
            return None
        key = self._plib.get_action_key(idx)
        if key is None:
            return None
        for rec in self.verified:
            if tuple(rec.actions) == key:
                return rec
        return None

    # ------------------------------------------------------------------
    # Wynik wykonania
    # ------------------------------------------------------------------

    def record_outcome(self, maneuver_id: str,
                       success: bool,
                       reward:  float = 0.0):
        """
        Aktualizuje statystyki po wykonaniu manewru przez VMLExecutor.

        Auto-archiwizacja:
          fail_count >= AUTO_ARCHIVE_FAILS i success_rate < AUTO_ARCHIVE_RATE
          → ARCHIVED (zdyskwalifikowany manewer)
        """
        for rec in self.records:
            if rec.maneuver_id != maneuver_id:
                continue
            rec.use_count  += 1
            rec.last_used   = time.time()
            rec.avg_reward  = rec.avg_reward * 0.9 + reward * 0.1
            if success:
                rec.success_count += 1
                # Zwiększamy pewność za udane wykonanie (max 1.0)
                rec.val_score = min(1.0, rec.val_score + 0.01)
            else:
                rec.fail_count += 1
                if (rec.fail_count >= self.AUTO_ARCHIVE_FAILS
                        and rec.success_rate < self.AUTO_ARCHIVE_RATE):
                    rec.status = ManeuverStatus.ARCHIVED
                    print(f"[VML] AUTO-ARCHIVED {maneuver_id} "
                          f"(fail={rec.fail_count} "
                          f"sr={rec.success_rate:.2f})")
                    self._primitives_dirty = True
            return

    def archive(self, maneuver_id: str):
        """Ręczna archiwizacja manewru (np. po decyzji operatora)."""
        for rec in self.records:
            if rec.maneuver_id == maneuver_id:
                rec.status = ManeuverStatus.ARCHIVED
                self._primitives_dirty = True
                self.save_to_disk()
                return

    # ------------------------------------------------------------------
    # Degradacja nieużywanych manewrów (zapominanie)
    # ------------------------------------------------------------------

    def degrade_unused(self, current_step: int, forget_after: int = 100000,
                       min_use_count: int = 2, decay_factor: float = 0.8):
        """
        Degradacja nieużywanych manewrów.
        - Jeśli manewr ma < min_use_count użyć I system przeszedł > forget_after kroków → obniżamy score
        - Jeśli last_used > 3600s temu (1h) I use_count < min_use_count → dodatkowa degradacja
        - Przy score < 0.35 → status ARCHIVED (nie usuwamy, tylko blokujemy)
        """
        import time as _time
        now = _time.time()
        degraded_count = 0
        archived_count = 0

        for rec in self.records:
            if rec.status == ManeuverStatus.ARCHIVED:
                continue
            use_count = rec.use_count
            age_hours = (now - rec.last_used) / 3600.0   # czas od ostatniego użycia [h]

            stale_by_steps = use_count < min_use_count and current_step > forget_after
            stale_by_time  = use_count < min_use_count and age_hours > 1.0

            if stale_by_steps or stale_by_time:
                old_score = rec.val_score
                rec.val_score = max(0.0, old_score * decay_factor)
                degraded_count += 1

                reason = f"steps>{forget_after}" if stale_by_steps else f"age={age_hours:.1f}h"
                print(f"[DEGRADE] {rec.maneuver_id} nieużywany ({reason}) "
                      f"→ score {old_score:.3f} → {rec.val_score:.3f}")

                if rec.val_score < 0.35:
                    rec.status = ManeuverStatus.ARCHIVED
                    archived_count += 1
                    print(f"[ARCHIVE] {rec.maneuver_id} zablokowany (score < 0.35)")

        if degraded_count > 0 or archived_count > 0:
            print(f"[DEGRADE SUMMARY] degraded={degraded_count}, archived={archived_count}")
            self.save_to_disk()

    # ------------------------------------------------------------------
    # Capacity enforcement
    # ------------------------------------------------------------------

    def _enforce_capacity(self):
        """
        Jeśli VERIFIED > MAX_VERIFIED: archiwizuj najsłabszy rekord
        (najniższy quality_score) aż pojemność jest OK.
        """
        while len(self.verified) > self.MAX_VERIFIED:
            worst = min(self.verified, key=lambda r: r.quality_score)
            worst.status = ManeuverStatus.ARCHIVED
            print(f"[VML] CAPACITY TRIM: {worst.maneuver_id} → ARCHIVED")

    # ------------------------------------------------------------------
    # Persystencja JSON + binarna biblioteka prymitywów
    # ------------------------------------------------------------------

    def _rebuild_primitives(self) -> None:
        """
        Odbudowuje primitives.bin z aktualnych VERIFIED rekordów i wczytuje go
        do self._plib. Wywołuj po zmianach w zbiorze VERIFIED.
        """
        try:
            built = PrimitiveLibrary.build_from_records(
                self.records, self._plib.filepath
            )
            # Przejęcie stanu zbudowanej biblioteki
            self._plib.deltas       = built.deltas
            self._plib.scores       = built.scores
            self._plib.actions_list = built.actions_list
            self._plib.lengths      = built.lengths
            self._plib.kdtree       = built.kdtree
            self._plib._action_keys = built._action_keys
            self._primitives_dirty  = False
        except Exception as e:
            print(f'[PLIB] Błąd przebudowy prymitywów: {e}')

    def save_to_disk(self):
        """Atomiczny zapis JSON (maneuvers.json) + rebuild primitives.bin gdy dirty."""
        # --- JSON ---
        data = {
            "version": "1.2",
            "saved_at": time.time(),
            "records": [r.to_dict() for r in self.records],
        }
        tmp = self.filepath + ".tmp"
        try:
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.filepath)
        except Exception as e:
            print(f"[VML] Błąd zapisu JSON: {e}")

        # --- Binarna biblioteka prymitywów ---
        if self._primitives_dirty:
            self._rebuild_primitives()

    def load_from_disk(self):
        """
        Wczytuje rekordy z maneuvers.json.
        Następnie wczytuje primitives.bin lub odbudowuje go jeśli brak.
        Błędny JSON = pusta biblioteka.
        """
        if not os.path.exists(self.filepath):
            self.records = []
            return
        try:
            with open(self.filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.records = [ManeuverRecord.from_dict(d)
                            for d in data.get('records', [])]
            v = len(self.verified)
            c = len(self.candidates)
            a = len(self.archived)
            print(f"[VML] Wczytano: {v} VERIFIED, {c} CANDIDATE, {a} ARCHIVED")
        except Exception as e:
            print(f"[VML] Błąd odczytu ({e}) – start z pustą biblioteką")
            self.records = []

        # --- Wczytaj lub zbuduj primitives.bin ---
        if not self._plib.load():
            print('[PLIB] Brak primitives.bin – buduję z rekordów...')
            self._rebuild_primitives()

    # ------------------------------------------------------------------
    # Diagnostyka
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        v = self.verified
        return {
            'verified':       len(v),
            'candidate':      len(self.candidates),
            'archived':       len(self.archived),
            'avg_val_score':  round(sum(r.val_score for r in v) / max(len(v), 1), 3),
            'avg_success_rate': round(sum(r.success_rate for r in v) / max(len(v), 1), 3),
        }

    def __len__(self) -> int:
        return len(self.verified)


# =============================================================================
# VML EXECUTOR – zarządza wykonaniem sekwencji w pętli głównej
# =============================================================================

class VMLExecutor:
    """
    Wykonuje sekwencję akcji z VML jako 100% override CorpusCallosum.

    Wywołanie w pętli main.py:
        vml_action, override = executor.step(safety_active, reward)
        if override and vml_action:
            pwm_l, pwm_r = _action_to_pwm(vml_action, PWM_MAX)
            final_source = f"VML({vml_action.name})"

    Zasady bezpieczeństwa (CDC v1.2):
      - SafetyLayer ZAWSZE ma pierwszeństwo
      - 1. przerwanie Safety → pauza + RESUME_CLEAR_CYCLES czekania
      - 2. przerwanie Safety w TYM SAMYM manewrze → abort + mark failed
      - Po abort: VMLExecutor wraca do IDLE, normalne fast/slow/CC flow
    """

    # Po ilu czystych krokach (bez Safety) wznowiamy po 1. przerwaniu
    RESUME_CLEAR_CYCLES: int = 3

    def __init__(self, vml: VerifiedManeuverLibrary):
        self.vml = vml

        self._active_id:       Optional[str]   = None
        self._active_actions:  List[Action]    = []
        self._seq_index:       int             = 0
        self._interrupt_count: int             = 0
        self._interrupted:     bool            = False
        self._clear_countdown: int             = 0
        self.plib                              = None  # ustawiany przez attach_plib

    # ------------------------------------------------------------------
    # Właściwości
    # ------------------------------------------------------------------

    @property
    def is_active(self) -> bool:
        return self._active_id is not None

    @property
    def is_interrupted(self) -> bool:
        return self._interrupted

    @property
    def active_id(self) -> Optional[str]:
        return self._active_id

    @property
    def progress_str(self) -> str:
        if not self.is_active:
            return "IDLE"
        return (f"{self._active_id}"
                f"[{self._seq_index}/{len(self._active_actions)}]"
                f"i{self._interrupt_count}")

    # ------------------------------------------------------------------
    # PrimitiveLibrary – attach & lookup
    # ------------------------------------------------------------------

    def attach_plib(self, plib) -> None:
        """Przypina PrimitiveLibrary do executora."""
        self.plib = plib

    def lookup_by_delta(self, dx: float, dy: float, dtheta: float = 0.0) -> bool:
        """
        Próbuje znaleźć i uruchomić zweryfikowany manewr z PrimitiveLibrary
        na podstawie żądanego wektora przemieszczenia (dx, dy, dtheta).
        Zwraca True, jeśli manewr został pomyślnie rozpoczęty.
        """
        if self.plib is None or not self.plib.is_ready():
            return False
        if self.is_active:
            return False

        idx, act_bytes = self.plib.select_maneuver(dx, dy, dtheta)
        if idx < 0 or act_bytes is None or len(act_bytes) == 0:
            return False

        # Dekodowanie bajtów uint8 → lista Action (przez ACTION_NAMES z swarm_primitives)
        from swarm_primitives import ACTION_NAMES as PLIB_ACTION_NAMES
        action_list: List[Action] = []
        for b in act_bytes:
            name = PLIB_ACTION_NAMES.get(int(b), 'STOP')
            try:
                action_list.append(Action[name])
            except KeyError:
                action_list.append(Action.STOP)

        if not action_list:
            return False

        self._active_actions   = action_list
        self._seq_index        = 0
        self._interrupt_count  = 0
        self._interrupted      = False
        self._clear_countdown  = 0
        self._active_id        = f"plib_{idx}"
        print(f"[VML] Primitive {idx} started via lookup_by_delta"
              f"({dx:.2f}, {dy:.2f}, {dtheta:.2f})")
        return True

    # ------------------------------------------------------------------
    # Uruchomienie
    # ------------------------------------------------------------------

    def try_start(self, x: float, y: float) -> bool:
        """
        Próbuje uruchomić manewr VML dla pozycji (x,y).
        Wywołuj gdy: not is_active AND stuck_cycles >= 5.
        Zwraca True jeśli znaleziono i uruchomiono manewr.
        """
        if self.is_active:
            return True

        rec = self.vml.lookup(x, y)
        if rec is None:
            return False

        self._active_id       = rec.maneuver_id
        self._active_actions  = rec.actions_enum
        self._seq_index       = 0
        self._interrupt_count = 0
        self._interrupted     = False
        self._clear_countdown = 0

        print(f"[VML] START {rec.maneuver_id} "
              f"({len(self._active_actions)} kroków) "
              f"score={rec.quality_score:.3f} @ ({x:.2f},{y:.2f})")
        return True

    # ------------------------------------------------------------------
    # Krok wykonania
    # ------------------------------------------------------------------

    def step(self,
             hard_safety: bool = False,
             reward: float = 0.0) -> Tuple[Optional[Action], bool]:
        """
        Wywołaj co krok pętli głównej JEŻELI is_active == True.

        Blok 3: VML trzyma sekwencję przez CAŁY czas trwania.
        Fast Brain przechodzi w tryb obserwacji — nie przerywa manewru.
        Tylko HARD safety (BUMPER_HIT, HARD_SAFETY) może przerwać.
        SPATIAL_TURN, US_CORR, STAGNATION — NIE przerywają VML.

        Parametry:
          hard_safety – True TYLKO przy BUMPER_HIT / HARD_SAFETY (absolutne veto)
          reward      – bieżąca nagroda

        Zwraca:
          (vml_action, override_active)
        """
        if not self.is_active:
            return None, False

        # --- Tylko HARD safety przerywa VML ---
        if hard_safety:
            self._interrupt_count += 1
            self._interrupted      = True
            self._clear_countdown  = self.RESUME_CLEAR_CYCLES

            if self._interrupt_count >= 2:
                print(f"[VML] ABORT {self._active_id} (2. HARD safety)")
                self._finish(success=False, reward=reward)
            return None, False

        # --- Po hard safety: odlicz czyste kroki przed wznowieniem ---
        if self._interrupted:
            if self._clear_countdown > 0:
                self._clear_countdown -= 1
                return None, False
            self._interrupted = False
            print(f"[VML] WZNOWIENIE {self._active_id} "
                  f"od kroku {self._seq_index}/{len(self._active_actions)}")

        # --- Normalne wykonanie — Fast w trybie obserwacji ---
        if self._seq_index >= len(self._active_actions):
            print(f"[VML] SUKCES {self._active_id} "
                  f"({len(self._active_actions)} kroków)")
            self._finish(success=True, reward=reward)
            return None, False

        action = self._active_actions[self._seq_index]
        self._seq_index += 1
        return action, True

    # ------------------------------------------------------------------
    # Wewnętrzne
    # ------------------------------------------------------------------

    def _finish(self, success: bool, reward: float = 0.0):
        """Zakończ manewr – zaktualizuj statystyki VML, wyczyść stan."""
        if self._active_id is not None:
            self.vml.record_outcome(self._active_id, success, reward)
        self._active_id       = None
        self._active_actions  = []
        self._seq_index       = 0
        self._interrupt_count = 0
        self._interrupted     = False
        self._clear_countdown = 0

    def reset(self):
        """Wymuś reset (np. przy resecie całego systemu)."""
        self._finish(success=False)

    # ------------------------------------------------------------------
    # Diagnostyka
    # ------------------------------------------------------------------

    def get_diagnostics(self) -> Dict[str, Any]:
        return {
            'vml_active':     self.is_active,
            'vml_id':         self._active_id or '',
            'vml_progress':   self.progress_str,
            'vml_step':       self._seq_index,
            'vml_total':      len(self._active_actions),
            'vml_interrupts': self._interrupt_count,
            'vml_paused':     self._interrupted,
        }