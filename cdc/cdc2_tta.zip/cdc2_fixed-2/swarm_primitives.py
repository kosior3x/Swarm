#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
swarm_primitives.py – Binary Primitive Library dla CDC v1.2
============================================================
Zastępuje wyszukiwanie po JSON w pętli RT binarnym plikiem primitives.bin
indeksowanym cKDTree po wektorze przemieszczenia (dx, dy, dtheta).

Format primitives.bin:
  [4B] uint32  N            – liczba prymitywów
  [4B] uint32  L            – łączna długość bajtów akcji
  Dla każdego i:
    [12B] float32[3]  delta  – (dx, dy, dtheta) wynikowe przemieszczenie
    [4B]  float32     score  – quality_score
    [2B]  uint16      len    – długość sekwencji bajtów akcji
  [L B] surowe bajty akcji (wszystkie prymitywy jeden za drugim)

Czas wyszukiwania: < 1 µs (cKDTree skompilowany w C).
"""

import math
import os
import struct
from typing import Dict, List, Optional, Tuple

import numpy as np
from scipy.spatial import cKDTree

# =============================================================================
# KODOWANIE AKCJI
# =============================================================================

ACTION_CODES: Dict[str, int] = {
    'FORWARD':         0x01,
    'REVERSE':         0x02,
    'TURN_LEFT':       0x03,
    'TURN_RIGHT':      0x04,
    'SPIN_LEFT':       0x05,
    'SPIN_RIGHT':      0x06,
    'STOP':            0x07,
    'ESCAPE_MANEUVER': 0x08,
}

ACTION_NAMES: Dict[int, str] = {v: k for k, v in ACTION_CODES.items()}

# =============================================================================
# KINEMATYKA RÓŻNICOWA – parametry z config.py + arena_eval.py
# =============================================================================

_WHEEL_BASE   = 0.28    # [m]
_MAX_SPEED    = 0.75    # [m/s] przy PWM=100
_PWM_MAX      = 100.0
_DT           = 0.063   # [s] krok symulacji

# (vl_norm, vr_norm) przy spd=1.0, st=0.0 – z obliczeń swarm_fast.py
# vl_norm = pwm_l / PWM_MAX,  vr_norm = pwm_r / PWM_MAX
_PWM_TABLE: Dict[str, Tuple[float, float]] = {
    # FORWARD: pl=pr=100
    'FORWARD':          ( 1.000,  1.000),
    # TURN_LEFT: inner_r=0.35, pl=35, pr=100
    'TURN_LEFT':        ( 0.350,  1.000),
    # TURN_RIGHT: pl=100, pr=35
    'TURN_RIGHT':       ( 1.000,  0.350),
    # SPIN_LEFT: mag=50, pl=-50, pr=50
    'SPIN_LEFT':        (-0.500,  0.500),
    # SPIN_RIGHT: pl=50, pr=-50
    'SPIN_RIGHT':       ( 0.500, -0.500),
    # REVERSE: rev=45, pl=pr=-45
    'REVERSE':          (-0.450, -0.450),
    # ESCAPE_MANEUVER: mag=30, pl=-30, pr=30
    'ESCAPE_MANEUVER':  (-0.300,  0.300),
    # STOP
    'STOP':             ( 0.000,  0.000),
}


def simulate_delta(action_names: List[str],
                   dt: float       = _DT,
                   max_speed: float = _MAX_SPEED,
                   wheel_base: float = _WHEEL_BASE
                   ) -> Tuple[float, float, float]:
    """
    Symuluje efekt sekwencji akcji startując z (x=0, y=0, theta=0).
    Model: jednokrokowa kinematyka różnicowa.

    Zwraca: (dx, dy, dtheta) – wektor przemieszczenia jako float.
    """
    x = y = theta = 0.0
    for name in action_names:
        vl, vr = _PWM_TABLE.get(name, (0.0, 0.0))
        v     = (vl + vr) * 0.5 * max_speed
        omega = (vr - vl) / wheel_base * max_speed
        theta += omega * dt
        x     += v * math.cos(theta) * dt
        y     += v * math.sin(theta) * dt
    return float(x), float(y), float(theta)


# =============================================================================
# ZAPIS / ODCZYT BINARNY
# =============================================================================

def save_primitives(primitives: List[dict], filename: str) -> None:
    """
    Zapisuje listę prymitywów do pliku binarnego.

    Każdy element listy to dict z kluczami:
      'delta'         – tuple (dx, dy, dtheta)
      'score'         – float
      'actions_bytes' – np.ndarray dtype=uint8
    """
    N = len(primitives)
    total_len = sum(len(p['actions_bytes']) for p in primitives)

    tmp = filename + '.tmp'
    with open(tmp, 'wb') as f:
        # Nagłówek globalny
        f.write(struct.pack('<II', N, total_len))
        # Nagłówki prymitywów
        for p in primitives:
            dx, dy, dt = p['delta']
            f.write(struct.pack('<3ffH',
                                float(dx), float(dy), float(dt),
                                float(p['score']),
                                len(p['actions_bytes'])))
        # Surowe bajty akcji
        for p in primitives:
            f.write(bytes(p['actions_bytes']))
    os.replace(tmp, filename)


def load_primitives(filename: str) -> Tuple[
        np.ndarray, np.ndarray, List[np.ndarray], np.ndarray, 'cKDTree']:
    """
    Wczytuje primitives.bin jednym wywołaniem f.read.

    Zwraca:
      deltas       – np.ndarray (N, 3) float32
      scores       – np.ndarray (N,)   float32
      actions_list – lista N × np.ndarray uint8
      lengths      – np.ndarray (N,)   uint16
      kdtree       – cKDTree zbudowany na deltas
    """
    with open(filename, 'rb') as f:
        header = f.read(8)
        N, total_len = struct.unpack('<II', header)

        deltas  = np.empty((N, 3), dtype=np.float32)
        scores  = np.empty(N,      dtype=np.float32)
        lengths = np.empty(N,      dtype=np.uint16)

        # Wczytaj wszystkie nagłówki prymitywów jedną pętlą
        raw_headers = f.read(18 * N)
        for i in range(N):
            off = i * 18
            dx, dy, dth, sc, ln = struct.unpack_from('<3ffH', raw_headers, off)
            deltas[i]  = (dx, dy, dth)
            scores[i]  = sc
            lengths[i] = ln

        # Wczytaj blok bajtów akcji jednym wywołaniem
        actions_flat = np.frombuffer(f.read(total_len), dtype=np.uint8).copy()
        splits = np.cumsum(lengths)[:-1]
        actions_list = np.split(actions_flat, splits)

    kdtree = cKDTree(deltas)
    return deltas, scores, actions_list, lengths, kdtree


# =============================================================================
# KLASA BIBLIOTEKI PRYMITYWÓW
# =============================================================================

class PrimitiveLibrary:
    """
    Biblioteka prymitywów manewrów indeksowana cKDTree po (dx, dy, dtheta).

    Eliminuje JSON z pętli RT – wyszukiwanie O(log N) ~< 1 µs.
    Pełne zarządzanie rekordami (promote/record_outcome) pozostaje
    w VerifiedManeuverLibrary (JSON + persistence).

    Typowy cykl życia:
      1. Zbuduj z rekordów VML:  PrimitiveLibrary.build_from_records(records, filepath)
      2. Wczytaj w runtime:      plib.load()
      3. Zapytaj:                idx, act_bytes = plib.select_maneuver(dx, dy, dtheta)
                            lub  idx, act_bytes = plib.select_best()
    """

    def __init__(self, filepath: str = 'primitives.bin'):
        self.filepath = filepath

        self.deltas:       Optional[np.ndarray]       = None   # (N,3) float32
        self.scores:       Optional[np.ndarray]       = None   # (N,)  float32
        self.actions_list: Optional[List[np.ndarray]] = None   # lista uint8[]
        self.lengths:      Optional[np.ndarray]       = None   # (N,)  uint16
        self.kdtree:       Optional[cKDTree]           = None

        # Klucz (tuple akcji) dla każdego indeksu – do odwzorowania na ManeuverRecord
        self._action_keys: Optional[List[tuple]] = None

    # ------------------------------------------------------------------
    # Wczytywanie
    # ------------------------------------------------------------------

    def load(self) -> bool:
        """
        Wczytuje primitives.bin i buduje cKDTree.
        Zwraca True jeśli sukces, False jeśli plik nie istnieje / błąd.
        """
        if not os.path.exists(self.filepath):
            return False
        try:
            (self.deltas, self.scores,
             self.actions_list, self.lengths, self.kdtree) = \
                load_primitives(self.filepath)
            print(f'[PLIB] Wczytano {len(self.scores)} prymitywów z {self.filepath}')
            return True
        except Exception as e:
            print(f'[PLIB] Błąd odczytu ({e})')
            self.deltas = self.scores = self.actions_list = self.lengths = self.kdtree = None
            return False

    def is_ready(self) -> bool:
        """True gdy dane i KD-drzewo są załadowane."""
        return (self.kdtree is not None
                and self.scores is not None
                and len(self.scores) > 0)

    # ------------------------------------------------------------------
    # Wyszukiwanie
    # ------------------------------------------------------------------

    def select_maneuver(self,
                        dx: float, dy: float, dtheta: float
                        ) -> Tuple[int, Optional[np.ndarray]]:
        """
        Zwraca prymityw najlepiej pasujący do żądanego przemieszczenia (dx,dy,dtheta).
        Czas: O(log N) ~< 1 µs dzięki cKDTree.

        Zwraca (idx, actions_bytes) lub (-1, None) gdy brak danych.
        """
        if not self.is_ready():
            return -1, None
        _dist, idx = self.kdtree.query([dx, dy, dtheta])
        return int(idx), self.actions_list[idx]

    def select_best(self) -> Tuple[int, Optional[np.ndarray]]:
        """
        Zwraca prymityw o najwyższym score (bez zadanego celu delta).
        Używany przez lookup(x, y) jako fallback map-independent.
        Czas: O(N) argmax – wywoływany rzadko (kilka razy na sekundę max).
        """
        if not self.is_ready():
            return -1, None
        idx = int(np.argmax(self.scores))
        return idx, self.actions_list[idx]

    def get_action_key(self, idx: int) -> Optional[tuple]:
        """Krotka nazw akcji dla danego indeksu prymitywu."""
        if self._action_keys is None or idx < 0 or idx >= len(self._action_keys):
            return None
        return self._action_keys[idx]

    # ------------------------------------------------------------------
    # Budowanie z rekordów VML
    # ------------------------------------------------------------------

    @classmethod
    def build_from_records(cls,
                           records,
                           filepath: str = 'primitives.bin'
                           ) -> 'PrimitiveLibrary':
        """
        Buduje i zapisuje primitives.bin z listy ManeuverRecord (tylko VERIFIED).

        Kroki:
          1. Grupuje rekordy po unikalnej krotce akcji.
          2. Wybiera najwyższy quality_score na grupę.
          3. Symuluje kinematykę → delta (dx, dy, dtheta).
          4. Koduje akcje → bajty.
          5. Zapisuje primitives.bin.
          6. Ładuje i zwraca gotową PrimitiveLibrary.
        """
        # Filtruj tylko VERIFIED
        verified = [r for r in records if r.status == 'VERIFIED']
        if not verified:
            obj = cls(filepath)
            print('[PLIB] Brak VERIFIED rekordów – pominięto budowę prymitywów')
            return obj

        # Grupowanie po unikalnej sekwencji akcji
        unique: Dict[tuple, float] = {}
        for rec in verified:
            key = tuple(rec.actions)
            q   = rec.val_score * rec.success_rate
            if key not in unique or q > unique[key]:
                unique[key] = q

        primitives  = []
        action_keys = []

        for key, score in unique.items():
            action_names  = list(key)
            dx, dy, dtheta = simulate_delta(action_names)
            actions_bytes  = np.array(
                [ACTION_CODES.get(n, 0x07) for n in action_names],
                dtype=np.uint8,
            )
            primitives.append({
                'delta':         (dx, dy, dtheta),
                'score':         float(np.clip(score, 0.0, 1.0)),
                'actions_bytes': actions_bytes,
            })
            action_keys.append(key)

        save_primitives(primitives, filepath)

        obj = cls(filepath)
        obj.load()
        obj._action_keys = action_keys
        print(f'[PLIB] Zbudowano {len(primitives)} unikalnych prymitywów → {filepath}')
        return obj


# =============================================================================
# NARZĘDZIE MIGRACJI – jednorazowy eksport maneuvers.json → primitives.bin
# =============================================================================

def migrate_json_to_binary(json_path: str = 'maneuvers.json',
                           bin_path:  str = 'primitives.bin') -> 'PrimitiveLibrary':
    """
    Jednorazowa migracja: wczytuje maneuvers.json, buduje primitives.bin.
    Wywoływać ręcznie lub z linii poleceń.

    Zwraca załadowaną PrimitiveLibrary.
    """
    import json as _json

    print(f'[MIGRATE] Wczytuję {json_path}...')
    with open(json_path, 'r', encoding='utf-8') as f:
        data = _json.load(f)

    records_raw = data.get('records', [])
    print(f'[MIGRATE] {len(records_raw)} rekordów w JSON')

    # Emulacja ManeuverRecord przy minimalnych zależnościach
    class _Rec:
        __slots__ = ('actions', 'status', 'val_score',
                     'use_count', 'success_count', 'fail_count')

        def __init__(self, d: dict):
            self.actions       = list(d['actions'])
            self.status        = str(d['status'])
            self.val_score     = float(d.get('val_score', 0.0))
            self.use_count     = int(d.get('use_count', 0))
            self.success_count = int(d.get('success_count', 0))
            self.fail_count    = int(d.get('fail_count', 0))

        @property
        def success_rate(self) -> float:
            t = self.success_count + self.fail_count
            return (self.success_count / t) if t > 0 else 1.0

    records = [_Rec(d) for d in records_raw]
    plib = PrimitiveLibrary.build_from_records(records, bin_path)
    return plib


# =============================================================================
# TEST WYDAJNOŚCI
# =============================================================================

def benchmark(bin_path: str = 'primitives.bin', n_queries: int = 10_000) -> None:
    """
    Mierzy czas wyszukiwania dla n_queries zapytań losowymi wektorami.
    Pokazuje wydajność batch (algorytmiczną) i pojedynczych wywołań Python.
    """
    import time

    plib = PrimitiveLibrary(bin_path)
    if not plib.load():
        print(f'[BENCH] Brak {bin_path} – najpierw uruchom migrację')
        return

    N = len(plib.scores)
    queries = np.random.uniform(-3.0, 3.0, (n_queries, 3)).astype(np.float32)

    # Warmup
    plib.kdtree.query(queries[:100])

    # --- Batch cKDTree (rzeczywista złożoność algorytmiczna) ---
    t0 = time.perf_counter()
    plib.kdtree.query(queries)
    t1 = time.perf_counter()
    batch_us   = (t1 - t0) * 1e6
    per_batch  = batch_us / n_queries

    # --- Single Python call overhead ---
    n_single = min(n_queries, 2000)
    t0 = time.perf_counter()
    for q in queries[:n_single]:
        plib.select_maneuver(float(q[0]), float(q[1]), float(q[2]))
    t1 = time.perf_counter()
    per_single = (t1 - t0) * 1e6 / n_single

    print(f'[BENCH] N={N} prymitywów | {n_queries} zapytań')
    print(f'[BENCH] Batch cKDTree:    {per_batch:.4f} µs/zapytanie  '
          f'{"✓ < 1 µs" if per_batch < 1.0 else "ok"}')
    print(f'[BENCH] Single Python:    {per_single:.2f} µs/zapytanie  '
          f'(overhead wywołania Python; nieistotny przy 1 decyzji/63ms)')
    print(f'[BENCH] Poprawa vs JSON parse: ~{int(50000 / max(per_batch, 0.01))}× '
          f'(JSON ~50 ms na 1 rekord)')


# =============================================================================
# CLI
# =============================================================================

if __name__ == '__main__':
    import sys
    cmd = sys.argv[1] if len(sys.argv) > 1 else 'migrate'

    if cmd == 'migrate':
        json_p = sys.argv[2] if len(sys.argv) > 2 else 'maneuvers.json'
        bin_p  = sys.argv[3] if len(sys.argv) > 3 else 'primitives.bin'
        plib   = migrate_json_to_binary(json_p, bin_p)
        benchmark(bin_p)

    elif cmd == 'bench':
        bin_p = sys.argv[2] if len(sys.argv) > 2 else 'primitives.bin'
        benchmark(bin_p)

    elif cmd == 'info':
        bin_p = sys.argv[2] if len(sys.argv) > 2 else 'primitives.bin'
        plib  = PrimitiveLibrary(bin_p)
        if plib.load():
            N = len(plib.scores)
            print(f'Prymitywów: {N}')
            print(f'Score min/max/avg: '
                  f'{plib.scores.min():.3f} / {plib.scores.max():.3f} / '
                  f'{plib.scores.mean():.3f}')
            print(f'Delta range dx: [{plib.deltas[:,0].min():.3f}, {plib.deltas[:,0].max():.3f}]')
            print(f'Delta range dy: [{plib.deltas[:,1].min():.3f}, {plib.deltas[:,1].max():.3f}]')
            print(f'Delta range dt: [{plib.deltas[:,2].min():.3f}, {plib.deltas[:,2].max():.3f}]')
        else:
            print(f'Plik {bin_p} nie istnieje – najpierw uruchom migrację')
    else:
        print('Użycie: swarm_primitives.py [migrate|bench|info] [json_path] [bin_path]')
