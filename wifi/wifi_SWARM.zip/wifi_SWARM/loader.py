#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
SWARM UNIVERSAL LOADER
================================================================================
Project: Autonomic SWARM
Version: 3.0 "Universal"
Date: 2026-01-25

This loader manages the SWARM Ecosystem without modifications to core files.
Supports: Windows, Linux, macOS, Android (Pydroid3)

Features:
- Dependency Check & Auto-fix
- Environment Setup (Directories, NPZ checks)
- Unified Menu for Simulator, Live Robot, and Trainer
- WiFi/ESP32 Discovery & Diagnostics
================================================================================
"""

import os
import sys
import time
import subprocess
import platform
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger('SwarmLoader')

# ============================================================================
# COLORS & AESTHETICS (ANSI)
# ============================================================================

class Color:
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

# ============================================================================
# DEPENDENCY MANAGER
# ============================================================================

DEPENDENCIES = {
    'numpy': 'numpy',
    'pandas': 'pandas',
    'pygame': 'pygame',
    'serial': 'pyserial'
}

def check_dependencies():
    """Check and report missing dependencies"""
    print(f"\n{Color.CYAN}[*] Checking Dependencies...{Color.END}")
    missing = []
    for module, package in DEPENDENCIES.items():
        try:
            __import__(module)
            print(f"  {Color.GREEN}[OK]{Color.END} {module}")
        except ImportError:
            print(f"  {Color.RED}[MISSING]{Color.END} {module} (package: {package})")
            missing.append(package)
    
    if missing:
        print(f"\n{Color.YELLOW}[!] Some dependencies are missing.{Color.END}")
        choice = input("Would you like to try installing them now? (y/n): ").lower()
        if choice == 'y':
            for pkg in missing:
                print(f"{Color.CYAN}[*] Installing {pkg}...{Color.END}")
                try:
                    subprocess.check_call([sys.executable, "-m", "pip", "install", pkg])
                except Exception as e:
                    print(f"{Color.RED}[ERROR] Failed to install {pkg}: {e}{Color.END}")
        else:
            print(f"{Color.YELLOW}[!] Please install them manually: pip install {' '.join(missing)}{Color.END}")

# ============================================================================
# ENVIRONMENT SETUP
# ============================================================================

def setup_environment():
    """Ensure directories and essential files exist"""
    print(f"\n{Color.CYAN}[*] Setting up environment...{Color.END}")
    
    # Check/Create Logs
    if not os.path.exists('logs'):
        os.makedirs('logs')
        print(f"  {Color.GREEN}[CREATED]{Color.END} logs directory")
    else:
        print(f"  {Color.GREEN}[OK]{Color.END} logs directory")
    
    # Check Brain
    if not os.path.exists('BEHAVIORAL_BRAIN.npz'):
        print(f"  {Color.YELLOW}[WARN]{Color.END} BEHAVIORAL_BRAIN.npz missing!")
        print("         System will use rule-based fallback or requires training.")
    else:
        print(f"  {Color.GREEN}[OK]{Color.END} BEHAVIORAL_BRAIN.npz")

# ============================================================================
# MENU ACTIONS
# ============================================================================

def run_simulator():
    """Launch the Pygame simulator"""
    print(f"\n{Color.BLUE}>>> LAUNCHING SWARM SIMULATOR <<<{Color.END}")
    try:
        subprocess.run([sys.executable, "swarm_simulator.py"])
    except Exception as e:
        print(f"{Color.RED}Error: {e}{Color.END}")

def run_live():
    """Launch the main robot loop"""
    print(f"\n{Color.BLUE}>>> LAUNCHING LIVE SWARM CONTROLLER <<<{Color.END}")
    try:
        subprocess.run([sys.executable, "swarm_main.py"])
    except Exception as e:
        print(f"{Color.RED}Error: {e}{Color.END}")

def run_trainer():
    """Launch the NPZ trainer"""
    print(f"\n{Color.BLUE}>>> LAUNCHING SWARM TRAINER <<<{Color.END}")
    try:
        subprocess.run([sys.executable, "swarm_trainer.py"])
    except Exception as e:
        print(f"{Color.RED}Error: {e}{Color.END}")

def run_diagnostics():
    """Check ESP32 connection and network status"""
    print(f"\n{Color.CYAN}--- SWARM DIAGNOSTICS ---{Color.END}")
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
        print(f"Local IP: {Color.GREEN}{local_ip}{Color.END}")
        
        print("\nScanning for ESP32 (port 81)...")
        from swarm_wifi import discover_esp32
        ip = discover_esp32(timeout=3.0)
        if ip:
            print(f"ESP32 Found: {Color.GREEN}{ip}{Color.END}")
        else:
            print(f"ESP32: {Color.RED}NOT FOUND{Color.END}")
            print("Check if ESP32 is on the same WiFi network.")
            
    except Exception as e:
        print(f"Diagnostics failed: {e}")
    
    input("\nPress Enter to return to menu...")

# ============================================================================
# MAIN INTERFACE
# ============================================================================

def print_header():
    os.system('cls' if os.name == 'nt' else 'clear')
    print(f"{Color.BOLD}{Color.BLUE}" + "="*60)
    print("      SWARM ROBOT SYSTEM - UNIVERSAL LOADER v3.0")
    print("="*60 + Color.END)
    print(f" Platform: {platform.system()} {platform.release()}")
    print(f" Python:   {sys.version.split()[0]}")
    print(f" Time:     {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{Color.BLUE}" + "="*60 + Color.END)

def main_menu():
    while True:
        print_header()
        print(f"\n{Color.BOLD}CHOOSE OPERATION:{Color.END}")
        print(f"  {Color.CYAN}1.{Color.END} RUN SIMULATOR        {Color.YELLOW}(Virtual Environment){Color.END}")
        print(f"  {Color.CYAN}2.{Color.END} RUN LIVE ROBOT       {Color.GREEN}(WiFi/ESP32 Connection){Color.END}")
        print(f"  {Color.CYAN}3.{Color.END} TRAIN BRAIN (NPZ)    {Color.CYAN}(Process Logs -> Model){Color.END}")
        print(f"  {Color.CYAN}4.{Color.END} RUN DIAGNOSTICS      {Color.BLUE}(Network & ESP32 Scan){Color.END}")
        print(f"  {Color.CYAN}5.{Color.END} RE-CHECK DEPENDENCIES")
        print(f"  {Color.RED}0. EXIT{Color.END}")
        
        choice = input(f"\n{Color.BOLD}Select [0-5]: {Color.END}").strip()
        
        if choice == '1':
            run_simulator()
        elif choice == '2':
            run_live()
        elif choice == '3':
            run_trainer()
        elif choice == '4':
            run_diagnostics()
        elif choice == '5':
            check_dependencies()
            input("\nPress Enter to continue...")
        elif choice == '0':
            print(f"\n{Color.GREEN}Exiting SWARM Loader. Goodbye!{Color.END}")
            break
        else:
            print(f"{Color.RED}Invalid selection.{Color.END}")
            time.sleep(1)

if __name__ == "__main__":
    try:
        # Initial checks
        print_header()
        setup_environment()
        
        # Check dependencies silently at start (optional)
        # check_dependencies() 
        
        main_menu()
    except KeyboardInterrupt:
        print(f"\n{Color.RED}Interrupted by user.{Color.END}")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Color.RED}Fatal error: {e}{Color.END}")
        input("Press Enter to exit...")
        sys.exit(1)
